import React, { useState, useEffect, Fragment } from 'react';
import JobSearch from '../component/JobSearch';

export default function JobDetails() {
  const [number, setNumber] = useState(0);
  const [openJob, setOpenJob] = React.useState(false);
  const [values, setValues] = useState({
    ID: '',
    title: '',
    description: '',
    qualifications: '',
  });

  const jobRoles = [
    {
      id: 'one',
      index: 1,
      role: "Analyst Strategy Manager",
      view: "VIEW JOB REQUIREMENTS",
      IDS: 415265093,
      description: `He D.`,
      qualifications: `Sifax, e`,
    },
    {
      id: 'two',
      index: 2,
      role: "React Frontend Developer",
      view: "VIEW JOB REQUIREMENTS",
      IDS: 13098201,
      description: `USA.`,
      qualifications: `InD.`,
    },
    {
      id: 'three',
      index: 3,
      role: "Office Administrator",
      view: "VIEW JOB REQUIREMENTS",
      IDS: 10309821,
      description: `This`,
      qualifications: `In.`,
    },
    {
      id: 'four',
      index: 4,
      role: "Project Manager",
      view: "VIEW JOB REQUIREMENTS",
      IDS: 13109820,
      description: `DSr.`,
      qualifications: `Juditn.`,
    },
    {
      id: 'five',
      index: 5,
      role: "IT Support",
      view: "VIEW JOB REQUIREMENTS",
      IDS: 31109820,
      description: `In .`,
      qualifications: `Kes.`,
    },
    {
      id: 'six',
      index: 6,
      role: "Application Developer - Full Stack",
      view: "VIEW JOB REQUIREMENTS",
      IDS: 31109820,
      description: `HeHF `,
      qualifications: `HeOPIP,`,
    },
  ]
  const jobDetails = [
    {
      index: 1,
      ID: 415265093,
      role: "Analyst Strategy Manager",
      description: `He D.`,
      qualifications: `Sifax, e`,
    },
    {
      index: 2,
      role: "React Frontend Developer",
      ID: 13098201,
      description: `USA.`,
      qualifications: `InD.`,
    },
    {
      index: 3,
      role: "Office Administrator",
      ID: 10309821,
      description: `This`,
      qualifications: `In.`,
    },
    {
      index: 4,
      role: "Project Manager",
      ID: 13109820,
      description: `DSr.`,
      qualifications: `Juditn.`,
    },
    {
      index: 5,
      role: "IT Support",
      ID: 31109820,
      description: `In .`,
      qualifications: `Kes.`,
    },
    {
      index: 6,
      role: "Application Developer - Full Stack",
      ID: 31109820,
      description: `HeHF `,
      qualifications: `HeOPIP,`,
    },
  ]
/*
  useEffect(() => {
    switch (number) {
      case 1:
        setValues({
          ...values,
          title: 'Chairman',
          ID: 10982031,
          description: `He D.`,
          qualifications: `Sifax, e`,
        });
        break;
      case 2:
        setValues({
          ...values,
          title: 'Development Specialist',
          ID: 13098201,
          description: `USA.`,
          qualifications: `InD.`,
        });
        break;
      case 3:
        setValues({
          ...values,
          title: 'Certified Trainer',
          ID: 10309821,
          description: `This`,
          qualifications: `In.`,
        });
        break;
      case 4:
        setValues({
          ...values,
          title: 'Development Specialist & Certified Trainer',
          ID: 13109820,
          description: `DSr.`,
          qualifications: `Juditn.`,
        });
        break;
      case 5:
        setValues({
          ...values,
          title: 'Certified Trainer & Development Specialist',
          ID: 31109820,
          description: `In .`,
          qualifications: `Kes.`,
        });
        break;
      case 6:
        setValues({
          ...values,
          title: 'Specialist & Trainer',
          ID: 31109820,
          description: `HeHF `,
          qualifications: `PIPHeO,`,
        });
        break;
      case 7:
        setValues({
          ...values,
          title: 'Development Certified Trainer',
          ID: 13109820,
          description: `Wit`,
          qualifications: `HeOPIP,`,
        });
        break;
      default:
        setValues({
          ...values,
        });
    }
  }, [number,values]);

   const handleClickOpenOne = (type) => {
    console.log("We are live")
    if (type === 'one') {
      setNumber(1);
    } else if (type === 'two') {
      setNumber(2);
    } else if (type === 'three') {
      setNumber(3);
    } else if (type === 'four') {
      setNumber(4);
    } else if (type === 'five') {
      setNumber(5);
    } else if (type === 'six') {
      setNumber(6);
    } else if (type === 'seven') {
      setNumber(7);
    } else {
      setOpenJob(false);
    }
    setOpenJob(true);
  };
  const handleCloseOne = () => {
    setOpenJob(false);
  }; */
  return (
    <Fragment>
      <JobSearch
        values={values}
        OpenJob={openJob}
        jobDetails={jobDetails}
        jobRoles={jobRoles}
      />
    </Fragment>
  );
}
