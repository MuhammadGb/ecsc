import React, { useState } from 'react';
import NavBar from '../globals/NavBar';
import Footer from '../globals/Footer';
import '../styles/Logopart.css';
import Box from '@material-ui/core/Box';
import { makeStyles } from '@material-ui/core/styles';
import { ThemeProvider, createTheme } from '@material-ui/core/styles';
import { default as FastMarquee } from 'react-fast-marquee';
import { Button, Paper, Typography } from '@material-ui/core';
import Solution from './Solution';
import Technology from './Technology';
import Operations from './Operations';
import Projects from './Projects';

import { Link } from 'react-router-dom';
import query from '../asset/images/query.png';
import blueback from '../asset/images/blueback.png';
import brownback from '../asset/images/brownback.png';
import blackback from '../asset/images/blackback.png';
import bigblackarrow from '../asset/images/bigblackarrow.png';

import circleone from '../asset/images/circleone.png';
import circletwo from '../asset/images/circletwo.png';
import circlethree from '../asset/images/circlethree.png';
import smallarrow from '../asset/images/smallarrow.png';
import bigarrow from '../asset/images/bigarrow.png';
import middlearrow from '../asset/images/middlearrow.png';
import mouseonly from '../asset/images/mouseonly.png';
import scanner from '../asset/images/scanner.png';
import drone from '../asset/images/drone.png';
import skyscraper from '../asset/images/skyscraper.png';
import twoHelmets from '../asset/images/twoHelmets.png';
import inTouchCircle from '../asset/images/inTouchCircle.png';
import mtn from '../asset/images/mtn.png';
import smile from '../asset/images/smile.png';
import firstbank from '../asset/images/firstbank.png';
import sifax from '../asset/images/sifax.png';
import cargo from '../asset/images/cargo.png';
import lagos from '../asset/images/lagos.png';
import towers from '../asset/images/towers.png';
import police from '../asset/images/police.png';
import wapic from '../asset/images/wapic.png';
import mansard from '../asset/images/mansard.png';
import cdk from '../asset/images/cdk.png';
import mainone from '../asset/images/mainone.png';
import arche from '../asset/images/arche.png';
import airtel from '../asset/images/airtel.png';
import platform from '../asset/images/platform.png';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import { motion, useViewportScroll, useAnimation } from 'framer-motion';

import '../styles/fonts.css';
import '../styles/NavBar.css';

const useStyles = makeStyles((theme) => ({
  root: {
    margin: '0',
    padding: '0',
  },
  bluemain: {
    display: 'flex',
    padding: '1.5em 0em 7em 0em',
    flexDirection: 'row',
    alignContent: 'center',
    margin: '0 auto',
    color: '#fff',
    fontFamily: 'Averta demo',
    '@media screen and (max-device-width:600px)': {
      padding: '0em 0em 7em 0em',
      flexDirection: 'row',
    },
  },
  queryImage: {
    top: '15%',
    left: '93.5%',
    cursor: 'pointer',
    width: '4.5%',
    height: '8%',
    padding: '0.7em',
    background: 'rgba(0, 0, 0, 0.3)',
    position: 'fixed',
    zIndex: '2',
    border: '2px solid white',
    borderRight: '0px',
  },
  bluepart: {
    backgroundImage: `url(${blueback})`,
    overflow: 'hidden',
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'cover',
    width: '100%',
    paddingBottom: '2em',
    marginLeft: '-0.15em',
    '@media screen and (max-device-width:600px)': {
      height: '60vh',
    },
  },
  blueLeft: {
    marginTop: '19em',
    marginLeft: '6em',
    width: '45%',
    '@media only screen and (max-device-width: 600px)': {
      marginLeft: '0.5em',
      marginTop: '10em',
    },
  },
  bluesustain: {
    fontSize: '3.2em',
    lineHeight: '1em',
    marginBottom: '0.8em',
    '@media only screen and (min-device-width: 1440px)': {
      fontSize: '3.5em',
    },
    '@media only screen and (max-device-width: 600px)': {
      fontSize: '3em',
    },
  },
  bluestrike: {
    fontSize: '1.1em',
    '@media only screen and (min-device-width: 1440px)': {
      width: '80%',
    },
    '@media only screen and (max-device-width: 1380px)': {
      width: '90%',
    },
    '@media only screen and (max-device-width: 600px)': {
      fontSize: '0.9em',
    },
  },
  // blueRight: {
  //   marginRight: '0em',
  //   position: 'relative',
  //   width: '50%',
  // },
  blueRight: {
    // [theme.breakpoints.down('sm')]
    display: 'flex',
    flexDirection: 'column',
    width: '55%',
    '@media only screen and (max-device-width: 600px)': {
      display: 'none',
    },
    '& img': {
      marginTop: '17em',
      padding: '0em 1.5em',
    },
  },
  imageCircleOne: {
    transition: 'transform 2s',
    '&:hover': {
      transform: 'rotate(360deg) translate(0)',
    },
  },
  imageCircleTwo: {
    transition: 'transform 2s',
    '&:hover': {
      transform: 'rotate(360deg) translate(0)',
    },
  },
  imageCircleThree: {
    animation: 'spin 2s linear',
  },
  '@keyframes spin': {
    '100%': {
      transform: 'rotate(360deg)',
    },
    '&:hover': {
      transform: 'rotate(360deg) translate(0)',
    },
  },
  roundImages: {
    display: 'flex',
    flexDirection: 'row',
  },
  imageWords: {
    display: 'flex',
    flexDirection: 'row',
  },
  relative1: {
    position: 'relative',
    top: '-5.7em',
    left: '10.5%',
    fontSize: '1.1em',
    fontFamily: 'Montserrat',
    '@media only screen and (min-device-width: 1500px)': {
      top: '-5.8em',
      left: '9.3%',
    },
  },
  relative2: {
    position: 'relative',
    top: '-5.7em',
    left: '28%',
    fontSize: '1.1em',
    fontFamily: 'Montserrat',
    margin: '0em 2em',
    '@media only screen and (min-device-width: 1500px)': {
      top: '-5.8em',
      left: '24.5%',
    },
  },
  relative3: {
    position: 'relative',
    fontFamily: 'Montserrat',
    top: '-5.7em',
    left: '38%',
    fontSize: '1.1em',
    margin: '0em 2em',
    '@media only screen and (min-device-width: 1500px)': {
      top: '-5.8em',
      left: '33.5%',
    },
  },
  solutiontext: {
    fontSize: '1.1em',
    color: 'whitesmoke',
    fontFamily: 'Opensanslight',
    fontWeight: '700',
  },
  solutionMain: {
    paddingLeft: '6em',
    display: 'flex',
    backgroundColor: '#020820',
    alignContent: 'center',
    flexDirection: 'row',
    '@media only screen and (max-device-width: 600px)': {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      margin: '0 auto',
      justifyContent: 'center',
    },
  },
  solutionItem: {
    display: 'flex',
    marginTop: '0.8em',
    flexDirection: 'row',
    padding: '2.5em 0.5em',
    cursor: 'pointer',
    '@media only screen and (max-device-width: 600px)': {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr 1fr',
      marginTop: '1em',
      padding: '1em 2em',
    },
  },
  smallarrow: {
    padding: '0 1em',
  },
  pushPart: {
    backgroundImage: `url(${brownback})`,
    height: '86.5vh',
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'cover',
    width: '100%',
    '@media only screen and (max-device-width: 600px)': {
      backgroundImage: 'none',
      height: '70vh',
    },
  },
  pushMain: {
    backgroundColor: '#fff',
    width: '40%',
    height: '77%',
    position: 'relative',
    paddingLeft: '6em',
    top: '14%',
    paddingRight: '4em',
    paddingTop: '3em',
    '@media only screen and (min-device-width: 1500px)': {
      top: '15.5%',
    },
    '@media only screen and (max-device-width: 600px)': {
      margin: '0 auto',
      justifyContent: 'center',
      paddingTop: '2em',
      position: 'static',
      width: '90%',
      paddingLeft: '0em',
      paddingRight: '0em',
    },
  },

  learntext: {
    fontWeight: '700',
    fontFamily: 'Opensanslight',
    fontSize: '0.6em',
  },
  learnarrow: {
    padding: '0em 0.5em',
  },
  pushBold: {
    fontSize: '2.8em',
    fontWeight: '700',
    lineHeight: '1',
    '@media only screen and (max-device-width: 600px)': {
      fontSize: '1.5em',
    },
  },
  learnMore: {
    display: 'flex',
    marginTop: '0.5em',
    textDecoration: 'none',
    justifyContent: 'left',
    alignItems: 'center',
    paddingBottom: '2em',
    fontSize: '1.8em',
    position: 'relative',
    color: '#000',
  },
  pushNormal: {
    fontSize: '1.2em',
    paddingTop: '2.4em',
    fontWeight: '600',
    '@media only screen and (max-device-width: 600px)': {
      fontSize: '0.9em',
    },
    //   lineHeight:'1',
  },
  linktext: {
    fontFamily: Opensans,
  },
  arrow: {
    padding: '0em 2em',
  },
  blackpart: {
    backgroundImage: `url(${blackback})`,
    height: '100vh',
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'cover',
    width: '100%',
    color: '#fff',
    '@media only screen and (max-device-width: 600px)': {
      marginTop: '2em',
      height: '50vh',
    },
  },
  blackmain: {
    paddingTop: '10em',
    paddingLeft: '6em',
    '@media only screen and (max-device-width: 600px)': {
      paddingLeft: '2em',
      paddingTop: '5em',
    },
  },
  performance: {
    display: 'flex',
    marginTop: '0.4em',
    textDecoration: 'none',
    justifyContent: 'left',
    alignItems: 'center',
    paddingBottom: '2em',
    fontSize: '5em',
    color: '#fff',
    '@media only screen and (max-device-width: 600px)': {
      paddingLeft: '0em',
      fontSize: '1.5em',
    },
  },
  blacktext: {
    fontSize: '5em',
    lineHeight: '1',
    '@media only screen and (max-device-width: 600px)': {
      fontSize: '2em',
    },
  },
  blackarrow: {
    padding: '0em 1em',
    width: '100px',
    '@media only screen and (max-device-width: 600px)': {
      width: '50px',
    },
  },
  strengthpart: {
    margin: '0 auto',
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
  },
  strengthmain: {
    marginTop: '3em',
    marginBottom: '3em',
  },
  strengthbold: {
    fontSize: '2em',
    fontWeight: '700',
    fontFamily: 'BellMT',
    lineHeight: '1.1',
  },
  strengthfirst: {
    marginTop: '2em',
  },
  strengthnormal: {
    fontSize: '1.1em',
    fontWeight: '800',
  },
  strengthnormalfirst: {
    marginTop: '1em',
  },

  cardpictures: {
    display: 'flex',
    flexDirection: 'row',
    padding: '2em 0em',
    margin: '0 auto',
    width: '100%',
    justifyContent: 'center',
    alignContent: 'center',
    [theme.breakpoints.down('sm')]: {
      display: 'block',
      padding: '0 1em',
      width: '100%',
    },
  },
  imageSection: {
    display: 'flex',
    flexDirection: 'column',
    margin: '0em 0.5em',
    textDecoration: 'none',
    width: '18%',
    color: '#354054 !important',
    [theme.breakpoints.down('sm')]: {
      // display:'block',
      width: '70%',
      margin: '0.9em 0.5em',
    },
  },
  imageBag: {
    width: '100%',
    height: '43%',
  },
  imageSelf: {
    width: '100%',
    height: '100%',
  },
  secondBag: {
    marginTop: '0.5em',
  },
  cardHeader: {
    fontSize: '1.2em',
    fontWeight: '700',
    fontFamily: 'Opensanslight',
    width: '100%',
  },
  cardHeadEmployee: {
    textAlign: 'left',
    fontSize: '1em',
    marginTop: '0em',
    fontWeight: '700',
    fontFamily: 'OpensansBold',
  },
  cardText: {
    marginTop: '2em',
    fontWeight: '700',
    fontSize: '0.9em',
    textDecoration: 'none',
  },
  cardTextemployee: {
    fontWeight: '700',
    marginTop: '0.6em',
    fontSize: '0.9em',
    fontFamily: 'Opensanslight',
  },
  adherencepart: {
    margin: '0 auto',
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
    paddingBottom: '5em',
  },
  adherencemain: {
    marginTop: '4em',
  },
  adherencesubmain: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },

  adherenceTopic: {
    fontSize: '2.1em',
    lineHeight: '1em',
    fontFamily: 'BellMT',
    fontWeight: '700',
    marginBottom: '0.5em',
  },
  adherencebold: {
    fontSize: '1.1em',
    fontFamily: 'Opensanslight',
    textAlign: 'center',
    width: '55%',
    fontWeight: '700',
    '@media screen and (max-width:600px)': {
      fontSize: '1.2em',
      width: '90%',
      margin: '0 auto',
    },
  },
  adherencenormal: {
    fontSize: '1.1em',
    fontWeight: '600',
    textAlign: 'center',
    width: '55%',
  },
  normalcont: {
    marginTop: '1.2em',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    '@media screen and (max-width:600px)': {
      marginTop: '1.5em',
    },
  },
  lowertext: {
    fontSize: '1.5em',
  },
  helmetpart: {
    display: 'flex',
    flexDirection: 'row',
    width: '100%',
    justifyContent: 'center',
    alignContent: 'center',
    color: '#fff',
    padding: '0em 0em',
    '@media only screen and (max-device-width: 600px)': {
      display: 'block',
    },
  },
  helmetleft: {
    backgroundColor: '#013B4F',
    padding: '0em 4em 0em 0em',
    width: '50%',
    height: '21em',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-end',
    justifyContent: 'center',
    zIndex: 2,
    marginBottom: '-0.2em',
    marginRight: '-0.2em',
    '@media only screen and (max-device-width: 600px)': {
      width: '92%',
      height: '44vh',
      padding: '2em 1em 1em 1em',
      margin: '0 auto',
      justifyContent: 'center',
    },
  },
  helmetbold: {
    fontSize: '2.8em',
    lineHeight: '1',
    textAlign: 'left',
    width: '85%',
    '@media only screen and (max-device-width: 600px)': {
      fontSize: '1em',
    },
  },
  helmetnormal: {
    fontSize: '1.1em',
    textAlign: 'left',
    fontWeight: 'light',
    marginTop: '2.5em',
    width: '85%',
  },
  helmetright: {
    padding: '0',
    backgroundImage: `url(${twoHelmets})`,
    width: '50%',
    zIndex: 1,
    height: '21em',
    backgroundRepeat: 'no-repeat',
    marginBottom: '-0.2em',
    backgroundSize: 'cover',
    '@media only screen and (max-device-width: 600px)': {
      display: 'none',
    },
  },
  market: {
    display: 'flex',
    flexDirection: 'row',
    margin: '0 auto',
    justifyContent: 'space-between',
    padding: '0em 0em 0em 0em',
    fontSize: '1.5em',
    marginTop: '4em',
    width: '90%',
    '@media only screen and (min-device-width: 1500px)': {
      marginTop: '5em',
    },
  },
  paragraph: {
    marginRight: '0.5em',
    textAlign: 'center',
    paddingTop: '5em',
    fontSize: '1.5em',
  },
  paratext: {
    fontSize: '1em',
    fontFamily: 'Opensanslight',
    fontWeight: '700',
    position: 'relative',
    left: '2em',
    '@media only screen and (max-device-width: 1380px)': {
      fontSize: '0.9em',
      marginLeft: '1em',
    },
  },
  paratext1: {
    fontSize: '1em',
    position: 'relative',
    fontFamily: 'Opensanslight',
    fontWeight: '700',
    left: '-2em',
    '@media only screen and (max-device-width: 1380px)': {
      fontSize: '0.9em',
    },
  },
  helmetimg: {
    padding: '0',
    margin: '0',
  },
  logopart: {},
  logomain: {
    marginTop: '2em',
  },
  touchpart: {
    marginTop: '0em',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    paddingBottom: '5em',
    zIndex: -1,
    height: '14em',
    backgroundImage: `url(${inTouchCircle})`,
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'cover',
    color: '#fff',
    padding: '7em 0em',
    '@media only screen and (max-device-width: 600px)': {
      justifyContent: 'left',
      alignItems: 'left',
      textAlign: 'left',
      margin: '0',
      padding: '4em 0em 2em 0em',
    },
  },
  touchmainOne: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    width: '53%',
  },
  touchmainTwo: {
    display: 'flex',
    flexDirection: 'column',
    width: '47%',
    '@media only screen and (max-device-width: 600px)': {
      //    marginLeft:'1em',
    },
  },
  touchboldOne: {
    fontSize: '2.5em',
    width: '70%',
    fontFamily: 'Leaguespartanbold',
    lineHeight: '1.1em',
  },
  touchboldTwo: {
    fontSize: '2.5em',
    textAlign: 'left',
    fontFamily: 'Leaguespartanbold',
    position: 'relative',
    color: '#2E324B',
    width: '70%',
    left: '13%',
  },
  touchnormal: {
    fontSize: '1.25em',
    textAlign: 'left',
    position: 'relative',
    fontFamily: 'Opensanslight',
    fontWeight: 700,
    color: '#2E324B',
    left: '8%',
    width: '70%',
    '@media only screen and (max-device-width: 600px)': {
      margin: '0',
      fontSize: '1.3em',
    },
  },
  touchnormal2: {
    fontSize: '1.25em',
    color: '#2E324B',
    fontFamily: 'Opensanslight',
    fontWeight: 700,
    position: 'relative',
    left: '11%',
    width: '70%',
    '@media only screen and (max-device-width: 600px)': {
      margin: '0',
      fontSize: '1.3em',
    },
  },
  linkButton: {
    marginTop: '4em',
    padding: '0em',
    width: '27%',
    textDecoration: 'none',
    borderRadius: '2.5em',
    position: 'relative',
    left: '18%',
    background: 'white',
    cursor: 'pointer',
  },
  buttonLink: {
    fontFamily: 'Opensanslight',
    textTransform: 'none',
    fontWeight: '900 ',
    fontSize: '1.3em',
    paddingLeft: '1.1em',
    borderRadius: '1.5em',
  },
  fowardIcon: {
    border: '3px solid #2E324B',
    color: '#2E324B',
    borderRadius: '1em',
    marginLeft: '0em',
    position: 'relative',
    left: '0.35em',
    fontSize: '1.5em !important',
    '@media only screen and (max-device-width: 1300px)': {
      left: '1em',
    },
  },
}));

const Opensans = createTheme({
  typography: {
    fontFamily: ['Opensanslight'].join(','),
  },
});

const AvertaDemo = createTheme({
  typography: {
    fontFamily: ['AvertaDemo'].join(','),
  },
});

const MontserratBold = createTheme({
  typography: {
    fontFamily: ['MontserratBold'].join(','),
  },
});

const OpensansBold = createTheme({
  typography: {
    fontFamily: ['OpensansBold'].join(','),
  },
});

const BellMTBold = createTheme({
  typography: {
    fontFamily: ['BellMTBold'].join(','),
  },
});

const HomePage = () => {
  const classes = useStyles();

  const [count, setCount] = useState(0);

  const ButtonVariants = {
    animate: {
      x: [0, -10],
      opacity: 1,
      transition: { yoyo: Infinity, ease: 'easeIn' },
    },
  };

  return (
    <div className={classes.root}>
      <Box className={classes.bluepart}>
        <NavBar />
        <img className={classes.queryImage} src={query} alt="query" />
        <div className={classes.bluemain}>
          <div className={classes.blueLeft}>
            <ThemeProvider theme={Opensans}>
              <ThemeProvider theme={BellMTBold}>
                <Typography className={classes.bluesustain}>
                  We help companies become sustainable
                </Typography>
              </ThemeProvider>
              <ThemeProvider theme={AvertaDemo}>
                <Typography className={classes.bluestrike}>
                  Striking the right cord through partnership and alliances
                  productivity. We exchanging ideas and connecting minds to
                  deliver greater productivity.
                </Typography>
              </ThemeProvider>
            </ThemeProvider>
          </div>
          <div className={classes.blueRight}>
            <Box className={classes.roundImages}>
              <img
                src={circleone}
                className={classes.imageCircleOne}
                alt={'circle-box'}
              />
              <img
                src={circletwo}
                className={classes.imageCircleTwo}
                alt={'circle-box'}
              />
              <img
                src={circlethree}
                className={classes.imageCircleThree}
                alt={'circle-box'}
              />
            </Box>
            <Box className={classes.imageWords}>
              <Typography className={classes.relative1}>Insight</Typography>
              <Typography className={classes.relative2}>Analysis</Typography>
              <Typography className={classes.relative3}>Reporting</Typography>
            </Box>
          </div>
        </div>
      </Box>
      <ThemeProvider theme={AvertaDemo}>
        <Box className={classes.solutionMain}>
          <div className={classes.solutionItem} onClick={() => setCount(0)}>
            <ThemeProvider theme={AvertaDemo}>
              <Typography className={classes.solutiontext}>
                Solution Engineering
              </Typography>
            </ThemeProvider>
            <img
              className={classes.smallarrow}
              src={smallarrow}
              alt={'small-arrow'}
            />
          </div>
          <div className={classes.solutionItem} onClick={() => setCount(1)}>
            <ThemeProvider theme={AvertaDemo}>
              <Typography className={classes.solutiontext}>
                Technology
              </Typography>
            </ThemeProvider>
            <img
              className={classes.smallarrow}
              src={smallarrow}
              alt={'small-arrow'}
            />
          </div>
          <div className={classes.solutionItem} onClick={() => setCount(2)}>
            <ThemeProvider theme={AvertaDemo}>
              <Typography className={classes.solutiontext}>
                Operations
              </Typography>
            </ThemeProvider>
            <img
              className={classes.smallarrow}
              src={smallarrow}
              alt={'small-arrow'}
            />
          </div>
          <div className={classes.solutionItem} onClick={() => setCount(3)}>
            <ThemeProvider theme={AvertaDemo}>
              <Typography className={classes.solutiontext}>Projects</Typography>
            </ThemeProvider>
            <img
              className={classes.smallarrow}
              src={smallarrow}
              alt={'small-arrow'}
            />
          </div>
        </Box>
      </ThemeProvider>

      {/* pushing mind limit */}
      <div className={classes.pushPart}>
        <div className={classes.pushMain}>
          {count === 0 ? <Solution /> : ''}
          {count === 1 ? <Technology /> : ''}
          {count === 2 ? <Operations /> : ''}
          {count === 3 ? <Projects /> : ''}
          <Link to="/about" className={classes.learnMore}>
            <p className={classes.learntext}>Learn more</p>
            <img
              src={bigblackarrow}
              className={classes.learnarrow}
              alt={'big-black-arrow'}
            />
          </Link>
        </div>
      </div>
      {/* enabling part */}
      <Box className={classes.blackpart}>
        <ThemeProvider theme={Opensans}>
          <div className={classes.blackmain}>
            <ThemeProvider theme={Opensans}>
              <ThemeProvider theme={BellMTBold}>
                <Typography className={classes.blacktext} my={0}>
                  Enabling operational
                </Typography>
                <Typography className={classes.blacktext} my={0}>
                  tenacity for optimum
                </Typography>
              </ThemeProvider>
              <Link to="/" className={classes.performance}>
                <i>performance</i>
                <img
                  src={bigarrow}
                  className={classes.blackarrow}
                  alt={'big-black-arrow'}
                />
              </Link>
            </ThemeProvider>
          </div>
        </ThemeProvider>
      </Box>

      {/* strength part */}
      <Box className={classes.strengthpart}>
        <ThemeProvider theme={AvertaDemo}>
          <div className={classes.strengthmain}>
            <Typography
              className={`${classes.strengthbold} ${classes.strengthfirst}`}
            >
              Strengthening your efforts with collaboration
            </Typography>
            <Typography
              className={`${classes.strengthnormal} ${classes.strengthnormalfirst}`}
            >
              Every company needs support especially when it comes to
              performance
            </Typography>
            <Typography className={classes.strengthnormal}>
              improvement, we can help you deliver your objective as our model
            </Typography>
            <Typography className={classes.strengthnormal}>
              lower cost and drive efficiency
            </Typography>
          </div>
        </ThemeProvider>
      </Box>

      {/* card part */}
      <Box>
        <ThemeProvider theme={Opensans}>
          <Box className={classes.cardpictures}>
            <Box
              component={Link}
              to="/otherservices"
              className={classes.imageSection}
            >
              <Box className={classes.imageBag}>
                <img className={classes.imageSelf} src={mouseonly} />
              </Box>
              <Box className={classes.secondBag}>
                <Typography className={classes.cardHeader}>
                  Enabling Technology
                </Typography>
                <Typography className={classes.cardText}>
                  We review with deep evaluation tools, their business concern
                  to forecast the characteristics of the main potential impact
                </Typography>
              </Box>
            </Box>
            <Paper
              component={Link}
              to="/otherservices"
              elevation={0}
              className={classes.imageSection}
            >
              <Box className={classes.imageBag}>
                <img className={classes.imageSelf} src={scanner} />
              </Box>
              <Box className={classes.secondBag}>
                <Typography className={classes.cardHeader}>
                  Employee Competence Evaluation
                </Typography>
                <Typography class={classes.cardTextemployee}>
                  Every company needs support especially when it comes to
                  performance improvement, we can help you deliver
                </Typography>
              </Box>
            </Paper>

            <Paper
              component={Link}
              to="/otherservices"
              elevation={0}
              className={classes.imageSection}
            >
              <Box className={classes.imageBag}>
                <img className={classes.imageSelf} src={drone} alt="drone" />
              </Box>
              <Box className={classes.secondBag}>
                <Typography className={classes.cardHeader}>
                  Operation & Efficiency
                </Typography>
                <Typography className={classes.cardText}>
                  Every company needs support especially when it comes to
                  performance improvement, we can help you deliver
                </Typography>
              </Box>
            </Paper>

            <Paper
              component={Link}
              to="/otherservices"
              elevation={0}
              className={classes.imageSection}
            >
              <Box className={classes.imageBag}>
                <img
                  className={classes.imageSelf}
                  src={skyscraper}
                  alt="skyscraper"
                />
              </Box>
              <Box className={classes.secondBag}>
                <Typography className={classes.cardHeader}>
                  Digital Commerce
                </Typography>
                <Typography className={classes.cardText}>
                  Capturing your customers perception of your band and how to
                  create new product using their insight.
                </Typography>
              </Box>
            </Paper>
          </Box>
        </ThemeProvider>
      </Box>

      {/* adherence */}
      <Box className={classes.adherencepart}>
        <ThemeProvider theme={Opensans}>
          <div className={classes.adherencemain}>
            <div className={classes.adherencesubmain}>
              <Typography className={classes.adherenceTopic}>
                We Need a Title Here
              </Typography>
              <Typography className={classes.adherencebold}>
                Adherence to focus while analysing your current process Hurdles
                that preludes your from reaching your desired goals will quickly
                influence your growth
              </Typography>
            </div>
            <div className={classes.normalcont}>
              <Typography className={classes.adherencenormal}>
                The diversity of solution consulting has created innovation for
                business agility with major focus on creating solution for
                market complexity. Our dynamic team of professionals and
                technology experts are available to meet your business needs
              </Typography>
            </div>
          </div>
        </ThemeProvider>
      </Box>

      {/* helmet part */}
      <Box className={classes.helmetpart}>
        <ThemeProvider theme={Opensans}>
          <div className={classes.helmetleft}>
            <ThemeProvider theme={BellMTBold}>
              <Typography className={classes.helmetbold}>
                Creating the adept hub for Business Sportlight
              </Typography>
            </ThemeProvider>
            <ThemeProvider theme={Opensans}>
              <Typography className={classes.helmetnormal}>
                Using the best practices methodology to improve process, we can
                help you cut wastage and stay ahead of competition, The focus is
                to help you deliver significant and measurable change
              </Typography>
            </ThemeProvider>
          </div>

          <div className={classes.helmetright}>
            <ThemeProvider theme={OpensansBold}>
              <Typography className={classes.paragraph}>VS</Typography>
            </ThemeProvider>
            <div className={classes.market}>
              <Typography className={classes.paratext}>
                Market Forces
              </Typography>
              <Typography className={classes.paratext1}>
                Market Insight
              </Typography>
            </div>
          </div>
        </ThemeProvider>
      </Box>
      <Box className={classes.touchpart}>
        <Box className={classes.touchmainOne}>
          <Typography className={classes.touchboldOne}>
            You like to improve your performance?
          </Typography>
        </Box>
        <Box className={classes.touchmainTwo}>
          <Typography className={classes.touchboldTwo}>Get in Touch</Typography>
          <Typography className={classes.touchnormal}>
            and find out how your business can
          </Typography>
          <Typography className={classes.touchnormal2}>
            benefit from our creative space
          </Typography>
          <Link
            component={motion.a}
            animate="animate"
            initial="initial"
            variants={ButtonVariants}
            className={`${classes.linkButton}`}
            to="/contactus"
          >
            <Button
              className={classes.buttonLink}
              endIcon={<ArrowForwardIcon className={classes.fowardIcon} />}
            >
              Lets Talk
            </Button>
          </Link>
        </Box>
      </Box>
      {/* logo part */}

      <FastMarquee speed={40} gradient={true} className={'wrapper'}>
        <img src={mtn} alt={'logo-mtn'} />
        <img src={smile} alt={'logo-smile'} />
        <img src={firstbank} alt={'logo-firstbank'} />
        <img src={sifax} alt={'logo-sifax'} />
        <img src={cargo} alt={'logo-cargo'} />
        <img src={lagos} alt={'logo-lagos'} />
        <img src={towers} alt={'logo-towers'} />
        <img src={police} alt={'logo-police'} />
        <img src={wapic} alt={'logo-wapic'} />
        <img src={mansard} alt={'logo-mansard'} />
        <img src={cdk} alt={'logo-cdk'} />
        <img src={mainone} alt={'logo-mainone'} />
        <img src={arche} alt={'logo-arche'} />
        <img src={airtel} alt={'logo-airtel'} />
        <img src={platform} alt={'logo-platform'} />
      </FastMarquee>

      <Footer />
    </div>
  );
};

export default HomePage;
