import React, { useRef, useState } from 'react';
import NavBar from '../../globals/NavBar';
import Footer from '../../globals/Footer';
import '../../styles/Logopart.css';
import Box from '@material-ui/core/Box';
import { default as FastMarquee } from 'react-fast-marquee';
import { Button, Paper, Typography } from '@material-ui/core';
import { Link } from 'react-router-dom';
import query from '../../asset/images/query.png';
import arrowImage from '../../asset/images/arrowImage.png';
import bigarrow from '../../asset/images/bigarrow.png';
import handRobot from '../../asset/images/handRobot.png';
import plantVase from '../../asset/images/plantVase.png';
import toytrain from '../../asset/images/toytrain.png';
import box from '../../asset/images/box.png';
import mtn from '../../asset/images/mtn.png';
import smile from '../../asset/images/smile.png';
import firstbank from '../../asset/images/firstbank.png';
import sifax from '../../asset/images/sifax.png';
import cargo from '../../asset/images/cargo.png';
import lagos from '../../asset/images/lagos.png';
import towers from '../../asset/images/towers.png';
import police from '../../asset/images/police.png';
import wapic from '../../asset/images/wapic.png';
import mansard from '../../asset/images/mansard.png';
import cdk from '../../asset/images/cdk.png';
import mainone from '../../asset/images/mainone.png';
import arche from '../../asset/images/arche.png';
import airtel from '../../asset/images/airtel.png';
import platform from '../../asset/images/platform.png';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import { motion } from 'framer-motion';

import '../../styles/fonts.css';
import '../../styles/NavBar.css';
import { Solution } from './Solution';
import { useStyles } from './HomeStyles';
import {data} from './solutionData'


const HomePage = () => {
  const classes = useStyles();
  const [dataItem,setDataItem] = useState(data[0]);
  const innerRef = useRef()
  const handleClick = (e) =>{
    innerRef?.current?.scrollIntoView({
      behavior: 'smooth',
    });
    const name = (e.target.getAttribute("data-name"))
    data.find(i=>{if(i.compName===name) setDataItem(i)})
    
  }
  const ButtonVariants = {
    animate: {
      x: [0, -10],
      opacity: 1,
      transition: { yoyo: Infinity, ease: 'easeIn' },
    },
  };

  return (
    <div className={classes.root}>
      <NavBar />
      <div className={classes.bluepart}>
        <img className={classes.queryImage} src={query} alt="query" /> 
        <div className={classes.bluemain}>
          <div className={classes.blueLeft}>
          <div className={classes.heroText}>
          <div className={classes.bluesustain}>
                <Typography >
                  {"Sustainable"}
                </Typography>
                <Typography>
                  {"Business Growth "}
                </Typography>
                </div>
                <div className={classes.bluestrike}>
                <Typography >{"We strike the right chord by exchanging ideas and"}</Typography>
                <Typography>{"connecting minds through partnerships and alliances"}</Typography>
                <Typography>{" to deliver strategic values"}</Typography>
          </div>
          </div>
                </div>
          <div className={classes.blueRight}>
              <Box className={classes.circleImageBox}>
              <Typography>Insight</Typography>
              </Box>
              <Box className={classes.circleImageBox}>
              <Typography>Analysis</Typography>
              </Box>
              <Box className={classes.circleImageBox}>
              <Typography>Reporting</Typography>
              </Box>
          </div>
        </div>
      </div>

      {/* solution-main */}

      <div>
        <Box className={classes.solutionMain} ref={innerRef}>

          <div className={classes.solutionItem}  data-name={"solution"} onClick={handleClick}>
              <Typography data-name={"solution"} className={classes.solutiontext}>
                Solution Engineering
              </Typography>
            <img src={arrowImage}
            data-name="solution"
              alt={'small-arrow'}
            />
          </div>

          <div className={classes.solutionItem} data-name={"technology"} onClick={handleClick}>
              <Typography data-name={"technology"} className={classes.solutiontext}>
                Technology
              </Typography>
            <img
            data-name={"technology"}
              src={arrowImage}
              alt={'small-arrow'}
            />
          </div>

          <div className={classes.solutionItem}  data-name={"operations"}  onClick={handleClick}>
              <Typography className={classes.solutiontext}  data-name={"operations"}>
                Operations
              </Typography>
            <img
              data-name={"operations"}
              src={arrowImage}
              alt={'small-arrow'}
            />
          </div>

          <div className={classes.solutionItem}  data-name={"project"} onClick={handleClick}>
              <Typography  data-name={"project"} className={classes.solutiontext}>Projects</Typography>
            <img
             data-name={"project"}
              src={arrowImage}
              alt={'small-arrow'}
            />
          </div>
        </Box>

      {/* pushing mind limit */}
      <div className={classes.pushPart} >
        <div className={classes.pushMain}>
          <Solution data={dataItem}/>
        </div>
      </div>
      </div>

      {/* enabling part */}
      <Box className={classes.blackpart}>
          <div className={classes.blackmain}>
                <Typography className={classes.blacktext} my={0}>
                  Enabling operational
                </Typography>
                <Typography className={classes.blacktext} my={0}>
                  tenacity for optimum
                </Typography>
              <Link to="/" className={classes.performance}>
                <i>performance</i>
                <img
                  src={bigarrow}
                  className={classes.blackarrow}
                  alt={'big-black-arrow'}
                />
              </Link>
          </div>
      </Box>

      <Box className={classes.fourthSection}>
      {/* strength part */}
      <Box className={classes.strengthpart}>
            <Typography
              className={`${classes.strengthbold}`}
            >
              Strengthening your efforts with collaboration
            </Typography>
            <div className={`${classes.strengthnormal} `}>
              
            <div className ={classes.littlespace}>
            <Typography >
              Every company needs support especially when it comes to
              performance
            </Typography>
            <Typography>
              improvement, we can help you deliver your objective as our model
            </Typography>
            <Typography>
              lower cost and drive efficiency
            </Typography>
            </div>
            </div>
      </Box>

      {/* card part */}
          <Box className={classes.cardpictures}>
            <Box
              component={Link}
              to="/otherservices"
              className={classes.imageSection}
            >
              <Box className={classes.imageBag}>
                <img className={classes.imageSelf} src={handRobot} />
              </Box>
              <Box className={classes.secondBag}>
                <Typography className={classes.cardHeader}>
                  Enabling Technology
                </Typography>
                <Typography className={classes.cardText}>{"We review business concerns with deep evaluation tools, to forecast potential impact..."}
                </Typography>
              </Box>
            </Box>
            <Paper
              component={Link}
              to="/otherservices"
              elevation={0}
              className={classes.imageSection}
            >
              <Box className={classes.imageBag}>
                <img className={classes.imageSelf} src={plantVase} />
              </Box>
              <Box className={classes.secondBag}>
                <Typography className={classes.cardHeader}>
                  Employee Evaluation
                </Typography>
                <Typography className={classes.cardText}>{"We provide excellent human capital evaluation service that allows you better understand your..."}
                </Typography>
              </Box>
            </Paper>

            <Paper
              component={Link}
              to="/otherservices"
              elevation={0}
              className={classes.imageSection}
            >
              <Box className={classes.imageBag}>
                <img className={classes.imageSelf} src={toytrain} alt="toytrain" />
              </Box>
              <Box className={classes.secondBag}>
                <Typography className={classes.cardHeader}>
                  Operation & Efficiency
                </Typography>
                <Typography className={classes.cardText}>{"Every company needs support especially when it comes to performance improvement..."}
                </Typography>
              </Box>
            </Paper>

            <Paper
              component={Link}
              to="/otherservices"
              elevation={0}
              className={classes.imageSection}
            >
              <Box className={classes.imageBag}>
                <img
                  className={classes.imageSelf}
                  src={box}
                  alt="box"
                />
              </Box>
              <Box className={classes.secondBag}>
                <Typography className={classes.cardHeader}>
                  Digital Commerce
                </Typography>
                <Typography className={classes.cardText}>{"Capturing your customers perception of your band and how to create new product using their insight..."}
                </Typography>
              </Box>
            </Paper>
          </Box>

          <Box className={classes.strengthpart}>
            <Typography
              className={`${classes.strengthbold}`}
            >{"Your Business, Our Business"}
            </Typography>
            <div className={`${classes.strengthnormal} `}>
            <div className ={classes.littlespace}>
            <Typography >Focusing on set goals while analyzing current challenges and processes </Typography>
            <Typography >have quick impact on business growth. </Typography>
            </div>
            <Typography> Our dynamic team of management professionals and technology experts </Typography>
            <Typography>are available to proffer diverse solutions and innovations for your</Typography>
            <Typography>business agility thereby resolving your business complexity.</Typography>
            </div>
      </Box>
      </Box>

      {/* helmet part */}
       <Box className={classes.helmetpart}>
          <div className={classes.helmetleft}>
              <Typography className={classes.helmetbold}>
                {"An Adept Hub for Business Spotlight"}
              </Typography>
              <Typography className={classes.helmetnormal}>{"Using the best practices methodology to improve processes, we can help you cut wastage, and stay ahead of competition. The focus is to help you deliver significant and measurable changes."}
              </Typography>
          </div>

          <div className={classes.helmetright}>
              <Typography className={classes.paragraph}>VS</Typography>
            <div className={classes.market}>
              <Typography className={classes.paratext}>
                Market Forces
              </Typography>
              <Typography className={classes.paratext1}>
                Market Insight
              </Typography>
            </div>
          </div>
      </Box>
      <Box className={classes.touchpart}>
        <Box className={classes.touchmainOne}>
          <Typography className={classes.touchboldOne}>
          {"Would You like To Improve Your Performance?"}
          </Typography>
        </Box>
        <Box className={classes.touchmainTwo}>
          <Typography className={classes.touchboldTwo}>Get in Touch</Typography>
          <Typography className={classes.touchnormal}>
            and find out how your business can
          </Typography>
          <Typography className={classes.touchnormal2}>
            benefit from our creative space
          </Typography>
          <Link
            component={motion.a}
            animate="animate"
            initial="initial"
            variants={ButtonVariants}
            className={`${classes.linkButton}`}
            to="/contactus"
          >
            <Button
              className={classes.buttonLink}
              endIcon={<ArrowForwardIcon className={classes.fowardIcon} />}
            >
              Lets Talk
            </Button>
          </Link>
        </Box>
      </Box>

      <FastMarquee speed={40} gradient={true} className={'wrapper'}>
        <img src={mtn} alt={'logo-mtn'} />
        <img src={smile} alt={'logo-smile'} />
        <img src={firstbank} alt={'logo-firstbank'} />
        <img src={sifax} alt={'logo-sifax'} />
        <img src={cargo} alt={'logo-cargo'} />
        <img src={lagos} alt={'logo-lagos'} />
        <img src={towers} alt={'logo-towers'} />
        <img src={police} alt={'logo-police'} />
        <img src={wapic} alt={'logo-wapic'} />
        <img src={mansard} alt={'logo-mansard'} />
        <img src={cdk} alt={'logo-cdk'} />
        <img src={mainone} alt={'logo-mainone'} />
        <img src={arche} alt={'logo-arche'} />
        <img src={airtel} alt={'logo-airtel'} />
        <img src={platform} alt={'logo-platform'} />
      </FastMarquee>

      <Footer />
    </div>
  );
};

export default HomePage;
