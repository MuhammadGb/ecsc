export const data = [{
    compName:"solution",
    head:'Take the Limits off Your Imagination',
    content:{p1:"As a team of best brains with immense insight and experience in management consulting and technology solutions, we deplore creativity, innovation and collaboration to engineer solutions that result in efficiency, growth and the right ROI for your business",p2:""}
},
{
    compName:"technology",
    head:"Building Innovation for Business Process",
    content:{p1:"Digital transformation drives productivity gains alongside industrial automation. We help businesses harness the digital transformation in the modern workplace to boost agility and productivity while driving digital culture through our portfolio of software solutions.",p2:"You can rely on us to create appropriate applications and technology solutions that can be used to manage your business processes and transactions."}
},
{
    compName:"operations",
    head:"People Drive Business Processes -  An Old-age Conundrum",
    content:{p1:"An effective business process can only be driven by people. The people identify when a process is obsolete, outdated or counter-productive. People trigger and enforce changes that take place in a business-process hence the need to ensure a robust process that governs employee management.In order to win a process-driven organization, start with people!",
    p2:"As a team of best thinkers with immense insight & experience in management consulting and technology solution we adapt precise business processes in a way that support people-centric culture resulting in efficiency, growth, and productivity"}
},
{
    compName:"project",
    head:"Achieving More through Synergism",
    content:{p1:"At ECSALLIANCE, we believe in the power of collaboration which helps us achieve and deliver on our various projects, and business interventions thereby causing a direct turnaround and economic growth.",
    p2:"Our reach cuts across both the public and private sectors of the economy. We leverage on both internal and external connections to generate ideas, engineer solutions, and achieve your set goals for your business."
    }
}
]