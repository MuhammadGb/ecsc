import { createTheme, makeStyles } from "@material-ui/core";

import blueback from '../../asset/images/blueback.png';
import brownback from '../../asset/images/brownback.png';
import blackback from '../../asset/images/blackback.png';
import twoHelmets from '../../asset/images/twoHelmets.png';
import inTouchCircle from '../../asset/images/inTouchCircle.png';
import circle from '../../asset/images/circleone.png'
 export const useStyles = makeStyles((theme) => ({
    root: {
      margin: '0',
      padding: '0',
    },
    bluepart: {
      paddingTop:'90px',
      display:'flex',
      backgroundImage: `url(${blueback})`,
      backgroundRepeat: 'no-repeat',
      width: '100%',
      height:'calc(100vh - 90px)',
      backgroundSize:'cover',
      backgroundColor:'black'
    },
    bluemain: {
      width:"100%",
      display: 'flex',
      flexDirection: 'row',
      alignContent: 'center',
      margin: 'auto',
      color: '#fff',
      fontFamily: 'Averta demo',
      '@media screen and (max-device-width:600px)': {
        padding: '0em 0em 7em 0em',
        flexDirection: 'row',
      },
    },
    blueLeft: {
      fontFamily:'Opensans',
      margin:'auto',
    height:'100%',/* 
    '@media only screen and (max-device-width: 600px)': {
      marginLeft: '0.5em',
    }, */
  },
    queryImage: {
      right: '0',
      cursor: 'pointer',
      width: '4.5%',
      padding: '0.2em',
      background: 'rgba(0, 0, 0, 0.3)',
      position: 'fixed',
      marginRight:'4px',
      zIndex: '2',
      border: '2px solid white',
    },
    heroText:{
      width:"100%",
      display:"flex",
      flexDirection:"column"
    },
    bluesustain: {
      paddingBottom:'1.4em',
      "& p":{ fontFamily:'BellMTBold',
      fontSize: '4rem',
      lineHeight:'1em'
    },
    },
    bluestrike: {
      "& p":{fontFamily:'AvertaDemo',
      fontSize: '1.3em',
    }
    },
    blueRight: {
      // [theme.breakpoints.down('sm')]
      width:'50%',
      display: 'flex',
    },
    circleImageBox:{
      width:"174px",
      height:"174px",
      margin:"0 1.5em",
      backgroundSize:"100%",
      backgroundRepeat: 'no-repeat',
      backgroundImage: `url(${circle})`,
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      animation: `$rotate 5s infinite`

    },
    '@keyframes rotat':{
      
      '0%' :{transform:"rotate(0deg)"},
      '100%' :{transform:"rotate(360deg)"},
    },

    solutiontext: {
      color:'#fff',
      fontSize: '1.1em',
      fontFamily: 'Opensanslight',
      fontWeight: '700',
    },
    solutionMain: {
      backgroundColor:'black',
      fontFamily:'AvertaDemo',
      paddingLeft: '6em',
      display: 'flex',
      alignContent: 'center',
      flexDirection: 'row',
    },
    solutionItem: {
      display: 'flex',
      flexDirection: 'row',
      padding: '2.5em 1em',
      cursor: 'pointer',
      '& p':{
        margin:'0 0.4em',
      }
    },
    //stopped from here
    pushPart: {
      backgroundImage: `url(${brownback})`,
      height: '86.5vh',
      backgroundRepeat: 'no-repeat',
      backgroundSize: 'cover',
      width: '100%',
      '@media only screen and (max-device-width: 600px)': {
        backgroundImage: 'none',
        height: '70vh',
      },
    },
    pushMain: {
      backgroundColor: '#fff',
      width: '40%',
      height: '77%',
      position: 'relative',
      paddingLeft: '6em',
      top: '14%',
      paddingRight: '4em',
      paddingTop: '3em',
      '@media only screen and (min-device-width: 1500px)': {
        top: '15.5%',
      },
      '@media only screen and (max-device-width: 600px)': {
        margin: '0 auto',
        justifyContent: 'center',
        paddingTop: '2em',
        position: 'static',
        width: '90%',
        paddingLeft: '0em',
        paddingRight: '0em',
      },
    },
  
    learntext: {
      fontWeight: '700',
      fontFamily: 'Opensanslight',
      fontSize: '0.6em',
    },
    learnarrow: {
      padding: '0em 0.5em',
    },
    pushBold: {
      fontSize: '2.8em',
      fontWeight: '700',
      lineHeight: '1',
      '@media only screen and (max-device-width: 600px)': {
        fontSize: '1.5em',
      },
    },
    learnMore: {
      display: 'flex',
      marginTop: '0.5em',
      textDecoration: 'none',
      justifyContent: 'left',
      alignItems: 'center',
      paddingBottom: '2em',
      fontSize: '1.8em',
      position: 'relative',
      color: '#000',
    },
    pushNormal: {
      fontSize: '1.2em',
      paddingTop: '2.4em',
      fontWeight: '600',
      '@media only screen and (max-device-width: 600px)': {
        fontSize: '0.9em',
      },
      //   lineHeight:'1',
    },
    linktext: {
      fontFamily: Opensans,
    },
    arrow: {
      padding: '0em 2em',
    },
    blackpart: {
        fontFamily:'Opensans',
      backgroundImage: `url(${blackback})`,
      height: '100vh',
      backgroundRepeat: 'no-repeat',
      backgroundSize: 'cover',
      width: '100%',
      color: '#fff',
      '@media only screen and (max-device-width: 600px)': {
        marginTop: '2em',
        height: '50vh',
      },
    },
    blackmain: {
        
        fontFamily:'Opensans',
      paddingTop: '10em',
      paddingLeft: '6em',
      '@media only screen and (max-device-width: 600px)': {
        paddingLeft: '2em',
        paddingTop: '5em',
      },
    },
    performance: {
      fontFamily:'calistItallics',
      display: 'flex',
      marginTop: '0.4em',
      textDecoration: 'none',
      justifyContent: 'left',
      alignItems: 'center',
      paddingBottom: '2em',
      fontSize: '5em',
      color: '#fff',
      '@media only screen and (max-device-width: 600px)': {
        paddingLeft: '0em',
        fontSize: '1.5em',
      },
    },
    blacktext: {
      fontFamily:'BellMTBold',
      fontSize: '5em',
      lineHeight: '1',
      '@media only screen and (max-device-width: 600px)': {
        fontSize: '2em',
      },
    },
    blackarrow: {
      padding: '0em 1em',
      width: '100px',
      '@media only screen and (max-device-width: 600px)': {
        width: '50px',
      },
    },
    //continued here
    fourthSection:{
      display:'flex',
      flexDirection:'column',
      width:'100%',
    },
    strengthpart: {/* 
        fontFamily:'AvertaDemo', */
      paddingBottom:'4em',
      justifyContent: 'center',
      alignItems: 'center',
      textAlign: 'center',
    },
    strengthbold: {
      fontSize: '2.2em',
      fontWeight: 'bold',
      fontFamily: 'BellMT',
      lineHeight: '1.1',
    },
    littlespace:{
        margin:'1em 0'
      },
    strengthnormal: {
      '& p':{
      fontSize: '1.34em',
      fontWeight:'400'
      },
      
    },
    strengthmain: {
      marginTop: '3em',
      marginBottom: '3em',
    },
  
    cardpictures: {
      fontFamily:'Opensans',
      padding:'4em 0',
      paddingBottom:'3em',
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'center',
      gap:'1em',
      alignContent: 'center',
      [theme.breakpoints.down('sm')]: {
        display: 'block',
        padding: '0 1em',
        width: '100%',
      },
    },
    imageSection: {
      display: 'flex',
      flexDirection: 'column',
      margin: '0em 0.5em',
      textDecoration: 'none',
      width: '18%',
      color: '#354054 !important',
      [theme.breakpoints.down('sm')]: {
        // display:'block',
        width: '70%',
        margin: '0.9em 0.5em',
      },
    },
    imageBag: {
      width: '100%',
      height: '43%',
    },
    imageSelf: {
      width: '100%',
      height: '100%',
    },
    secondBag: {
      marginTop: '0.5em',
    },
    cardHeader: {
      fontSize: '1.5em',
      fontWeight: '700',
      fontFamily: 'Opensanslight',
      width: '100%',
    },
    cardText: {
      marginTop: '1em',
      fontWeight: '500',
      fontSize: '1em',
      textDecoration: 'none',
    },

    lowertext: {
      fontSize: '1.5em',
    },
    helmetpart: {
      display: 'flex',
      flexDirection: 'row',
      width: '100%',
      justifyContent: 'center',
      alignContent: 'center',
      color: '#fff',
      padding: '0em 0em',
      '@media only screen and (max-device-width: 600px)': {
        display: 'block',
      },
    },
    helmetleft: {
        fontFamily:'BellMTBold',
      backgroundColor: '#013B4F',
      padding: '0em 4em 0em 0em',
      width: '50%',
      height: '21em',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-end',
      justifyContent: 'center',
      zIndex: 2,
      marginBottom: '-0.2em',
      marginRight: '-0.2em',
      '@media only screen and (max-device-width: 600px)': {
        width: '92%',
        height: '44vh',
        padding: '2em 1em 1em 1em',
        margin: '0 auto',
        justifyContent: 'center',
      },
    },
    helmetbold: {
      fontFamily: 'BellMT',
      fontSize: '2.8em',
      lineHeight: '1',
      textAlign: 'left',
      width: '85%',
      '@media only screen and (max-device-width: 600px)': {
        fontSize: '1em',
      },
    },
    helmetnormal: {
        fontFamily:'Opensans',
      fontSize: '1.2em',
      textAlign: 'left',
      fontWeight: 'light',
      marginTop: '2.5em',
      width: '85%',
    },
    helmetright: {
        fontFamily:'OpensansBold',
      padding: '0',
      backgroundImage: `url(${twoHelmets})`,
      width: '50%',
      zIndex: 1,
      height: '21em',
      backgroundRepeat: 'no-repeat',
      marginBottom: '-0.2em',
      backgroundSize: 'cover',
      '@media only screen and (max-device-width: 600px)': {
        display: 'none',
      },
    },
    market: {
      display: 'flex',
      flexDirection: 'row',
      margin: '0 auto',
      justifyContent: 'space-between',
      padding: '0em 0em 0em 0em',
      fontSize: '1.5em',
      marginTop: '4em',
      width: '90%',
      '@media only screen and (min-device-width: 1500px)': {
        marginTop: '5em',
      },
    },
    paragraph: {
      marginRight: '0.5em',
      textAlign: 'center',
      paddingTop: '5em',
      fontSize: '1.5em',
    },
    paratext: {
      fontSize: '1em',
      fontFamily: 'Opensanslight',
      fontWeight: '700',
      position: 'relative',
      left: '2em',
      '@media only screen and (max-device-width: 1380px)': {
        fontSize: '0.9em',
        marginLeft: '1em',
      },
    },
    paratext1: {
      fontSize: '1em',
      position: 'relative',
      fontFamily: 'Opensanslight',
      fontWeight: '700',
      left: '-2em',
      '@media only screen and (max-device-width: 1380px)': {
        fontSize: '0.9em',
      },
    },
    helmetimg: {
      padding: '0',
      margin: '0',
    },
    logopart: {},
    logomain: {
      marginTop: '2em',
    },
    touchpart: {
      marginTop: '0em',
      display: 'flex',
      flexDirection: 'row',
      alignItems: 'center',
      paddingBottom: '5em',
      zIndex: -1,
      height: '14em',
      backgroundImage: `url(${inTouchCircle})`,
      backgroundRepeat: 'no-repeat',
      backgroundSize: 'cover',
      color: '#fff',
      padding: '7em 0em',
      '@media only screen and (max-device-width: 600px)': {
        justifyContent: 'left',
        alignItems: 'left',
        textAlign: 'left',
        margin: '0',
        padding: '4em 0em 2em 0em',
      },
    },
    touchmainOne: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      width: '53%',
    },
    touchmainTwo: {
      display: 'flex',
      flexDirection: 'column',
      width: '47%',
      '@media only screen and (max-device-width: 600px)': {
        //    marginLeft:'1em',
      },
    },
    touchboldOne: {
      fontSize: '2.5em',
      width: '70%',
      fontFamily: 'Leaguespartanbold',
      lineHeight: '1.1em',
    },
    touchboldTwo: {
      fontSize: '2.5em',
      textAlign: 'left',
      fontFamily: 'Leaguespartanbold',
      position: 'relative',
      color: '#2E324B',
      width: '70%',
      left: '13%',
    },
    touchnormal: {
      fontSize: '1.25em',
      textAlign: 'left',
      position: 'relative',
      fontFamily: 'Opensanslight',
      fontWeight: 700,
      color: '#2E324B',
      left: '8%',
      width: '70%',
      '@media only screen and (max-device-width: 600px)': {
        margin: '0',
        fontSize: '1.3em',
      },
    },
    touchnormal2: {
      fontSize: '1.25em',
      color: '#2E324B',
      fontFamily: 'Opensanslight',
      fontWeight: 700,
      position: 'relative',
      left: '11%',
      width: '70%',
      '@media only screen and (max-device-width: 600px)': {
        margin: '0',
        fontSize: '1.3em',
      },
    },
    linkButton: {
      marginTop: '4em',
      padding: '0em',
      width: '27%',
      textDecoration: 'none',
      borderRadius: '2.5em',
      position: 'relative',
      left: '18%',
      background: 'white',
      cursor: 'pointer',
    },
    buttonLink: {
      fontFamily: 'Opensanslight',
      textTransform: 'none',
      fontWeight: '900 ',
      fontSize: '1.3em',
      paddingLeft: '1.1em',
      borderRadius: '1.5em',
    },
    fowardIcon: {
      border: '3px solid #2E324B',
      color: '#2E324B',
      borderRadius: '1em',
      marginLeft: '0em',
      position: 'relative',
      left: '0.35em',
      fontSize: '1.5em !important',
      '@media only screen and (max-device-width: 1300px)': {
        left: '1em',
      },
    },
  }));
  
  const Opensans = createTheme({
    typography: {
      fontFamily: ['Opensanslight'].join(','),
    },
  });
  