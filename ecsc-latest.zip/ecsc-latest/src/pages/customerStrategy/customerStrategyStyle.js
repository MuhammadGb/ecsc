
import { makeStyles } from '@material-ui/styles';

const brown_moon = '../../asset/images/brown_moon.png'
const ball = '../../asset/images/ball.png'
export default makeStyles((theme) => ({
    root:{
        margin:'0',
        padding:'0',
    },
    firstmain:{
        width:'100%',
        margin:'0 auto',
        alignContent:'center',
        textAlign:'center',
        justifyContent:'center',
        marginTop:"90px",
        backgroundColor:'#fafafa'
    },
    blankspace:{
        height:'1.2em',
        margin:'0px',
        backgroundColor:'#fafafa',
    },  
    underline:{
        height: '0.35rem',
        width: '5rem',
        margin:'5em auto',
        marginTop:'0',
        position:'relative',
        backgroundColor:'#2E324B',
       
    },
    
    market:{
        marginTop:'3em',
        color:'#2E324B'
    },
    marketbold:{
        fontFamily:"geometric",
        fontSize:'7em',
        fontWeight:'bolder',
        acHeight:'1',
        lineHeight:'1'
    },
    marketnormal:{
        fontFamily:"AvertaDemo",
        fontWeight:'500',
        fontSize:'1.5em',
    },
    marketnormaldiv:{
        marginTop:'2em',
    },
    moreunderline:{
        height: '0.35rem',
        width: '10rem',
        margin:'3em auto ',
        
        backgroundColor:'#2E324B',
    },
    purplepart:{
        backgroundColor:'#2E324B',
        height:'6em',
        width:'100%',
    },
   
    // second section
    secondMain:{
        width:'100%',
        margin:'0 auto',
        alignContent:'center',
        textAlign:'center',
        justifyContent:'center',
        paddingTop:'7em',
    },
    customerbold:{
      '& p':{ fontSize:'3em',
        lineHeight:'1',
        fontFamily:'bellMTBold',
        fontWeight:'bolder',
    }
    },
    customernormal:{
        padding:'2em',
        '& p':{ 
        fontSize:'1.em',
        fontWeight:'bolder',
        fontFamily:'opensans',
        }
    },
    iconmain:{
        display:'flex',
        justifyContent:'center',
        paddingBottom:'6em'
    },
    column:{
        display:'flex',
        justifyContent:'space-evenly',
        alignContent:'center',
        flexDirection:'column',
    },
    iconpart:{
        display:'flex',
        marginTop:'2em',
        flexDirection: 'row',
        padding:'1em',
    },
    iconimage:{
        maxHeight:'80px',
        paddingTop:'1em'
    },
    icontext:{
        paddingLeft:'2em',
    },
//third
    specialeffect:{
        marginTop:'4em',
        
        fontFamily:'bellMTBold',
    },
    
    texttop:{
        display:'flex',
        flexDirection:'row',
        justifyContent:'space-around',
        width:'100%',
        padding:'2em 0em 0em 0em',
        margin:'0 auto',
        alignContent:'center',
    },
    effectleft:{
        fontSize:'2em',
    },
    
    sellingtext:{
        fontSize:'2.9em',
        lineHeight:'1',
    },
    effectright:{
        paddingTop:'12em',
    },
    effecttext:{
        margin:'0 auto',
        width:'100%',
    },
    effectunderline:{
        height: '0.25rem',
        width: '8rem',
        background: 'black',
        // margin:'10em auto 0 auto',
    },
    lefttext:{
        lineHeight:'0.7',
        fontSize:'1.8em',
        marginTop:'-1em',
    },
    spantext:{
        fontSize:'2.1em',
        lineHeight:'1',
        marginTop:'-20em',
    },
    leftmiddle:{
        display:'flex',
        flexDirection:'row',
        width:'100%',  
    },
    middletext:{
        fontSize:'2em',
    },
 bigtext:{
        fontSize:'5em',
        marginTop:'-0.45em',
    },
    //4th part
   
    secondmiddle:{
        fontSize:'2em',
        marginTop:'-0.9em',
    },
    bigsecond:{
        fontSize:"4.5em",
        marginTop:'-0.7em',
    },
    growthtext:{    
        fontSize:'3.5em',
        lineHeight:'0',
        backgroundColor:'red',
    },
    effectimage:{
        marginLeft:'3em',
    },
    effectdown:{
        textAlign:'right',
        fontFamily:'Opensanslight',
        padding:'5em 10em'
    },
    cartoonunderline:{
        height: '0.5rem',
        width: '8rem',
        background: 'black',
        marginTop:'6em',
    },
    simpletop:{
        display:'flex',
        flexDirection:'row',
        paddingLeft:'10em',
    },
    simple:{
        marginTop:'3em 0',
    },
    simpletext:{
        fontSize:'6em',
    },
    cartoon:{
        display:'flex',
        flexDirection:'row',
        justifyContent:"space-evenly",
        width:'100%',
        height:'50vh',
    },
    cartoontext:{
       '& p':{
        textAlign:'center',
        fontSize:'1.5em',
        fontWeight:'500',
       }
    },
    cartoonImg:{
        maxWidth:'100%',
        objectFit:'cover'
    },
    quality:{
        padding:"3em 0em 8em 0em",
    },
    qualitytext:{
        fontSize:'4em',
       
    },
    qualitytop:{
        display:'flex',
        flexDirection:'row',
        marginRight:'5em',
        justifyContent:'right',
    },
    qualityunderline:{
        height: '0.5rem',
        width: '10rem',
        background: 'black',
        marginRight:'1em',
        
    },
    tennisball:{
        height:'90vh',
        backgroundImage: `url(${ball})`,
        backgroundRepeat:'no-repeat',
        backgroundSize: 'cover',
        width:'100%',
    },
    blackbox:{
        backgroundColor:'#000',
        width:'30%',
        position:'absolute',
        marginTop:'4.5em',
        paddingLeft:'4em',
        paddingRight:'4em',
        paddingTop:'3em',
        height:"60vh",
        opacity: '0.5',
        marginLeft:'3em',
    },
    touchpart:{
        marginTop:'0.1em',
        justifyContent:"center",
        alignItems:"center",
        textAlign:'center',
        paddingBottom:'5em',
        backgroundImage: `url(${brown_moon})`,
        backgroundRepeat:'no-repeat',
        backgroundSize: 'cover',
        width:'100%',
        color:'#fff',
        padding:'7em 0em',
    },
    touchbold:{
        fontSize:'3em',
        marginRight:'2em',
    },
    touchnormal:{
        fontSize:'2em',
        marginRight:'9em',
    },
    touchnormal2:{
        fontSize:'2em',
        marginRight:'3em',
    },
    touchlink:{
        display:'flex',
        textDecoration: 'none',
        justifyContent:'right',
        alignItems:'center',
        color:'#013B4F',
        backgroundColor:'#FAFAFA',
        width:'12%',
        marginLeft:'54em',
        height:'6vh',
        borderRadius:'40px',
        padding:'0.5em',
        marginTop:'2em',
    },
    touchlinktext:{
        fontSize:'1.5em',
         
    },
    toucharrow:{
        paddingLeft:'0em',
        paddingRight:'0.5em',
        marginLeft:'1em'
    }
}));
