import React from 'react'
import Footer from '../../globals/Footer'
import Box from '@material-ui/core/Box';
import { ThemeProvider, createTheme } from '@material-ui/core/styles';
import {
    Paper,
    Typography,
} from '@material-ui/core';

import { Link } from 'react-router-dom';
import { Parallax } from 'react-parallax';
import tennisbat from '../../asset/images/tennisbat.png'
import square from '../../asset/images/square.png'
import crown from '../../asset/images/crown.png'
import star from '../../asset/images/star.png'
import people from '../../asset/images/people.png'
import downarrow from '../../asset/images/downarrow.png'
import running from '../../asset/images/running.png'
import running2 from '../../asset/images/running2.png'
import middlearrow from '../../asset/images/middlearrow.png'

import '../../styles/fonts.css'
import NavBar from '../../globals/NavBar';
import useStyles from './customerStrategyStyle'
  
const AvertaDemo = createTheme({
    typography: {
      fontFamily: ['AvertaDemo'].join(','),
    },
});
const BellMTBold = createTheme({
    typography: {
      fontFamily: ['BellMTBold'].join(','),
    },
});



 const CustomerSatisfaction = () => {

    const classes = useStyles();
    return (
        <div className={classes.root}>
                <NavBar page={'customerStrategy'}/>
                <Paper elevation={0}>
                    <Box className={classes.firstmain }>
                        <div className={classes.blankspace}/>
                        <div className={classes.underline}/>
                        <div className={classes.market}>
                            <Typography className={classes.marketbold}>{"Market Intelligence"}</Typography>
                            <Typography className={classes.marketbold}>{"& Insight"}</Typography>
                        </div>

                        <div className={classes.marketnormaldiv}>
                            <Typography className={classes.marketnormal}>We Help create influential insights about your customers in order to identify</Typography>
                            <Typography className={classes.marketnormal}>attractive segments to focus on your go-to-market strategy</Typography>
                        </div>
                        <div className={classes.moreunderline}></div>
                        <div className={classes.purplepart}/>
                    </Box>

                <Box className={classes.secondMain}>
                    <Box className={classes.customerbold}>
                        <Typography >{"Customer innovation driven"}</Typography>
                        <Typography >{"through insight"}</Typography>
                    </Box>
                    <Box className={classes.customernormal}>
                        <Typography >{"Giving insight to your customers DNA to enable you segment correctly and allocate"}</Typography>
                        <Typography>{"resources more efficiently for a workable marketing plan."}</Typography>
                    </Box>
                </Box>

            <Box className={classes.iconmain}>
                <div className={`${classes.column} firstColumn`}>
                    <div className={classes.iconpart}>
                        <img src={tennisbat} alt={"tennis-bat"} className={classes.iconimage}/>
                        <div className={classes.icontext}>
                                <Typography className={classes.iconbold}>{"Market Insight"}</Typography>
                                <Typography>{"Creating a more functioning tool that"}</Typography>
                                <Typography>{"drives the right marketing plan, amend"}</Typography>
                                <Typography>{" the existing plan and explore the future"}</Typography>
                                <Typography >{"to create a niche."}</Typography>
                               
                        </div>
                    </div>

                    <div className={classes.iconpart}>
                            <img src={crown} alt={"crown-iconpart"} className={classes.iconimage}/>
                            <div className={classes.icontext}>
                                    <Typography className={classes.iconbold}>Loyalty Program</Typography>
                                    <Typography >Build a strong brand customer relationship</Typography>
                                    <Typography>where the customers have a sense of ownership</Typography>
                                    <Typography>or are seen as partners to the brand.</Typography>
                             
                            </div>
                        </div>
                  
                    
                </div>

                <div className={`${classes.column} firstColumn`}>
                <div className={classes.iconpart}>
                        <img src={square} alt={"square-iconpart"} className={classes.iconimage}/>
                        <div className={classes.icontext}>
                                <Typography className={classes.iconbold}>Market Plan</Typography>
                                <Typography>Adopting the right road map for a </Typography>
                                <Typography>marketing plan for sustainable</Typography>
                                <Typography >business.</Typography>
                        </div>
                    </div>
                        
                        <div className={classes.iconpart}>
                            <img src={star} alt={"star-iconpart"} className={classes.iconimage}/>
                            <div className={classes.icontext}>
                                    <Typography className={classes.iconbold}>Customer Experience</Typography>
                                    <Typography >Walking through customer experiences</Typography>
                                    <Typography>simulation to develop strong connections</Typography>
                                    <Typography>with your brand and encourage buy-agains.</Typography>
                            </div>
                        </div>
                
                        
                </div>
            </Box>
            
            <Parallax bgImage={people} strength={800}>
                <Box className={classes.specialeffect}>
                    <div className={classes.texttop}>
                            <div className={classes.effectleft}>
                                <Typography className={classes.sellingtext}>Selling</Typography>
                                  <Box className={classes.leftmiddle}>
                                    <Typography className={classes.middletext}>your </Typography>
                                    <Typography className={classes.bigtext}>brand </Typography>
                                    <Typography className={classes.middletext}>right </Typography>
                                </Box>
                                <Box className={classes.leftmiddle}>
                                    <Typography className={classes.secondmiddle}>bring </Typography>
                                    <Typography className={classes.bigsecond}>incessant</Typography>
                                   
                                </Box>
                                
                                <Typography className={classes.growthtext}> Growth</Typography>
                            </div>
                            <div className={classes.effectright}>
                                <img src={downarrow} alt={"downarrow-effect"} className={classes.effectimage}/>
                                <div className={classes.moreunderline}></div>

                            </div>
                           
                    </div>
                    <div className={classes.effectdown}>
                                    <Typography>{"Customised services and fulfilling your promise will"}</Typography>
                                    <Typography >{"attract more customers to you than the known brand"}</Typography>
                                    <Typography>{"that sell generic services. The touch point for business"}</Typography>
                                    <Typography>{"success is customer satisfaction through viable pricing "}</Typography>
                                    <Typography >{"option to suit each customer need, prioritized value"}</Typography>
                                    <Typography>{"preposition and continous change to meet change in"}</Typography>
                                    <Typography>{"customers demand."}</Typography>
                               
                        </div>
                </Box>
            </Parallax>

            <Box className={classes.simple}>
                <div className={classes.simpletop}>
                    <div>
                    <Typography className={classes.simpletext}>You </Typography>
                    </div>
                    <div className={classes.cartoonunderline}>

                    </div>
                </div>

            <Box className={classes.cartoon}>
                        <img src={running} alt={"running-cartoon"}  className={classes.cartoonImg}/>
                    <div className={classes.cartoontext}>
                            <Typography >A better customer satisfaction is shared</Typography>
                            <Typography>among few people, but a bad experience travels</Typography>
                            <Typography>at the speed of light......Reaching the customer</Typography>
                            <Typography>on time with their need targets the opportunity</Typography>
                            <Typography>for growth</Typography>
                        
                    </div>
                    <div>
                        <img src={running2} alt={"running-cartoon"} className={classes.cartoonImg}/>
                    </div>
            </Box>

            <Box className={classes.quality} >
                <div className={classes.qualitytop}>

                    <div className={classes.qualityunderline}>
                    </div>
                    <div>
                        <Typography className={classes.qualitytext}>Quality Customer Review</Typography>
                    </div>
                </div>
            </Box>
            
            <Box className={classes.tennisball}>
                <div className={classes.blackbox}>

                </div>

            </Box>

            </Box>
            <Box className={classes.touchpart}>
                <ThemeProvider theme={AvertaDemo}>
                <div className={classes.touchmain}>
                   <ThemeProvider theme={BellMTBold}>
                        <Typography className={classes.touchbold}>Get in Touch</Typography>
                    </ThemeProvider>
                     <ThemeProvider theme={AvertaDemo}>
                        <Typography className={classes.touchnormal}>and find out how your business</Typography>
                        <Typography className={classes.touchnormal2}>can benefit from our creative space</Typography>
                    </ThemeProvider>
                    <Link to='/' className={classes.touchlink}>
                    <ThemeProvider theme={AvertaDemo}>
                        <Typography><a href="/" className={classes.touchlinktext}>Lets Talk</a></Typography> 
                    </ThemeProvider>
                        <img src={middlearrow} alt={"middlearrow-avertar"} className={classes.toucharrow}/>
                    </Link>
                
                </div>
            </ThemeProvider>
            
            </Box>
            <Footer/>
</Paper>
        </div>
    )
}

export default CustomerSatisfaction