import React from 'react';
import Box from '@material-ui/core/Box';
import { makeStyles } from '@material-ui/styles';
import { Button, Divider, Icon, Typography } from '@material-ui/core';
import query from '../asset/images/query.png';
import bare_arrow from '../asset/images/bare_arrow.png';
import colored_bricks from '../asset/images/colored_bricks.png';
import half_filled from '../asset/images/half_filled.png';
import map_sketch from '../asset/images/map_sketch.png';
import speed_rail from '../asset/images/speed_rail.png';
import tin_can from '../asset/images/tin_can.png';
import arrow_light from '../asset/images/arrow_light.png';
import dark_arrow from '../asset/images/dark_arrow.png';
import NavBar from '../globals/NavBar';
import Footer from '../globals/Footer';

const useStyles = makeStyles((theme) => ({
  column: {
    display: 'flex',
    flexDirection: 'column',
  },
  row: {
    display: 'flex',
    flexDirection: 'row',
  },
  leftMain: {
    backgroundColor: '#020820',
  },
  firstSection: {
    height: '35em',
    backgroundColor: '#020820',
    color: 'white',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  dividerMain: {
    backgroundColor: 'gray',
    width: '0.15em',
    height: '95.5%',
    marginTop: '9em',
    position: 'relative',
    left: '15em',
  },
  textAreaOne: {
    width: '50%',
    position: 'relative',
    left: '-24%',
  },
  textAreaHeader: {
    fontSize: '3em',
    fontWeight: '500',
    lineHeight: '1.2em',
    width: '70%',
    textAlign: 'left',
    marginBottom: '0.3em',
  },
  textAreaSentence: {
    fontSize: '1.2em',
    width: '85%',
  },
  arrow_light: {
    position: 'relative',
    left: '6em',
    top: '12em',
  },
  query: {
    position: 'fixed',
    right: '0%',
    top: '26%',
    padding: '0.4em',
    width: '4.5%',
    height: '8%',
    cursor: 'pointer',
    background: 'rgba(0, 0, 0, 0.3)',
    zIndex: '1',
    border: '2px solid whitesmoke',
    borderRight: '0px',
  },
  secondSection: {
    height: '50em',
    color: '#020820',
    justifyContent: 'center',
    backgroundImage: `url(${map_sketch})`,
    backgroundSize: 'cover',
    backgroundRepeat: 'no-repeat',
  },
  darkarrow: {
    position: 'relative',
    left: '-5%',
    top: '85%',
  },
  textAreaSecond: {
    alignItems: 'flex-end',
    justifyContent: 'center',
  },
  dividerSubTwo: {
    backgroundColor: '#020820',
    width: '15%',
    height: '0.3em',
    marginTop: '-5em',
    position: 'relative',
    left: '0em',
  },
  secondTexts: {
    width: '55%',
    marginBottom: '3em',
    alignItems: 'flex-end',
    justifyContent: 'flex-end',
  },
  secondTxtHeader: {
    fontSize: '3em',
    textAlign: 'right',
    width: '85%',
  },
  secondTxtSentence: {
    fontSize: '1.2em',
    textAlign: 'right',
    width: '95%',
  },
  secondImages: {
    alignItems: 'space-between',
    justifyContent: 'space-between',
    width: '85%',
  },
  imageHeader: {
    fontSize: '1em',
    fontWeight: '700',
    marginTop: '1em',
  },
  imageSentence: {
    fontSize: '1.3em',
    marginTop: '0.5em',
  },
  secImg: {
    width: '30%',
    height: '100%',
    backgroundColor: 'whitesmoke',
  },
  secImages: {
    width: '100%',
  },
  half_filled: {
    width: '100%',
  },
  colored_bricks: {
    width: '100%',
  },
  speed_rail: {
    width: '100%',
  },
  thirdSection: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F6F8FA',
    height: '45em',
  },
  thirdTexts: {
    width: '50%',
  },
  thirdTextSubHead: {
    fontSize: '1em',
    marginTop: '1.5em',
    marginBottom: '1em',
    fontWeight: '700',
  },
  thirdTextHead: {
    fontSize: '3em',
    marginBottom: '1em',
    fontWeight: '700',
  },
  thirdTextSentence: {
    fontSize: '1.2em',
    marginBottom: '2em',
    fontFamily: 'Opensanslight',
    fontWeight: '700',
  },
  darkarrowTwo: {
    position: 'relative',
    left: '-40%',
    top: '5%',
    marginBottom: '1em',
  },
  fourthSection: {
    backgroundColor: '#020820',
    color: 'white',
    height: '45em',
  },
  arrowTwoLight: {
    width: '5%',
    margin: 'auto auto',
    position: 'relative',
    top: '35%',
    left: '7%',
  },
  fourthText: {
    alignItems: 'flex-end',
    width: '50%',
    justifyContent: 'center',
    paddingRight: '9em',
  },
  fourthTextSubHead: {
    fontSize: '1.5em',
    marginBottom: '1em',
    marginTop: '5em',
  },
  dividerSubThree: {
    backgroundColor: 'white',
    width: '15%',
    height: '0.3em',
    marginBottom: '1.5em',
  },
  fourthTextHead: {
    fontSize: '4em',
    textAlign: 'right',
    width: '55%',
    marginBottom: '1.1em',
    lineHeight: '1.2em',
    color: '#FFD700	',
  },
  fourthSentence: {
    fontSize: '1.2em',
    textAlign: 'right',
    marginBottom: '1em',
    width: '60%',
  },
  buttonFourth: {
    color: 'white',
    textTransform: 'none',
    border: '2px solid white',
    borderRadius: '1em',
    fontSize: '1.5em',
    marginTop: '3em',
    marginBottom: '6em',
  },
  tinCanBox: {
    width: '45%',
  },
  tinCan: {
    width: '100%',
    height: '100%',
  },
  fifthSection: {
    justifyContent: 'center',
    alignItems: 'center',
    background: '#F6F8FA',
    paddingTop: '4em',
    paddingBottom: '1em',
  },
  innerFifth: {
    alignItems: 'flex-start',
    width: '55%',
    marginLeft: '5em',
  },
  fifthSubHead: {
    fontSize: '1.5em',
    marginBottom: '1em',
  },
  fifthHeader: {
    fontSize: '3.5em',
    marginBottom: '1em',
    fontWeight: '700',
  },
  fifthSentence: {
    fontSize: '1.2em',
    marginBottom: '2em',
    fontWeight: '700',
    fontFamily: 'Opensanslight',
  },
}));
const FeaturedInsight = () => {
  const classes = useStyles();
  return (
    <Box className={`${classes.column}`}>
      <NavBar />
      <Box className={`${classes.main} ${classes.row}`}>
        <Box className={classes.leftMain}>
          <Divider className={classes.dividerMain} orientation="vertical" />
        </Box>
        <Box className={classes.rightMain}>
          <Box className={`${classes.firstSection} ${classes.row}`}>
            <Box className={classes.arrow_light}>
              <img
                className={classes.arrow_light_img}
                src={arrow_light}
                alt="arrow_light"
              />
            </Box>
            <Box className={classes.textAreaOne}>
              <Typography className={classes.textAreaHeader}>
                Having your sights on the Horizon
              </Typography>
              <Typography className={classes.textAreaSentence}>
                Gracing on today's tides towards tomorrow's shores, the future
                holds treasure for brave thinkers equipped with fresh updates
              </Typography>
            </Box>
            <img className={classes.query} src={query} alt="query" />
          </Box>
          <Box className={[classes.secondSection, classes.row]}>
            <Box className={classes.darkarrow}>
              <img
                className={classes.dark_arrow}
                src={dark_arrow}
                alt="arrow_light"
              />
            </Box>
            <Box className={[classes.textAreaSecond, classes.column]}>
              <Divider
                className={classes.dividerSubTwo}
                orientation="horizontal"
              />
              <Box className={[classes.secondTexts, classes.column]}>
                <Typography className={classes.secondTxtHeader}>
                  Tomorrow Mindset
                </Typography>
                <Typography className={classes.secondTxtSentence}>
                  Matching responsive thinking with possible paradigm shifts we
                  can anticipate trends to form better communities
                </Typography>
              </Box>
              <Box className={[classes.secondImages, classes.row]}>
                <Box className={[classes.column, classes.secImg]}>
                  <Box className={classes.secImages}>
                    <img
                      className={classes.half_filled}
                      src={half_filled}
                      alt="half_filled"
                    />
                  </Box>
                  <Typography className={classes.imageHeader}>
                    Customer Care
                  </Typography>
                  <Typography className={classes.imageSentence}>
                    An improved public Perception
                  </Typography>
                </Box>
                <Box className={[classes.column, classes.secImg]}>
                  <Box className={classes.secImages}>
                    <img
                      className={classes.colored_bricks}
                      src={colored_bricks}
                      alt="colored_bricks"
                    />
                  </Box>
                  <Typography className={classes.imageHeader}>
                    Insight into how we work
                  </Typography>
                  <Typography className={classes.imageSentence}>
                    Changing the way we work
                  </Typography>
                </Box>
                <Box className={[classes.column, classes.secImg]}>
                  <Box className={classes.secImages}>
                    <img
                      className={classes.speed_rail}
                      src={speed_rail}
                      alt="speed_rail"
                    />
                  </Box>
                  <Typography className={classes.imageHeader}>
                    Oil & Gas
                  </Typography>
                  <Typography className={classes.imageSentence}>
                    Energy Transitions and Their Challenges
                  </Typography>
                </Box>
              </Box>
            </Box>
          </Box>
          <Box className={[classes.thirdSection, classes.column]}>
            <Box className={[classes.thirdTexts, classes.column]}>
              <Typography className={classes.thirdTextSubHead}>
                Insight into how we work
              </Typography>
              <Typography className={classes.thirdTextHead}>
                Change in the way we work
              </Typography>
              <Typography className={classes.thirdTextSentence}>
                What comes to mind every morning, your goal I guess if not then
                what? Fulfilment at work is driven majorly by passion; result
                oriented task fulfils the organisational plan as coming to work
                to drive the everyday task continue to give the same result.
                Would give couple of hours of dedication to work while at house
                pose a better result than sowing up at work for 8 hours with
                without nothing to show for it.
              </Typography>
              <Typography className={classes.thirdTextSentence}>
                What direction do we go and why? Thinking the hybrid way of work
                might just pose a better solution.
              </Typography>
            </Box>
            <Box className={classes.darkarrowTwo}>
              <img
                className={classes.dark_arrow_two}
                src={dark_arrow}
                alt="arrow_light"
              />
            </Box>
          </Box>
          <Box className={`${classes.fourthSection} ${classes.row}`}>
            <Box className={classes.arrowTwoLight}>
              <img
                className={classes.arrow_light_img}
                src={arrow_light}
                alt="arrow_light"
              />
            </Box>
            <Box className={[classes.column, classes.fourthText]}>
              <Typography className={classes.fourthTextSubHead}>
                Finances
              </Typography>
              <Divider
                className={classes.dividerSubThree}
                orientation="horizontal"
              />
              <Typography className={classes.fourthTextHead}>
                Obsolete Financial Vehicles
              </Typography>
              <Typography className={classes.fourthSentence}>
                Finding out what used to work does not work anymore within the
                fintech space
              </Typography>
              <Button className={classes.buttonFourth} variant="outlined">
                Read More
              </Button>
            </Box>
            <Box className={classes.tinCanBox}>
              <img className={classes.tinCan} src={tin_can} alt="tin_can" />
            </Box>
          </Box>
          <Box className={`${classes.fifthSection} ${classes.column}`}>
            <Box className={`${classes.innerFifth} ${classes.column}`}>
              <Typography className={classes.fifthSubHead}>
                Insight into how we work
              </Typography>
              <Typography className={classes.fifthHeader}>
                Performance Insight
              </Typography>
              <Typography className={classes.fifthSentence}>
                Our insight share how the effectiveness of an organization is
                always relative to the current context of operation and approach
                needed in strategies, processes, attitude, leadership, culture
                in trade to create a smarter and more sustainable intervention
                required to proffer solutions.
              </Typography>
              <Typography className={classes.fifthSentence}>
                Companies must innovate and transform from their usual ways of
                doing business to attract incessant growth. It is critical for
                organizations to be ready and capable of adapting to changing
                times to ensure business survival in a constantly evolving
                market for business success.
              </Typography>
            </Box>
            <Box className={classes.darkarrowTwo}>
              <img
                className={classes.dark_arrow_two}
                src={dark_arrow}
                alt="arrow_light"
              />
            </Box>
          </Box>
        </Box>
      </Box>
      <Box>
        <Footer />
      </Box>
    </Box>
  );
};

export default FeaturedInsight;
