import React from 'react';
import Box from '@material-ui/core/Box';
import { makeStyles } from '@material-ui/styles';
import NavBar from '../globals/NavBar';
import query from '../asset/images/query.png';
import { ThemeProvider, createTheme } from '@material-ui/core/styles';
import { Button, Divider, Icon, Typography } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import half_blue_moon from '../asset/images/half_blue_moon.png';
import chinese from '../asset/images/chinese.png';
import down_arrow from '../asset/images/down_arrow.png';
import excellence from '../asset/images/excellence.png';
import headset_outline from '../asset/images/headset_outline.png';
import mibcity from '../asset/images/mibcity.png';
import pencil from '../asset/images/pencil.png';
import redbloodcell from '../asset/images/redbloodcell.png';
import ripples from '../asset/images/ripples.png';
import skateboard from '../asset/images/skateboard.png';
import slippers from '../asset/images/slippers.png';
import '../styles/fonts.css';
import Footer from '../globals/Footer';
import { Link } from 'react-router-dom';
import {
  motion,
  useViewportScroll,
  useAnimation,
  useCycle,
} from 'framer-motion';

const useStyles = makeStyles({
  column: {
    display: 'flex',
    flexDirection: 'column',
  },
  row: {
    display: 'flex',
    flexDirection: 'row',
  },
  sectionOne: {
    color: 'white',
    backgroundImage: `url(${ripples})`,
    backgroundSize: 'cover',
    backgroundRepeat: 'no-repeat',
    backgroundColor: '#2E324B',
    paddingTop: '6em',
    paddingBottom: '5em',
    justifyContent: 'space-between',
    // width: '100%',
  },
  topHeader: {
    fontSize: '4em',
    lineHeight: '1em',
    marginBottom: '0.5em',
  },
  topTextArea: {
    width: '55%',
    marginLeft: '7%',
    marginTop: '8%',
  },
  topSentence: {
    fontSize: '1.2em',
    width: '100%',
    fontFamily: 'AvertaDemo',
  },
  queryImage: {
    position: 'fixed',
    right: '0%',
    width: '4.5%',
    height: '8%',
    top: '26%',
    padding: '0.4em',
    cursor: 'pointer',
    background: 'rgba(0, 0, 0, 0.3)',
    zIndex: '1',
    border: '2px solid whitesmoke',
    borderRight: '0px',
  },
  sectionTwo: {
    backgroundColor: '#2E324B',
    height: '9em',
  },
  sectionThree: {
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
  },
  pictureArea: {
    marginTop: '5%',
    width: '80%',
    justifyContent: 'center',
  },
  pictureTextBoxStrange: {
    alignItems: 'flex-start',
    color: '#2E324B',
    width: '90%',
  },
  pictureTextBox: {
    alignItems: 'flex-start',
    marginLeft: '2em',
    color: '#2E324B',
    width: '90%',
  },
  pictureHeader: {
    marginTop: '1em',
    marginBottom: '0.3em',
    fontWeight: '700',
    fontFamily: 'BellMT',
  },
  pictureSentence: {
    fontFamily: 'Opensanslight',
    fontWeight: '700',
  },
  pictureBox: {
    height: '70%',
  },
  pictureBoxStrange: {
    height: '70%',
  },
  pictureImage: {
    width: '100%',
    height: '100%',
  },
  dividerFirst: {
    height: '0.2em',
    width: '55%',
    marginTop: '3.5em',
    marginBottom: '3.5em',
    backgroundColor: '#063E63',
  },
  businessText: {
    width: '75%',
  },
  businessHeader: {
    textAlign: 'center',
    fontSize: '3.7em',
    fontWeight: '700',
    marginBottom: '0.8em',
    color: '#063E63',
    fontFamily: 'BellMT',
  },
  businessSentence: {
    textAlign: 'center',
    fontSize: '1.2em',
    fontWeight: '700',
    padding: '0em 7em 0em 7em',
    color: '#2E324B',
    fontFamily: 'Opensanslight',
    marginBottom: '2em',
  },
  businessFooterText: {
    textAlign: 'center',
    fontSize: '1.4em',
    color: '#2E324B',
    fontFamily: 'BellMT',
    marginTop: '0.5em',
    marginBottom: '2.5em',
    fontWeight: '900',
  },
  sectionFour: {
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    backgroundColor: '#2E324B',
    paddingTop: '7%',
    paddingBottom: '0%',
    color: 'white',
  },
  optimumHeader: {
    fontSize: '3.5em',
    fontFamily: 'geometric',
    marginBottom: '1em',
    fontWeight: '900',
  },
  optimumText: {
    fontSize: '2em',
    marginBottom: '1.5em',
    fontFamily: 'AvertaDemo',
    lineHeight: '1.1em',
    width: '47%',
    fontWeight: '100 ',
    '@media only screen and (max-device-width: 1300px)': {
      width: '49%',
    },
  },
  optimumIcon: {
    marginTop: '1.5em',
  },
  pointed_out: {
    marginTop: '0em',
    borderTop: '50px solid #2E324B',
    borderBottom: '50px solid transparent',
    borderLeft: '50px solid transparent',
    borderRight: '50px solid transparent',
    backgroundColor: 'transparent',
    position: 'relative',
    top: '6.2em',
    height: '0em',
    width: '0em',
  },
  sectionFive: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: '5%',
  },
  dividerLast: {
    height: '0.2em',
    width: '70%',
    marginTop: '1em',
    marginBottom: '2em',
    backgroundColor: '#2E324B',
  },
  symbolArea: {
    width: '65%',
  },
  symbolSubAreaOne: {
    marginLeft: '0em',
    width: '55%',
  },
  symbolSubAreaTwo: {
    marginLeft: '5em',
    width: '55%',
  },
  symbolImage: {
    width: '55%',
  },
  symbolText: {
    marginLeft: '0.2em',
    color: '#2E324B',
  },
  symbolTextSpecial: {
    marginLeft: '-0.9em',
  },
  symbolHeader: {
    fontSize: '2.2em',
    color: '#2E324B',
    fontFamily: 'Opensanslight',
    fontWeight: '700',
  },
  symbolSentence: {
    fontSize: '1em',
    fontFamily: 'Opensanslight',
    fontWeight: '700',
  },
  sectionSix: {
    backgroundColor: '#2E324B',
    padding: '8% 0% 8% 10%',
    marginTop: '5%',
    color: 'white',
  },
  innerSix: {
    width: '58%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sixHeader: {
    width: '90%',
    fontSize: '3em',
    lineHeight: '1em',
    fontWeight: '700',
    position: 'relative',
    marginBottom: '0.5em',
    left: '-0.7em',
    fontFamily: 'BellMTBold',
  },
  sixText: {
    fontWeight: '700',
    fontFamily: 'Opensanslight',
    fontSize: '1.1em',
  },
  textSeven: {
    width: '50%',
    color: '#2E324B',
    height: '10%',
    position: 'relative',
    top: '6em',
    marginLeft: '10%',
  },
  imageSeven: {
    width: '35%',
    height: '35em',
    position: 'relative',
    left: '-5em',
    top: '-11em',
  },
  imageSevenPic: {
    width: '100%',
    height: '100%',
  },
  sevenTextOne: {
    justifyContent: 'center',
    alignItems: 'center',
    fontSize: '5em',
    lineHeight: '1em',
    fontWeight: '700',
    position: 'relative',
    left: '1em',
  },
  sevenTextTwo: {
    justifyContent: 'center',
    alignItems: 'center',
    lineHeight: '1em',
    fontSize: '7em',
    fontWeight: '700',
  },
  sevenTextThree: {
    justifyContent: 'center',
    alignItems: 'center',
    fontSize: '5em',
    lineHeight: '1em',
    fontWeight: '700',
  },
  sevenTextFour: {
    justifyContent: 'center',
    alignItems: 'center',
    fontSize: '5em',
    lineHeight: '1em',
    fontWeight: '700',
  },
  sectionEight: {
    color: 'white',
    marginBottom: '0em',
    height: '26em',
    backgroundImage: `url(${half_blue_moon})`,
    backgroundSize: 'cover',
  },
  inTouchText: {
    width: '35%',
    justifyContent: 'center',
    position: 'relative',
    left: '22%',
    '@media only screen and (max-device-width: 1300px)': {
      left: '25%',
    },
  },
  inTouchHeader: {
    fontSize: '4.5em',
    textAlign: 'center',
    fontFamily: 'BellMT',
  },
  inTouchTextOne: {
    fontSize: '1.5em',
    textAlign: 'left',
    fontFamily: 'AvertaDemo',
  },
  inTouchTextTwo: {
    fontSize: '1.5em',
    textAlign: 'right',
    fontFamily: 'AvertaDemo',
  },
  linkButton: {
    marginTop: '1.25em',
    padding: '0em',
    width: '37.5%',
    height: '12%',
    textDecoration: 'none',
    padding: '0.3em',
    borderRadius: '2.5em',
    position: 'relative',
    left: '68%',
    background: 'white',
    cursor: 'pointer',
  },
  buttonLink: {
    fontFamily: 'Opensanslight',
    textTransform: 'none',
    textAlign: 'center',
    fontWeight: '700',
    fontSize: '1.3em',
    borderRadius: '1.5em',
    width: '100%',
    height: '100%',
  },
  fowardIcon: {
    border: '3px solid #2E324B',
    color: '#2E324B',
    borderRadius: '1em',
    marginLeft: '0em',
    position: 'relative',
    left: '0.6em',
    fontSize: '1.5em !important',
    '@media only screen and (max-device-width: 1300px)': {
      left: '1em',
    },
  },
});

const geometric = createTheme({
  typography: {
    fontFamily: ['geometric'].join(','),
  },
});
const BellMTBold = createTheme({
  typography: {
    fontFamily: ['BellMTBold'].join(','),
  },
});

const ButtonVariants = {
  animate: {
    x: [0, -10],
    opacity: 1,
    transition: { yoyo: Infinity, ease: 'easeIn' },
  },
};
const ArrowDownVariants = {
  animate: {
    y: ['25%', '0%'],
    opacity: 1,
    transition: {
      repeat: Infinity,
      repeatType: 'reverse',
      ease: 'easeIn',
      duration: 0.5,
    },
  },
};

const BusinessAgility = () => {
  const classes = useStyles();
  return (
    <Box>
      <NavBar />
      {/* <Box className={`${classes.sectionOne} ${classes.column}`}>
        <Box></Box>
        <Box></Box>
      </Box> */}
      <Box className={`${classes.sectionOne} ${classes.row}`}>
        <Box className={`${classes.column} ${classes.topTextArea}`}>
          <Typography className={`${classes.topHeader}`} variant="h4">
            Enhanced efficiency through collaboration.
          </Typography>
          <Typography className={`${classes.topSentence}`} variant="h6">
            Gaining insight to business and reduce cost and improve
            profitability through efficiency making use of our creative space
            will help you grow and maximize profit.
          </Typography>
        </Box>
        <img className={`${classes.queryImage}`} src={query} alt="query" />
      </Box>
      <Box className={`${classes.sectionTwo} ${classes.bannerSection}`}></Box>
      <Box className={`${classes.sectionThree} ${classes.column}`}>
        <Box className={`${classes.row} ${classes.pictureArea}`}>
          <Box
            className={`${classes.column}  ${classes.pictureTextBoxStrange}`}
          >
            <Box className={`${classes.pictureBoxStrange}`}>
              <img
                className={`${classes.pictureImage}`}
                src={mibcity}
                alt="mibcity"
              />
            </Box>
            <Box className={`${classes.pictureText}`}>
              <Typography className={`${classes.pictureHeader}`} variant="h4">
                Innovation
              </Typography>
              <Typography className={`${classes.pictureSentence}`} variant="h7">
                Adopting productivity mindset and a high performance using
                innovation.
              </Typography>
            </Box>
          </Box>
          <Box className={`${classes.column}  ${classes.pictureTextBox}`}>
            <Box className={`${classes.pictureBox}`}>
              <img
                className={`${classes.pictureImage}`}
                src={skateboard}
                alt="skateboard"
              />
            </Box>
            <Box className={`${classes.pictureText}`}>
              <Typography className={`${classes.pictureHeader}`} variant="h4">
                Strategy
              </Typography>
              <Typography className={`${classes.pictureSentence}`} variant="h7">
                The art of improvement driven by plan using insight and metrics
                for growth.
              </Typography>
            </Box>
          </Box>
          <Box className={`${classes.column}  ${classes.pictureTextBox}`}>
            <Box className={`${classes.pictureBox}`}>
              <img
                className={`${classes.pictureImage}`}
                src={slippers}
                alt="slippers"
              />
            </Box>
            <Box className={`${classes.pictureText}`}>
              <Typography className={`${classes.pictureHeader}`} variant="h4">
                Partnership
              </Typography>
              <Typography className={`${classes.pictureSentence}`} variant="h7">
                Transforming operations through partnership to enhance business
                growth.
              </Typography>
            </Box>
          </Box>
        </Box>
        <Divider
          className={`${classes.dividerFirst}`}
          orientation="horizontal"
        />
        <Box className={`${classes.column} ${classes.businessText}`}>
          <Typography className={`${classes.businessHeader}`} variant="">
            Operational tenacity for transforming the way businesses are done
          </Typography>
          <Typography className={`${classes.businessSentence}`} variant="">
            Delivering optimum business solutions for business efficiency and
            developing a strong collaboration with clients has helped and
            supported our pro-active approach in solving complex business
            problems.
          </Typography>
          <Typography className={`${classes.businessFooterText}`} variant="">
            Keeping you growing has been and will continue to be our main
            objective.
          </Typography>
        </Box>
      </Box>
      <Box className={`${classes.sectionFour} ${classes.column}`}>
        <Typography className={`${classes.optimumHeader}`} variant="h3">
          Achieving Optimum Service
        </Typography>
        <Typography className={`${classes.optimumText}`} variant="h6">
          Adopting a productivity mindset can be challenging but the pay off is
          enormous.
        </Typography>
        <Box
          component={motion.div}
          animate="animate"
          initial="initial"
          variants={ArrowDownVariants}
        >
          <img
            src={down_arrow}
            className={`${classes.optimumIcon}`}
            alt="down_arrow"
          />
        </Box>
        <Box className={`${classes.pointed_out}`}></Box>
      </Box>
      <Box className={`${classes.sectionFive} ${classes.column}`}>
        <Box className={`${classes.row} ${classes.symbolArea}`}>
          <Box className={`${classes.row} ${classes.symbolSubAreaOne}`}>
            <Box className={`${classes.symbolImage}`}>
              <img src={headset_outline} alt="headset_outline" />
            </Box>
            <Box className={`${classes.column} ${classes.symbolText}`}>
              <Typography className={`${classes.symbolHeader}`} variant="h4">
                Listen
              </Typography>
              <Typography className={`${classes.symbolSentence}`} variant="h6">
                We'll be happy to listen to all of your requirements
              </Typography>
              <Divider
                className={`${classes.dividerLast}`}
                orientation="horizontal"
              />
            </Box>
          </Box>
          <Box className={`${classes.row} ${classes.symbolSubAreaTwo}`}>
            <Box className={`${classes.symbolImage}`}>
              <img src={chinese} alt="chinese" />
            </Box>
            <Box className={`${classes.column} ${classes.symbolText}`}>
              <Typography className={`${classes.symbolHeader}`} variant="h4">
                Plan
              </Typography>
              <Typography className={`${classes.symbolSentence}`} variant="">
                We develop a model that suits the stated requirements
              </Typography>
              <Divider
                className={`${classes.dividerLast}`}
                orientation="horizontal"
              />
            </Box>
          </Box>
        </Box>
        <Box className={`${classes.row}  ${classes.symbolArea}`}>
          <Box className={`${classes.row} ${classes.symbolSubAreaOne}`}>
            <Box className={`${classes.symbolImage}`}>
              <img src={pencil} alt="pencil" />
            </Box>
            <Box className={`${classes.column} ${classes.symbolText}`}>
              <Typography className={`${classes.symbolHeader}`} variant="h4">
                Create
              </Typography>
              <Typography className={`${classes.symbolSentence}`} variant="">
                We design an intervention and report on likely impact
              </Typography>
              <Divider
                className={`${classes.dividerLast}`}
                orientation="horizontal"
              />
            </Box>
          </Box>
          <Box className={`${classes.row}  ${classes.symbolSubAreaTwo}`}>
            <Box className={`${classes.row}`}>
              <Box className={`${classes.symbolImage}`}>
                <img src={excellence} alt="excellence" />
              </Box>
              <Box className={`${classes.column} ${classes.symbolTextSpecial}`}>
                <Typography className={`${classes.symbolHeader}`} variant="h4">
                  Deliver
                </Typography>
                <Typography className={`${classes.symbolSentence}`} variant="">
                  We assure a satisfactory delivery on innovation
                </Typography>
                <Divider
                  className={`${classes.dividerLast}`}
                  orientation="horizontal"
                />
              </Box>
            </Box>
          </Box>
        </Box>
      </Box>
      <Box className={`${classes.sectionSix}`}>
        <Box className={`${classes.innerSix} ${classes.column}`}>
          <Typography className={`${classes.sixHeader}`} variant="h4">
            Right on time to market makes a difference
          </Typography>
          <Typography className={`${classes.sixText}`} variant="h6">
            We identify your goals and help you develop a cutting edge business
            model that will probably differentiate your company from its
            competitors and analyze the current process hurdles that preclude
            reaching the desired goal. We develop a plan to close the gap
            between the current process status and attainment of the desired
            goal.
          </Typography>
        </Box>
      </Box>
      <Box className={`${classes.sectionSeven} ${classes.row}`}>
        <Box className={`${classes.textSeven} ${classes.column}`}>
          <ThemeProvider theme={BellMTBold}>
            <Typography className={`${classes.sevenTextOne}`}>Using</Typography>
            <Typography className={`${classes.sevenTextTwo}`}>
              Innovation
            </Typography>
            <Typography className={`${classes.sevenTextThree}`}>
              to improve
            </Typography>
            <Typography className={`${classes.sevenTextFour}`}>
              perfomance
            </Typography>
          </ThemeProvider>
        </Box>
        <Box className={`${classes.imageSeven}`}>
          <img
            className={`${classes.imageSevenPic}`}
            src={redbloodcell}
            alt="redbloodcell"
          />
        </Box>
      </Box>
      <Box className={`${classes.row} ${classes.sectionEight}`}>
        <Box className={`${classes.column} ${classes.inTouchText}`}>
          <Typography className={`${classes.inTouchHeader}`} variant="h4">
            Get in Touch
          </Typography>
          <Typography className={`${classes.inTouchTextOne}`} variant="h6">
            and find out how your business
          </Typography>
          <Typography className={`${classes.inTouchTextTwo}`} variant="h6">
            can benefit from our creative space
          </Typography>
          <Link
            component={motion.a}
            animate="animate"
            initial="initial"
            variants={ButtonVariants}
            className={`${classes.linkButton}`}
            to="/contactus"
          >
            <Button
              className={classes.buttonLink}
              endIcon={<ArrowForwardIcon className={classes.fowardIcon} />}
            >
              Lets Talk
            </Button>
          </Link>
        </Box>
      </Box>
      <Footer />
    </Box>
  );
};

export default BusinessAgility;
