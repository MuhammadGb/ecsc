import React from 'react';
import { Divider, Typography } from '@material-ui/core';
import Box from '@material-ui/core/Box';
import { makeStyles } from '@material-ui/styles';
import NavBar from '../globals/NavBar';
import query from '../asset/images/query.png';
import upView from '../asset/videos/upView.mp4';
import Footer from '../globals/Footer';
import Audi2021 from '../asset/images/Audi2021.png';
import cartWheel from '../asset/images/cartWheel.png';
import glassPattern from '../asset/images/glassPattern.png';
import robot_hand from '../asset/images/robotHand.png';

const useStyles = makeStyles((theme) => ({
  column: {
    display: 'flex',
    flexDirection: 'column',
  },
  row: {
    display: 'flex',
    flexDirection: 'row',
  },
  firstSection: {
    height: '100vh',
    width: '100%',
    color: 'white',
    alignItems: 'center',
    background: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
  },
  videoBackground: {
    zIndex: '-1',
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100vw',
    height: '100vh',
    objectFit: 'cover',
  },
  videoText: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
  firstHeader: {
    fontSize: '4.5em',
    lineHeight: '1em',
    fontWeight: '700',
    fontFamily: 'geometric',
  },
  firstSentence: {
    fontSize: '1.2em',
    textAlign: 'center',
    width: '60%',
    fontWeight: '700',
    fontFamily: 'Opensanslight',
    marginTop: '2em',
  },
  query: {
    position: 'fixed',
    right: '0%',
    width: '4.5%',
    height: '8%',
    top: '26%',
    padding: '0.4em',
    cursor: 'pointer',
    background: 'rgba(0, 0, 0, 0.3)',
    zIndex: '1',
    border: '2px solid whitesmoke',
    borderRight: '0px',
  },
  secondSection: {
    
    height: '100vh',
    backgroundColor: '#2E324B',
  },
  nonBlankTwo: {
    width: '40%',
    color: 'white',
    alignItems: 'flex-start',
    justifyContent: 'center',
    margin: 'auto 5em',
  },
  blankTwo: {
    height: '100%',
    width: '40%',
  },
  twoHeader: {
    fontSize: '2em',
    fontWeight: '700',
    marginBottom: '0.5em',
    fontFamily: 'Leaguespartanbold',
  },
  twoSentence: {
    fontSize: '3vh',
    fontFamily: 'Opensanslight',
    fontWeight: '400',
    marginTop: '0.7em',
    marginBottom: '0.7em',
  },
  thirdSection: {
    height: '100vh',
    backgroundColor: 'white',
  },
  empty: {
    width: '20%',
  },
  blankThree: {
    
    width: '40%',
  },
  nonBlankThree: {
    width: '40%',
    textAlign: 'left',
    margin: 'auto 5em',
    justifyContent: 'center',
  },
  Image: {
    maxWidth: '100%',
    height: 'auto',
    objectFit: 'cover',
  },
  threeHeader: {
    fontSize: '2em',
    fontFamily: 'Leaguespartanbold',
    fontWeight: '100',
    marginBottom: '0.1em',
    flexWrap: 'nowrap',
  },
  threeSentence: {
    fontSize: '3vh',
    fontFamily: 'Opensanslight',
    fontWeight: '700',
    marginTop: '0.7em',
    marginBottom: '0.7em',
  },
  dividerMain: {
    backgroundColor: 'gray',
    width: '0.15em',
    height: '100%',
    position: 'relative',
    left: '100%',
  },
}));

const OtherServices = () => {
  const classes = useStyles();
  return (
    <Box>
      <NavBar />
      <Box className={classes.column}>
        <Box className={`${classes.firstSection} ${classes.column}`}>
          <video autoPlay muted loop className={classes.videoBackground}>
            <source src={upView} type="video/mp4" />
          </video>
          <Box className={`${classes.videoText} ${classes.column}`}>
            <img className={classes.query} src={query} alt="query" />
            <Typography className={classes.firstHeader}>Utilizing</Typography>
            <Typography className={classes.firstHeader}>
              The Competence
            </Typography>
            <Typography className={classes.firstSentence}>
              Achieving the highest result by putting together the best thinkers
              can spur extraordinary results
            </Typography>
          </Box>
        </Box>
        <Box className={`${classes.secondSection} ${classes.row}`}>
          <Box className={`${classes.empty}`}>
            <Divider className={classes.dividerMain} orientation="vertical" />
          </Box>
          <Box className={`${classes.nonBlankTwo} ${classes.column}`}>
            <Typography className={`${classes.twoHeader}`}>
              Enabling Technology
            </Typography>
            <Typography className={`${classes.twoSentence}`}>{"There has been a paradigm shift from legacy technology to new technologies. This is one of the most significant business complexities an organization encounters."}
            </Typography>
            <Typography className={`${classes.twoSentence}`}>
           {" As enterprises upgrade or change their technologies they must ensure compatibility with the old systems and data formats."}
            </Typography>
            <Typography className={`${classes.twoSentence}`}>
              {"At ECSALLIANCE, we woo our customers with customized software that enhances robust performance."}
            </Typography>
          </Box>
          <Box className={`${classes.blankTwo}`}>
            <img
              className={classes.Image}
              src={robot_hand}
              alt="robot_hand"
            />
          </Box>
        </Box>
        <Box className={[classes.thirdSection, classes.row]}>
          <Box className={`${classes.empty}`}>
            <Divider className={classes.dividerMain} orientation="vertical" />
          </Box>
          <Box className={`${classes.blankThree}`}>
            <img className={classes.Image} src={cartWheel} alt="cartWheel" />
          </Box>
          <Box className={`${classes.nonBlankThree}  ${classes.column}`}>
            <Typography className={`${classes.threeHeader}`}>
              Employee Competence Evaluation
            </Typography>
            <Typography className={`${classes.threeSentence}`}>
              A thorough competency assessment of the workforce will help build
              a resourceful organization that delivers value deliberately to
              complement the actualization of your vision.
            </Typography>
            <Typography className={`${classes.threeSentence}`}>
              Our intervention will drive a precise insight into the skill you
              already have and what competence is lacking to help the
              organization achieve a optimum performance.
            </Typography>
          </Box>
        </Box>
        <Box className={`${classes.secondSection} ${classes.row}`}>
          <Box className={`${classes.empty}`}>
            <Divider className={classes.dividerMain} orientation="vertical" />
          </Box>
          <Box className={`${classes.nonBlankTwo} ${classes.column}`}>
            <Typography className={`${classes.twoHeader}`}>
              {'Operation & Efficiency'}
            </Typography>
            <Typography className={`${classes.twoSentence}`}>
              {
                "Adopting a productivity mindset can be challenging but the pay off is enormous. With our acquired business insight, we can show you how to do business in a way that improves profitability through efficiency as your continuous growth is our main objective.."
              }
            </Typography>
            <Typography className={`${classes.twoSentence}`}>
              {
                "We put the right tool in place to drive organizational effectiveness through knowledge transfer, innovation and process improvement"
              }
            </Typography>
          </Box>
          <Box className={`${classes.blankTwo}`}>
            <img className={classes.Image} src={Audi2021} alt="Audi2021" />
          </Box>
        </Box>
        <Box className={`${classes.thirdSection} ${classes.row}`}>
          <Box className={`${classes.empty}`}>
            <Divider className={classes.dividerMain} orientation="vertical" />{' '}
          </Box>
          <Box className={`${classes.blankThree}`}>
            <img
              className={classes.Image}
              src={glassPattern}
              alt="glass-pattern"
            />
          </Box>
          <Box className={`${classes.nonBlankThree} ${classes.column}`}>
            <Typography className={`${classes.threeHeader}`}>
              Digital Commerce
            </Typography>
            <Typography className={`${classes.threeSentence}`}>{" The name of the game is vital positioning! The capacity of an organization to decide developing chances and use its important human capital to maximize benefits from these open doors through an e-business procedure is very crucial."}
            </Typography>
            <Typography className={`${classes.threeSentence}`}>{"At ECSALLIANCE we design digital vision for your business. We connect your business to the digital world and help your realize your vision through exceptional results."}
            </Typography>
          </Box>
        </Box>
      </Box>
      <Footer />
    </Box>
  );
};

export default OtherServices;
