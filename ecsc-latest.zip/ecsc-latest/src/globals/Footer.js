import React from 'react';

import footerlogo from '../asset/images/footerlogo.png';
import facebook from '../asset/images/facebook.png';
import youtube from '../asset/images/youtube.png';
import twitter from '../asset/images/twitter.png';
import linkedn from '../asset/images/linkedn.png';
import instagram from '../asset/images/instagram.png';

import '../styles/Footer.css';
import { Link } from 'react-router-dom';
const Footer = () => {
  return (
    <div className="footer">
        <h4 className="footer-text">Intervention Driven By Agility</h4>
     
      <div className="footer-main">
        <div className="footer-left">
          <img src={footerlogo} alt={'footerlogo'} />
        </div>
        <div className="footer-right">
          <div className="footer-link">
            <ul className="footer-link">
              <li>
                <Link className="linkconnect" to="/">
                  Functions
                </Link>
              </li>

              <li>
                <Link className="linkconnect" to="/contactus">
                  Connect
                </Link>
              </li>
              <li>
                <Link className="linkconnect" to="/career">
                  Careers
                </Link>
              </li>
              <li>
                <Link className="linkconnect" to="/about">
                  About Us
                </Link>
              </li>
            </ul>
          </div>
          <div className="footer-icons">
            <span className="follow-us">{'Follow us'}</span>
            <div></div>
            <img src={facebook} />
            <img src={youtube} />
            <img src={linkedn} />
            <img src={instagram} />
            <img src={twitter} />
          </div>
        </div>
      </div>
      <hr></hr>
      <div className="footer-lower">
        <p>
          Copyright &#169;2021 &nbsp;{' '}
          <span>
            <img src={footerlogo} alt={'footerlogo'} />
          </span>{' '}
        </p>
      </div>
    </div>
  );
};

export default Footer;
