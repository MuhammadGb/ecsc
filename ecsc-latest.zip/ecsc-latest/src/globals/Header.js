
import React, { useState} from 'react';
import { NavLink } from 'react-router-dom';
import '../styles/NavBar.css';
import Dropdown from '../component/Dropdown'
import blacklogo from '../asset/images/blacklogo.png';
import {FaBars} from "react-icons/fa";
import {FaTimes} from 'react-icons/fa';



const Header = () => {
    const [appearance, setAppearance] =useState(false)
    const [dropdown, setDropdown] = useState(false)
    const [isMobile, setIsMobile] = useState(false)


    const changeBackground = () => {
      if (window.scrollY >= 80) {
        setAppearance(true)
      }
      else{
        setAppearance(false)
      }
    };
  
    window.addEventListener('scroll',changeBackground);

    const onMouseEnter = () =>{
      if (window.innerWidth < 960) {
        setDropdown(false)
      }else {
        setDropdown(true)
      }
    };
  
  const onMouseLeave = () =>{
    if (window.innerWidth < 960) {
      setDropdown(false)
    }else {
      setDropdown(false)
    }
  };

  const handleClick = ()=>{
    setIsMobile(!isMobile)
  }
  
    return (
      <nav className={appearance ? 'navbar headeraddition' : 'navbar'}>
        <div className="nav-container">
          <NavLink exact to="/" className="nav-logo">
            <img src={blacklogo} alt={"blacklogo"} />
          </NavLink>
          <div className='mobile-icon-bar' onClick={handleClick}>
          {isMobile ? (<FaTimes color='#000'/>) :(<FaBars color='#000'/>)}
        </div>
          <ul className={isMobile ? "nav-menu header" : "nav-menu"} onClick={() => setIsMobile(false)}>
            <li className="nav-item">
              <NavLink exact to="/featured" className="header-links" >
                Featured Insight
              </NavLink>
            </li>
            <li className="nav-item" onMouseEnter={onMouseEnter} onMouseLeave={onMouseLeave}>
              <NavLink exact to="/" className="header-links">
                Functions
                {dropdown && <Dropdown/>}
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink exact to="/" className="header-links">
                Careers
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink exact to="/" className="header-links">
                About Us
              </NavLink>
            </li>
          </ul>
  
       
        </div>
       
      </nav>
    );
  };
  
export default Header
