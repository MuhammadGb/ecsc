import React from 'react';
import Footer from '../globals/Footer';
import NavBar from '../globals/NavBar';
import {
  motion,
} from 'framer-motion';

import Box from '@material-ui/core/Box';
import { makeStyles } from '@material-ui/styles';
import { ThemeProvider, createTheme } from '@material-ui/core/styles';
import {
  Paper,
  Typography,
} from '@material-ui/core';
import { Link } from 'react-router-dom';
import chess from '../asset/images/chess.png';
import twomen from '../asset/images/2men.png';
import eight from '../asset/images/eight.png';
import yellowimage from '../asset/images/yellowimage.png';
import pink from '../asset/images/pink.png';
import whitearrow from '../asset/images/whitearrow.png';
import query from '../asset/images/query.png';

import '../styles/fonts.css';

const useStyles = makeStyles((theme) => ({
  root: {
    margin: '0',
    padding: '0',
  },
  inTouchButton: {
    display: 'flex',
    textDecoration: 'none',
    justifyContent: 'center',
    alignItems: 'center',
    color: '#fff',
    backgroundColor: '#000',
    width: '13em',
    height: '6vh',
    borderRadius: '40px',
    paddingTop: '2em',
    paddingBottom: '2em',
    marginTop: '4em',
  },
  chesspart: {
    backgroundImage: `url(${chess})`,
    height: '100vh',
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'cover',
    width: '100%',
  },
  chessmain: {
    paddingTop: '14em',
    color: '#fff',
    margin: '0 auto',
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',

    width: '90%',
  },
  chessline: {
    height: '0.35rem',
    width: '10rem',
    background: '#FADD98',
    marginBottom: '2em',
  },
  chessbig: {
    fontSize: '3em',
  },
  chessbigger: {
    fontSize: '4em',
    lineHeight: '0.7',
  },
  chesstext: {
    fontSize: '1.3em',
  },
  chessleft: {
    marginLeft: '6em',
  },
  queryImage: {
    position: 'fixed',
    right: '0%',
    width: '4.5%',
    height: '8%',
    top: '26%',
    padding: '0.4em',
    cursor: 'pointer',
    background: 'rgba(0, 0, 0, 0.3)',
    zIndex: '1',
    border: '2px solid whitesmoke',
    borderRight: '0px',
  },
  smalldiv: {
    marginTop: '3em',
  },
  whitemain: {
    height: '95vh',
    display: 'flex',
    width: '100%',
    justifyContent: 'space-around',
    flexDirection: 'row',
    marginTop: '8em',
    paddingBottom: '0em',
  },
  whiteleft: {
    position: 'relative',
    top: '-6em',
  },
  whiteright: {
    textAlign: 'center',
    marginLeft: '-25em',
  },
  imageBox: {
    marginTop: '0.5em',
    marginRight: '1em',
  },
  segoesctext: {
    fontSize: '4em',
    lineHeight: '1.2em',
    fontFamily: 'Leaguespartanbold',
  },
  segoesctextImage: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'space-between',
    justifyContent: 'center',
  },
  whitepartline: {
    height: '0.35rem',
    width: '8rem',
    background: 'black',
    margin: '1em auto 0 auto',
  },
  yellowpart: {
    background: '#2E324B',
    height: '90vh',
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'cover',
    width: '100%',
    paddingTop: '4em',
    paddingBottom: '3em',
  },
  yellowmain: {
    textAlign: 'center',
    paddingTop: '2em',
    margin: '0 auto',
    paddingBottom: '3em',
    justifyContent: 'center',
  },
  addressdiv: {
    marginTop: '2.5em',
  },
  addressbold: {
    fontSize: '4em',
    lineHeight: '0.9',
    color: '#FADD98',
  },
  normaldiv: {
    marginTop: '2em',
  },
  normaldivtest: {
    color: '#fff',
    fontSize: '1.5em',
  },
  benefittext: {
    marginTop: '2em',
    color: '#FADD98',
    fontSize: '2em',
    lineHeight: '0',
    paddingBottom: '1em',
  },
  whitefirst: {
    marginTop: '2em',
    fontSize: '1.2em',
    fontWeight: '600',
  },
  normaltext: {
    fontSize: '1.2em',
    fontWeight: '600',
  },
  addressline: {
    height: '0.25rem',
    width: '10rem',
    background: '#fff',
    margin: '0 auto',
  },
  iconpart: {
    display: 'flex',
    flexDirection: 'row',
    paddingTop: '3em',
    justifyContent: 'space-between',
    textAlign: 'center',
    alignContent: 'center',
    width: '65%',
    margin: '0 auto',
    color: '#fff',
    fontWeight: '300',
  },
  iconpart2: {
    display: 'flex',
    flexDirection: 'row',
    alignContent: 'center',
    paddingTop: '3em',
    justifyContent: 'space-between',
    width: '69%',
    textAlign: 'center',
    margin: '0 auto',
    color: '#fff',
    fontWeight: '300',
  },
  iconitem: {
    display: 'flex',
    flexDirection: 'row',
    // justifyContent:'space-between',
  },
  iconitem1: {
    display: 'flex',
    flexDirection: 'row',
    // justifyContent:'space-between',
    // marginLeft:'1.2em',
    paddingLeft: '2em',
  },
  iconitem2: {
    display: 'flex',
    flexDirection: 'row',
    // justifyContent:'space-between',
    marginLeft: '1.2em',
    paddingLeft: '7.3em',
  },
  iconitem3: {
    display: 'flex',
    flexDirection: 'row',
    // justifyContent:'space-between',
    paddingLeft: '10.8em',
  },
  iconitem4: {
    display: 'flex',
    flexDirection: 'row',
    // justifyContent:'space-between',
    paddingLeft: '6em',
  },
  icontext: {
    paddingLeft: '1em',
    fontSize: '1.3em',
  },
  undericonline: {
    height: '0.25rem',
    width: '19rem',
    background: '#fff',
    margin: '0 auto',
    marginTop: '5.5em',
  },
  mentorship: {
    height: '60vh',
  },
  mentorshipmain: {
    width: '100%',
    margin: '0 auto',
    alignContent: 'center',
    textAlign: 'center',
    justifyContent: 'center',
    marginTop: '8em',
  },
  mentorshipbold: {
    fontSize: '4em',
    lineHeight: '1',
  },
  mentorshipdiv: {
    marginTop: '2em',
  },
  mentorshipnormal: {
    fontWeight: '600',
    fontSize: '1.3em',
    width: '100%',
  },
  pinkpart: {
    backgroundImage: `url(${pink})`,
    height: '90vh',
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'cover',
    width: '100%',
  },
  pinkmain: {
    display: 'flex',
    flexDirection: 'row',
    width: '80%',
    justifyContent: 'space-between',
    margin: '0 auto',
    paddingTop: '9em',
  },
  pinkleftdown: {
    marginTop: '1.5em',
  },
  pinkleftnormal: {
    fontWeight: '600',
    fontSize: '1.2em',
  },
  pinkleftbold: {
    // fontWeight:'bolder',
    fontSize: '1.2em',
  },
  pinkright: {
    marginTop: '4em',
    marginRight: '1em',
    textAlign: 'right',
  },
  pinkrightbold: {
    fontSize: '2.5em',
    color: '#fff',
  },
  whiteline: {
    height: '0.25rem',
    width: '15rem',
    background: '#fff',
    marginLeft: '13em',
    marginTop: '1em',
  },
  touchlink: {
    display: 'flex',
    textDecoration: 'none',
    justifyContent: 'right',
    alignItems: 'center',
    color: '#fff',
    backgroundColor: '#000',
    width: '11em',
    height: '6vh',
    borderRadius: '40px',
    padding: '0.5em',
    marginTop: '4em',
  },
  touchlinktext: {
    fontSize: '1.5em',
  },
  toucharrow: {
    position: 'relative',
    left: '1.2em',
  },
}));

const segoesc = createTheme({
  typography: {
    fontFamily: ['segoesc'].join(','),
  },
});

const Opensans = createTheme({
  typography: {
    fontFamily: ['Opensanslight'].join(','),
  },
});

const AvertaDemo = createTheme({
  typography: {
    fontFamily: ['AvertaDemo'].join(','),
  },
});

const MontserratBold = createTheme({
  typography: {
    fontFamily: ['MontserratBold'].join(','),
  },
});
const Montserrat = createTheme({
  typography: {
    fontFamily: ['Montserrat'].join(','),
  },
});

const OpensansBold = createTheme({
  typography: {
    fontFamily: ['OpensansBold'].join(','),
  },
});

const BellMT = createTheme({
  typography: {
    fontFamily: ['BellMT'].join(','),
  },
});

const BellMTBold = createTheme({
  typography: {
    fontFamily: ['BellMTBold'].join(','),
  },
});

const ButtonVariants = {
  animate: {
    x: [0, -10],
    opacity: 1,
    transition: { yoyo: Infinity, ease: 'easeIn' },
  },
};

const Learning = () => {
  const classes = useStyles();
  return (
    <div className={classes.root}>
      <Paper elevation={0} className={classes.chesspart}>
        <NavBar />
        <Box className={classes.chessmain}>
          <ThemeProvider theme={BellMTBold}>
            <div className={classes.chessleft}>
              <div className={classes.chessline}></div>
              <ThemeProvider theme={BellMTBold}>
                <Typography className={classes.chessbig}>
                  Efficiency through
                </Typography>
                <Typography className={classes.chessbigger}>
                  Mentorship
                </Typography>
              </ThemeProvider>
              <ThemeProvider theme={AvertaDemo}>
                <div className={classes.smalldiv}>
                  <Typography className={classes.chesstext}>
                    Increasing employee experience and Knowledge
                  </Typography>
                  <Typography className={classes.chesstext}>
                    through mentorship will productivity
                  </Typography>
                </div>
              </ThemeProvider>
            </div>
          </ThemeProvider>
          <Box className={classes.queryBox}>
            <img className={classes.queryImage} src={query} alt="query" />
          </Box>
        </Box>
      </Paper>
      <Box className={classes.whitemain}>
        <div className={classes.whiteleft}>
          <img src={twomen} />
        </div>
        <div className={classes.whiteright}>
          <Typography className={classes.segoesctext}>
            Employee Skill
          </Typography>
          <Box className={classes.segoesctextImage}>
            <Box className={classes.imageBox}>
              <img src={eight} className={classes.image} />
            </Box>
            <Typography className={classes.segoesctext}>Company</Typography>
          </Box>
          <Typography className={classes.segoesctext}>Improvement</Typography>
          <div className={classes.whitepartline}></div>
          <ThemeProvider theme={Opensans}>
            <Typography className={classes.whitefirst}>
              A development program will help bring your employees to a{' '}
            </Typography>
            <Typography className={classes.normaltext}>
              higher level of similar skills and knowledge. This helps
            </Typography>
            <Typography className={classes.normaltext}>
              reduce any weak link and toxic employee within the organisation.
            </Typography>
          </ThemeProvider>
        </div>
      </Box>
      <Box className={classes.yellowpart}>
        <ThemeProvider theme={Opensans}>
          <div className={classes.yellowmain}>
            <div className={classes.addressline}></div>
            <div className={classes.addressdiv}>
              <ThemeProvider theme={BellMTBold}>
                <Typography className={classes.addressbold}>
                  Let us address your critical
                </Typography>
                <Typography className={classes.addressbold}>
                  business priorities
                </Typography>
              </ThemeProvider>
            </div>
            <div className={classes.normaldiv}>
              <Typography className={classes.normaldivtest}>
                Organizations that adopt the Mentorship Program are best
                positioned
              </Typography>
              <Typography className={classes.normaldivtest}>
                to benefit from market changes.
              </Typography>
            </div>
            <ThemeProvider theme={BellMTBold}>
              <Typography className={classes.benefittext}>
                The benefits are immense as it stands to boost:
              </Typography>
            </ThemeProvider>
            <div className={classes.iconpart}>
              <div className={classes.iconitem}>
                <img src={yellowimage} />
                <Typography className={classes.icontext}>Competence</Typography>
              </div>

              <div className={classes.iconitem}>
                <img src={yellowimage} />
                <Typography className={classes.icontext}>
                  Interpersonal Skill
                </Typography>
              </div>

              <div className={classes.iconitem}>
                <img src={yellowimage} />
                <Typography className={classes.icontext}>Creativity</Typography>
              </div>

              <div className={classes.iconitem}>
                <img src={yellowimage} />
                <Typography className={classes.icontext}>
                  Versatility
                </Typography>
              </div>
            </div>
            <div className={classes.iconpart2}>
              <div className={classes.iconitem1}>
                <img src={yellowimage} />
                <Typography className={classes.icontext}>Effeciency</Typography>
              </div>
              <div className={classes.iconitem2}>
                <img src={yellowimage} />
                <Typography className={classes.icontext}>Confidence</Typography>
              </div>
              <div className={classes.iconitem3}>
                <img src={yellowimage} />
                <Typography className={classes.icontext}>Knowledge</Typography>
              </div>
              <div className={classes.iconitem4}>
                <img src={yellowimage} />
                <Typography className={classes.icontext}>
                  Performance
                </Typography>
              </div>
            </div>
            <div className={classes.undericonline}></div>
          </div>
        </ThemeProvider>
      </Box>

      <Box className={classes.mentorship}>
        <ThemeProvider theme={AvertaDemo}>
          <div className={classes.mentorshipmain}>
            <div>
              <ThemeProvider theme={BellMTBold}>
                <Typography className={classes.mentorshipbold}>
                  Use the right
                </Typography>
                <Typography className={classes.mentorshipbold}>
                  mentorship partner
                </Typography>
              </ThemeProvider>
              <ThemeProvider theme={AvertaDemo}>
                <div className={classes.mentorshipdiv}>
                  <ThemeProvider theme={Opensans}>
                    <Typography className={classes.mentorshipnormal}>
                      Business Mentorship transfer skills needed to be embraced
                      for
                    </Typography>
                    <Typography className={classes.mentorshipnormal}>
                      proper fit for dynamics of change. The Organization can
                      then{' '}
                    </Typography>
                    <Typography className={classes.mentorshipnormal}>
                      be positioned to benefit from people & process.
                    </Typography>
                  </ThemeProvider>
                </div>
              </ThemeProvider>
            </div>
            <div className={classes.moreunderline}></div>
          </div>
        </ThemeProvider>
      </Box>

      <Box className={classes.pinkpart}>
        <div className={classes.pinkmain}>
          <div className={classes.pinkleft}>
            <ThemeProvider theme={Opensans}>
              <ThemeProvider theme={Opensans}>
                <Typography className={classes.pinkleftnormal}>
                  Business mentorship transfers skills needed to be
                </Typography>
                <Typography className={classes.pinkleftnormal}>
                  embraced for proper fit for dynamics of change.
                </Typography>
                <Typography className={classes.pinkleftnormal}>
                  The Organization can then be
                </Typography>
                <Typography className={classes.pinkleftnormal}>
                  positioned to benefit from people & process.
                </Typography>

                <div className={classes.pinkleftdown}>
                  <Typography className={classes.pinkleftnormal}>
                    If you have any question about Mentorship program
                  </Typography>
                  <Typography className={classes.pinkleftnormal}>
                    from our work station, kindly send an email to
                  </Typography>
                  <ThemeProvider theme={OpensansBold}>
                    <Typography className={classes.pinkleftbold}>
                      sales@ecscorpresources.com
                    </Typography>
                  </ThemeProvider>
                  <Typography className={classes.pinkleftnormal}>
                    We are availble to respond
                  </Typography>
                  <ThemeProvider theme={OpensansBold}>
                    <Typography className={classes.pinkleftbold}>
                      Mondays to Fridays, 9.00am-6.00pm
                    </Typography>
                  </ThemeProvider>
                </div>
                <Link
                  to="/"
                  className={`${classes.inTouchButton}`}
                  component={motion.button}
                  animate="animate"
                  initial="initial"
                  variants={ButtonVariants}
                >
                  <ThemeProvider>
                    <Typography>
                      <a className={classes.touchlinktext}>Lets Talk</a>
                    </Typography>
                  </ThemeProvider>
                  <img src={whitearrow} className={classes.toucharrow} />
                </Link>
              </ThemeProvider>
            </ThemeProvider>
          </div>
          <div className={classes.pinkright}>
            <ThemeProvider theme={segoesc}>
              <div>
                <ThemeProvider theme={segoesc}>
                  <Typography className={classes.pinkrightbold}>
                    Try Our Business
                  </Typography>
                  <Typography className={classes.pinkrightbold}>
                    Mentorship Program
                  </Typography>
                  <Typography className={classes.pinkrightbold}>
                    Today
                  </Typography>
                </ThemeProvider>
                <div className={classes.whiteline}></div>
              </div>
            </ThemeProvider>
          </div>
        </div>
      </Box>

      <Footer />
    </div>
  );
};

export default Learning;
