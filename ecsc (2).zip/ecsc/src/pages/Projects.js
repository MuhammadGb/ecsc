import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { ThemeProvider, createTheme } from '@material-ui/core/styles';
import {
  Typography,
} from '@material-ui/core';

import brownback from '../asset/images/brownback.png';

const useStyles = makeStyles((theme) => ({
  pushPart: {
    backgroundImage: `url(${brownback})`,
    height: '86.5vh',
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'cover',
    width: '100%',
    position: 'relative',

    '@media only screen and (max-device-width: 600px)': {
      backgroundImage: 'none',
      height: '70vh',
    },
  },
  pushMain: {
    backgroundColor: '#fff',
    width: '40%',
    position: 'absolute',
    marginTop: '5.4em',
    paddingLeft: '4em',
    paddingRight: '4em',
    paddingTop: '3em',
    '@media only screen and (max-device-width: 600px)': {
      margin: '0 auto',
      justifyContent: 'center',
      paddingTop: '2em',
      position: 'static',
      width: '90%',
      paddingLeft: '0em',
      paddingRight: '0em',
    },
  },
  pushBold: {
    fontSize: '2.7em',
    fontWeight: '700',
    lineHeight: '1',
    '@media only screen and (max-device-width: 600px)': {
      fontSize: '1.5em',
    },
  },
  pushNormal: {
    fontSize: '1.2em',
    paddingTop: '2.4em',
    fontWeight: '600',
    '@media only screen and (max-device-width: 600px)': {
      fontSize: '0.9em',
    },
    //   lineHeight:'1',
  },
  pushNormal2: {
    fontSize: '1.1em',
    paddingTop: '1em',
    fontWeight: '600',
    '@media only screen and (max-device-width: 600px)': {
      fontSize: '0.9em',
    },
  },
}));

const Opensans = createTheme({
  typography: {
    fontFamily: ['Opensanslight'].join(','),
  },
});

const BellMTBold = createTheme({
  typography: {
    fontFamily: ['BellMTBold'].join(','),
  },
});

const Projects = () => {
  const classes = useStyles();
  return (
    <div>
      <ThemeProvider theme={Opensans}>
        <ThemeProvider theme={BellMTBold}>
          <Typography className={classes.pushBold}>
            {' '}
            With our collaboration, we can make a case nobody can refute.{' '}
          </Typography>
        </ThemeProvider>
        <ThemeProvider theme={Opensans}>
          <Typography className={classes.pushNormal}>
            As a creator, we foster innovation through various owned project and
            business intervention, support, providing direct turnaround platform
            for economic growth.{' '}
          </Typography>

          <Typography className={classes.pushNormal2}>
            We support the private and public sector in so many of our niche
            initiative to grow business and public advocacy business.
          </Typography>
        </ThemeProvider>
      </ThemeProvider>
    </div>
  );
};

export default Projects;
