import React, { useState } from 'react';
import Box from '@material-ui/core/Box';
import { makeStyles } from '@material-ui/styles';
import NavBar from '../globals/NavBar';
import copy from '../asset/images/copy.png';
import coder from '../asset/images/coder.png';
import Footer from '../globals/Footer';
import { ThemeProvider, createTheme } from '@material-ui/core/styles';
import {
  Button,
  Divider,
  TextField,
  Typography,
} from '@material-ui/core';

const borderTheme = createTheme({
  palette: {
    primary: {
      main: '#2E324B', //your color
    },
  },
  // overrides: {
  //   MuiOutlinedInput: {
  //     root: {
  //       border: '1px solid #2E324B',
  //     },
  //   },
  // },
});
const useStyles = makeStyles((theme) => ({
  column: {
    display: 'flex',
    flexDirection: 'column',
  },
  row: {
    display: 'flex',
    flexDirection: 'row',
  },
  sectionOne: {
    backgroundImage: `url(${coder})`,
    backgroundSize: 'cover',
    backgroundRepeat: 'no-repeat',
    height: '40em',
    color: 'white',
  },
  sectionOneText: {
    width: '45%',
    fontSize: '2.8em',
    position: 'relative',
    top: '5em',
    left: '5em',
    fontFamily: 'segoe script',
  },
  sectionTwo: {
    alignItems: 'center',
  },
  innerSectionTwo: {
    background: '#fafafa',
    color: '#2E324B',
    width: '80%',
    paddingBottom: '8em',
    position: 'relative',
    top: '-10em',
  },
  divider: {
    height: '0.2em',
    width: '40%',
    marginTop: '3.5em',
    marginBottom: '3em',
    backgroundColor: '#063E63',
  },
  leftSide: {
    paddingLeft: '7em',
    paddingRight: '4em',
    paddingTop: '5em',
    width: '55%',
  },
  leftSideTop: {
    marginBottom: '2em',
  },
  leftSideHeader: {
    fontSize: '3em',
    fontFamily: 'geometric',
  },
  leftSideSubHead: {
    fontSize: '2em',
    fontFamily: 'Opensanslight',
    fontWeight: '700',
  },
  leftSideText: {
    fontSize: '1.2em',
    fontFamily: 'Opensanslight',
    fontWeight: '700',
    '@media only screen and (max-device-width: 1300px)': {
      fontSize: '1.1em',
    },
  },
  leftSideNum: {
    fontSize: '1.5em',
    fontFamily: 'avertaDemo',
    fontWeight: '900',
    marginTop: '0.3em',
    marginBottom: '0.5em',
  },
  leftSideDate: {
    fontWeight: '700',
    fontSize: '1.25em',
    marginTop: '0.2em',
  },
  leftSideSentence: {
    marginTop: '0.5em',
    fontSize: '1.1em',
    marginBottom: '0.5em',
    fontFamily: 'Opensanslight',
    fontWeight: '700',
    width: '95%',
    '@media only screen and (max-device-width: 1300px)': {
      fontSize: '1em',
    },
  },
  leftSideMail: {
    fontWeight: '700',
    fontSize: '1.2em',
    fontFamily: 'Opensansbold',
  },
  rightSide: {
    marginTop: '8%',
    marginRight: '3.5em',
    width: '45%',
    alignItems: 'center',
    background: 'white',
    position: 'relative',
    top: '4em',
  },
  textField: {
    marginTop: '0.8em',
    marginBottom: '0.8em',
    width: '65%',
    borderRadius: '0.35em',
    borderColor: '#2E324B !important',
  },
  notchedOutline: {
    border: '1px solid #2E324B',
  },
  formHeader: {
    marginTop: '1.8em',
    fontSize: '2em',
    marginLeft: '-1em',
  },
  formButton: {
    marginTop: '0.8em',
    width: '65%',
    borderRadius: '1em',
    fontFamily: 'avertaDemo',
    fontSize: '1.1em',
    fontWeight: '400',
    backgroundColor: '#2E324B',
    color: 'white',
    textTransform: 'none',
    '&:hover': {
      backgroundColor: '#373c59',
    },
  },
  copyText: {
    cursor: 'pointer',
  },
}));

const ContactUs = () => {
  const [copyOne, ] = useState('+2348170002139');
  const [copyTwo, ] = useState('sales@ecscorpresources.com');
  const [copiedOne, setCopiedOne] = useState(false);
  const [copiedTwo, setCopiedTwo] = useState(false);
  //const textAreaRef = useRef(null);

  const classes = useStyles();

  const copyToClipboard = async (text) => {
    if ('clipboard' in navigator) {
      return await navigator.clipboard.writeText(text);
    } else {
      return document.execCommand('copy', true, text);
    }
  };

  const handleCopyClickOne = () => {
    copyToClipboard(copyOne)
      .then(() => {
        setCopiedOne(true);
        setTimeout(() => {
          setCopiedOne(false);
        }, 2000);
      })
      .catch((err) => console.log(err));
  };
  const handleCopyClickTwo = () => {
    copyToClipboard(copyTwo)
      .then(() => {
        setCopiedTwo(true);
        setTimeout(() => {
          setCopiedTwo(false);
        }, 2000);
      })
      .catch((err) => console.log(err));
  };

  return (
    <Box className={classes.root}>
      <NavBar />
      <Box className={classes.sectionOne}>
        <Typography className={`${classes.sectionOneText}`} variant="h4">
          We speak your local Language with Global experience
        </Typography>
      </Box>
      <Box className={`${classes.sectionTwo} ${classes.column}`}>
        <Box className={`${classes.innerSectionTwo} ${classes.row}`}>
          <Box className={`${classes.leftSide} ${classes.column}`}>
            <Box className={`${classes.leftSideTop}`}>
              <Typography className={`${classes.leftSideHeader}`}>
                General Inquiries
              </Typography>
            </Box>
            <Box>
              <Typography className={`${classes.leftSideSubHead}`}>
                Call an Agent
              </Typography>
              <Typography gutterBottom className={`${classes.leftSideText}`}>
                To speak to a Customer Service Agent, Please call
              </Typography>
              <Box className={`${classes.row}`} alignItems="center">
                <Typography
                  className={`${classes.leftSideNum}`}
                  value={copyOne}
                >
                  +234 817 000 2139
                </Typography>
                <span
                  onClick={handleCopyClickOne}
                  className={`${classes.copyText}`}
                >
                  &nbsp; &nbsp;
                  <img src={copy} alt="copy" />
                </span>
                <span
                  style={{
                    fontSize: '0.8em',
                    display: `${copiedOne ? 'block' : 'none'}`,
                  }}
                >
                  &nbsp; &nbsp;Copied!
                </span>
              </Box>
              <Typography className={`${classes.leftSideText}`}>
                We are available to respond
              </Typography>
              <Typography className={`${classes.leftSideDate}`}>
                Mondays to Fridays, 9.00am - 6.00pm
              </Typography>
            </Box>
            <Divider
              className={`${classes.divider}`}
              orientation="horizontal"
            />
            <Box>
              <Typography className={`${classes.leftSideSubHead}`}>
                Request a Quote
              </Typography>
              <Typography className={`${classes.leftSideSentence}`}>
                For more information about how our services can deliver value
                contact, please send your requests to
              </Typography>
              <Box className={`${classes.row}`} alignItems="center">
                <Typography
                  className={`${classes.leftSideMail}`}
                  value={copyTwo}
                >
                  sales@ecscorpresources.com
                </Typography>
                <span
                  onClick={handleCopyClickTwo}
                  className={`${classes.copyText}`}
                >
                  &nbsp; &nbsp;
                  <img src={copy} alt="copy" />
                </span>
                <span
                  style={{
                    fontSize: '0.8em',
                    display: `${copiedTwo ? 'block' : 'none'}`,
                  }}
                >
                  &nbsp; &nbsp;Copied!
                </span>
              </Box>
            </Box>
          </Box>
          <Box className={`${classes.rightSide} ${classes.column}`}>
            <Typography className={`${classes.formHeader}`}>
              Send us a Mail
            </Typography>
            <ThemeProvider theme={borderTheme}>
              <TextField
                className={`${classes.textField}`}
                label="Name"
                variant="outlined"
                size="small"
              />
              <TextField
                className={`${classes.textField}`}
                label="Company"
                variant="outlined"
                size="small"
              />
              <TextField
                className={`${classes.textField}`}
                label="Email"
                variant="outlined"
                size="small"
              />
              <TextField
                className={`${classes.textField}`}
                label="Phone No. (optional)"
                variant="outlined"
                size="small"
              />
              <TextField
                className={`${classes.textField}`}
                label="Message Title"
                variant="outlined"
                size="small"
              />
              <TextField
                className={`${classes.textField}`}
                multiline
                label="Message"
                minRows="5"
                variant="outlined"
                size="medium"
              />
            </ThemeProvider>
            <Button className={`${classes.formButton}`} variant="contained">
              Submit Message
            </Button>
          </Box>
        </Box>
      </Box>
      <Footer />
    </Box>
  );
};

export default ContactUs;
