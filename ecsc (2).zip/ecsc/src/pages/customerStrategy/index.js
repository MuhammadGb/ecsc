import CustomerSatisfaction from "./CustomerStrategy"

export default CustomerSatisfaction 