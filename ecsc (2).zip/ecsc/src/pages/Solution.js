import React from 'react';
import Box from '@material-ui/core/Box';
import { makeStyles } from '@material-ui/core/styles';
import { ThemeProvider, createTheme } from '@material-ui/core/styles';
import {
  Typography,
} from '@material-ui/core';
import '../styles/fonts.css';
import '../styles/NavBar.css';

const useStyles = makeStyles((theme) => ({
  pushBold: {
    fontSize: '2.8em',
    fontWeight: '700',
    lineHeight: '1',
    '@media only screen and (max-device-width: 1380px)': {
      fontSize: '2.5em',
    },
    '@media only screen and (max-device-width: 600px)': {
      fontSize: '1.5em',
    },
  },
  pushNormal: {
    fontSize: '1.1em',
    paddingTop: '2em',
    fontWeight: '600',
    '@media only screen and (max-device-width: 600px)': {
      fontSize: '0.9em',
    },
    //   lineHeight:'1',
  },
  pushNormal2: {
    fontSize: '1.1em',
    paddingTop: '1em',
    fontWeight: '600',
    '@media only screen and (max-device-width: 600px)': {
      fontSize: '0.9em',
    },
  },
  learnMore: {
    display: 'flex',
    marginTop: '0em',
    textDecoration: 'none',
    justifyContent: 'left',
    alignItems: 'center',
    paddingBottom: '2em',
    paddingTop: '1.5em',
    fontSize: '1.8em',
    color: '#000',
  },
  learntext: {
    fontWeight: '400',
  },
  arrow: {
    padding: '0em 1em',
  },
}));

const Opensans = createTheme({
  typography: {
    fontFamily: ['Opensanslight'].join(','),
  },
});

const BellMTBold = createTheme({
  typography: {
    fontFamily: ['BellMTBold'].join(','),
  },
});

const Solution = () => {
  const classes = useStyles();
  return (
    <Box>
      <ThemeProvider theme={Opensans}>
        <ThemeProvider theme={BellMTBold}>
          <Typography className={classes.pushBold}>
            Pushing the mind limit with collaboration to deliver the imagination
          </Typography>
        </ThemeProvider>
        <ThemeProvider theme={Opensans}>
          <ThemeProvider theme={Opensans}>
            <Typography className={classes.pushNormal}>
              We are a team of best thinker with immense insight & experience{' '}
              <br />
              in management consulting and technology solution.
            </Typography>

            <Typography className={classes.pushNormal2}>
              We use creativity, innovation & collaboration to engineer solution
              to <br />
              provide efficiency, growth & the right return on investment for
              your <br /> business.
            </Typography>
          </ThemeProvider>
          {/* <ThemeProvider theme={Opensans}> */}
          {/* <Link to="/about" className={classes.learnMore}>
            <p className="learntext">Learn more</p>
            <img src={bigblackarrow} className={classes.arrow} />
          </Link> */}
          {/* </ThemeProvider> */}
        </ThemeProvider>
      </ThemeProvider>
    </Box>
  );
};

export default Solution;
