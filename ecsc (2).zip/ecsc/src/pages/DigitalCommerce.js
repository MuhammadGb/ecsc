import React, { useEffect } from 'react';
import Box from '@material-ui/core/Box';
import { makeStyles } from '@material-ui/styles';
import NavBar from '../globals/NavBar';
import { Button, Typography } from '@material-ui/core';
import landscape from '../asset/images/landscape.png';
import video_rec from '../asset/images/video_rec.png';
import virt from '../asset/images/virt.png';
import television from '../asset/images/television.png';
import speaker from '../asset/images/speaker.png';
import plug from '../asset/images/plug.png';
import twoHelmets from '../asset/images/twoHelmets.png';
import query from '../asset/images/query.png';
import brown_moon from '../asset/images/brown_moon.png';
import index_f from '../asset/images/index_f.png';
import inTouchCircle from '../asset/images/inTouchCircle.png';
import paint from '../asset/images/paint.png';
import Footer from '../globals/Footer';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import { motion, useAnimation } from 'framer-motion';
import '../styles/fonts.css';
import { useInView } from 'react-intersection-observer';
import { Link } from 'react-router-dom';
import '../styles/fonts.css';
import { ThemeProvider, createTheme } from '@material-ui/core/styles';

const useStyles = makeStyles({
  column: {
    display: 'flex',
    flexDirection: 'column',
  },
  row: {
    display: 'flex',
    flexDirection: 'row',
  },
  sectionOne: {
    backgroundColor: '#020820',
    color: 'white',
    paddingTop: '6em',
    paddingBottom: '5em',
    // width: '100%',
  },
  createText: {
    fontFamily: 'Bell MT',
    paddingLeft: '0.3em',
    fontSize: '3.5em',
    fontWeight: '900',
    '@media only screen and (max-device-width: 1080px)': {
      fontSize: '2.2em !important',
    },
  },
  digitalTextArea: {
    width: '45%',
    marginLeft: '7%',
    marginTop: '8%',
    '@media only screen and (max-device-width: 1080px)': {
      width: '60%',
      marginLeft: '5%',
    },
  },
  digitalTextOne: {
    fontSize: '7.5em',
    marginRight: '0.1em',
    fontFamily: 'Bell MT',
    fontWeight: '700',
    '@media only screen and (max-device-width: 1080px)': {
      fontSize: '4.5em',
    },
  },
  digitalTextTwo: {
    fontSize: '3.2em !important',
    marginLeft: '0em',
    fontFamily: 'Bell MT',
    fontWeight: '700',
    position: 'relative',
    top: '0.6em',
    '@media only screen and (max-device-width: 1080px)': {
      fontSize: '2em !important',
    },
  },
  spacedDigital: {
    position: 'relative',
    top: '-14%',
    '@media only screen and (max-device-width: 1080px)': {
      top: '-13%',
    },
  },
  forTextOne: {
    fontFamily: 'Bell MT',
    fontSize: '3.5em',
    fontWeight: '700',
    position: 'relative',
    left: '11%',
    '@media only screen and (min-device-width: 1370px)': {
      left: '13%',
    },
    '@media only screen and (max-device-width: 1080px)': {
      fontSize: '2em',
    },
  },
  forTextTwo: {
    fontFamily: 'Bell MT',
    fontSize: '3.5em',
    paddingLeft: '1em',
    fontWeight: '700',
    position: 'relative',
    left: '12%',
    '@media only screen and (min-device-width: 1370px)': {
      left: '15%',
    },
    '@media only screen and (max-device-width: 1080px)': {
      fontSize: '2em',
      left: '18%',
    },
  },
  digitalCenter: {
    justifyContent: 'center',
    position: 'relative',
    left: '2.3em',
    top: '-6%',
  },
  digitalImage: {
    width: '45%',
    marginLeft: '2.5em',
    '@media only screen and (max-device-width: 1300px)': {
      marginLeft: '2.25em',
    },
    '@media only screen and (max-device-width: 1080px)': {
      width: '50%',
      marginLeft: '0.5em',
    },
  },
  digitalImageItemOne: {
    width: '80%',
    position: 'relative',
    bottom: '-12em',
    left: '-0.2em',
    '@media only screen and (min-device-width: 1370px)': {
      bottom: '-13em',
    },
    '@media only screen and (max-device-width: 1300px)': {
      bottom: '-11.2em',
    },
    '@media only screen and (max-device-width: 1080px)': {
      width: '80%',
      bottom: '-13.1em',
      right: '7em',
    },
  },
  virtualR: {
    '@media only screen and (max-device-width: 1080px)': {
      width: '100%',
    },
  },
  digitalSentence: {
    fontSize: '1.2em',
    width: '95%',
    fontFamily: 'AvertaDemo',
    position: 'relative',
    left: '1em',
    '@media only screen and (max-device-width: 1080px)': {
      fontSize: '0.8em',
    },
  },
  queryImage: {
    position: 'fixed',
    right: '0%',
    width: '4.5%',
    height: '8%',
    top: '26%',
    padding: '0.4em',
    cursor: 'pointer',
    background: 'rgba(0, 0, 0, 0.3)',
    zIndex: '1',
    border: '2px solid whitesmoke',
    borderRight: '0px',
  },
  sectionTwo: {
    backgroundColor: '#2E324B',
    height: '9em',
  },
  sectionThree: {
    marginTop: '5em',
    marginBottom: '3em',
    alignItems: 'center',
  },
  miningHeader: {
    fontSize: '3em',
    fontWeight: '700',
    fontFamily: 'Bell MT',
  },
  miningTextOne: {
    textAlign: 'center',
    width: '40%',
    fontSize: '1.1em',
    marginBottom: '2em',
    fontFamily: 'AvertaDemo',
    '@media only screen and (max-device-width: 1080px)': {
      width: '70%',
    },
  },
  miningTextTwo: {
    textAlign: 'center',
    width: '40%',
    fontSize: '1.1em',
    fontFamily: 'AvertaDemo',
    '@media only screen and (max-device-width: 1080px)': {
      width: '70%',
    },
  },
  sectionFour: {
    width: '70%',
    position: 'relative',
    left: '18%',
    marginBottom: '5em',
    backgroundColor: 'rgba(236, 236, 236, 0.08)',
    '@media only screen and (max-device-width: 1080px)': {
      width: '90%',
      left: '5%',
    },
  },
  subSectionOne: {
    marginLeft: '1em',
    height: '20em',
    justifyContent: 'space-between',
  },
  subSectionTwo: {
    marginLeft: '1em',
    height: '20em',
    justifyContent: 'space-between',
  },
  subSectionHeader: {
    fontSize: '2em',
    fontFamily: 'AvertaDemo',
    '@media only screen and (max-device-width: 1080px)': {
      fontSize: '1.2em',
    },
  },
  subSectionSentence: {
    fontSize: '0.9em',
    fontFamily: 'Opensanslight',
    fontWeight: '700',
    marginLeft: '0.1em',
    width: '90%',
    '@media only screen and (max-device-width: 1080px)': {
      width: '100%',
    },
  },
  subSectionText: {
    marginBottom: '2em',
    marginLeft: '0.5em',
  },
  sectionFive: {
    backgroundColor: '#FADD98',
    height: '30em',
  },
  shapedArea: {
    width: '7%',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  shaped: {
    backgroundColor: 'white',
    width: '100%',
    height: '5em',
  },
  centralContentArea: {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  centralContent: {
    width: '50%',
    position: 'relative',
    top: '40%',
    left: '-18%',
    '@media only screen and (max-device-width: 1080px)': {
      width: '80%',
      left: '-10%',
      top: '18%',
    },
  },
  contentHeader: {
    fontSize: '2.6em',
    fontWeight: '700',
    fontFamily: 'Bell MT',
  },
  contentText: {
    fontSize: '1.1em',
    fontFamily: 'Opensanslight',
    fontWeight: '600',
    marginTop: '1em',
  },
  centralImage: {
    width: '100%',
    position: 'relative',
    top: '-27%',
  },
  sectionSix: {
    height: '45em',
    backgroundImage: `url(${plug})`,
    backgroundColor: '#020820',
    color: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '0em 4em 0em 4em',
    '@media only screen and (max-device-width: 1080px)': {
      height: '40em',
    },
  },
  meetTexts: {
    justifyContent: 'center',
    marginTop: '1em',
  },
  meetTitle: {
    fontFamily: 'Bell MT',
    fontSize: '5em',
    fontWeight: '900',
    '@media only screen and (max-device-width: 1080px)': {
      fontSize: '3em',
    },
  },
  meetTextOne: {
    margin: '1.2em 1em 0em 0em',
    width: '35%',
    fontFamily: 'AvertaDemo',
    fontSize: '1em',
    '@media only screen and (max-device-width: 1080px)': {
      width: '40%',
    },
  },
  meetTextTwo: {
    margin: '1.2em 1em 0em 0.5em',
    position: 'relative',
    fontFamily: 'Opensans',
    fontSize: '3.5em',
    top: '-1.1em',
  },
  meetTextThree: {
    margin: '1.2em -1em 0em 1em',
    width: '35%',
    fontFamily: 'AvertaDemo',
    fontSize: '1em',
    '@media only screen and (max-device-width: 1080px)': {
      width: '40%',
    },
  },
  sectionSeven: {
    width: '50%',
    position: 'relative',
    left: '28%',
    margin: '7em 0em 7em 0em',
  },
  blankHeader: {
    fontSize: '4em',
    fontWeight: '700',
    fontFamily: 'Bell MT',
    lineHeight: '1em',
    marginBottom: '0.4em',
  },
  blankText: {
    fontSize: '1.2em',
    fontFamily: 'AvertaDemo',
  },
  helmetpart: {
    display: 'flex',
    flexDirection: 'row',
    width: '100%',
    justifyContent: 'center',
    alignContent: 'center',
    color: '#fff',
    padding: '0em 0em',
    '@media only screen and (max-device-width: 600px)': {
      display: 'block',
    },
  },
  helmetleft: {
    backgroundColor: '#013B4F',
    padding: '0em 4em 0em 0em',
    width: '50%',
    height: '21em',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-end',
    justifyContent: 'center',
    zIndex: 2,
    marginBottom: '-0.2em',
    marginRight: '-0.2em',
    '@media only screen and (max-device-width: 600px)': {
      width: '92%',
      height: '44vh',
      padding: '2em 1em 1em 1em',
      margin: '0 auto',
      justifyContent: 'center',
    },
  },
  helmetbold: {
    fontSize: '2.8em',
    lineHeight: '1',
    textAlign: 'left',
    width: '85%',
    '@media only screen and (max-device-width: 600px)': {
      fontSize: '1em',
    },
  },
  helmetnormal: {
    fontSize: '1.1em',
    textAlign: 'left',
    fontWeight: 'light',
    marginTop: '2.5em',
    width: '85%',
  },
  helmetright: {
    padding: '0',
    backgroundImage: `url(${twoHelmets})`,
    width: '50%',
    zIndex: 1,
    height: '21em',
    backgroundRepeat: 'no-repeat',
    marginBottom: '-0.2em',
    backgroundSize: 'cover',
    '@media only screen and (max-device-width: 600px)': {
      display: 'none',
    },
  },
  market: {
    display: 'flex',
    flexDirection: 'row',
    margin: '0 auto',
    justifyContent: 'space-between',
    padding: '0em 0em 0em 0em',
    fontSize: '1.5em',
    marginTop: '4em',
    width: '90%',
    '@media only screen and (min-device-width: 1500px)': {
      marginTop: '5em',
    },
  },
  paragraph: {
    marginRight: '0.5em',
    textAlign: 'center',
    paddingTop: '5em',
    fontSize: '1.5em',
  },
  paratext: {
    fontSize: '1em',
    fontFamily: 'Opensanslight',
    fontWeight: '700',
    position: 'relative',
    left: '2em',
    '@media only screen and (max-device-width: 1380px)': {
      fontSize: '0.9em',
      marginLeft: '1em',
    },
  },
  paratext1: {
    fontSize: '1em',
    position: 'relative',
    fontFamily: 'Opensanslight',
    fontWeight: '700',
    left: '-2em',
    '@media only screen and (max-device-width: 1380px)': {
      fontSize: '0.9em',
    },
  },
  helmetimg: {
    padding: '0',
    margin: '0',
  },
  touchpart: {
    marginTop: '0em',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    paddingBottom: '5em',
    zIndex: -1,
    height: '14em',
    backgroundImage: `url(${inTouchCircle})`,
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'cover',
    color: '#fff',
    padding: '7em 0em',
    '@media only screen and (max-device-width: 600px)': {
      justifyContent: 'left',
      alignItems: 'left',
      textAlign: 'left',
      margin: '0',
      padding: '4em 0em 2em 0em',
    },
  },
  touchmainOne: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    width: '50%',
  },
  touchmainTwo: {
    display: 'flex',
    flexDirection: 'column',
    width: '50%',
    '@media only screen and (max-device-width: 600px)': {
      //    marginLeft:'1em',
    },
  },
  touchboldOne: {
    fontSize: '2.5em',
    width: '70%',
    fontFamily: 'Leaguespartanbold',
    lineHeight: '1.1em',
  },
  touchboldTwo: {
    fontSize: '2.5em',
    textAlign: 'left',
    fontFamily: 'Leaguespartanbold',
    position: 'relative',
    color: '#2E324B',
    width: '70%',
    left: '8%',
  },
  touchnormal: {
    fontSize: '1.25em',
    textAlign: 'left',
    position: 'relative',
    fontFamily: 'Opensanslight',
    fontWeight: 700,
    color: '#2E324B',
    left: '8%',
    width: '70%',
    '@media only screen and (max-device-width: 600px)': {
      margin: '0',
      fontSize: '1.3em',
    },
  },
  touchnormal2: {
    fontSize: '1.25em',
    color: '#2E324B',
    fontFamily: 'Opensanslight',
    fontWeight: 700,
    position: 'relative',
    left: '8%',
    width: '70%',
    '@media only screen and (max-device-width: 600px)': {
      margin: '0',
      fontSize: '1.3em',
    },
  },
  linkButton: {
    marginTop: '4em',
    padding: '0em',
    width: '26%',
    textDecoration: 'none',
    borderRadius: '2.5em',
    position: 'relative',
    left: '8%',
    background: 'white',
    cursor: 'pointer',
  },
  buttonLink: {
    fontFamily: 'Opensanslight',
    textTransform: 'none',
    fontWeight: '900 ',
    fontSize: '1.3em',
    paddingLeft: '1.1em',
    borderRadius: '1.5em',
  },
  fowardIcon: {
    border: '3px solid #2E324B',
    color: '#2E324B',
    borderRadius: '1em',
    marginLeft: '0em',
    position: 'relative',
    left: '0.35em',
    fontSize: '1.5em !important',
    '@media only screen and (max-device-width: 1300px)': {
      left: '1em',
    },
  },
  sectionNine: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: '5em',
    paddingBottom: '5em',
  },
  paintText: {
    width: '40%',
    marginRight: '2em',
  },
  paintHeader: {
    fontSize: '3.2em',
    textAlign: 'right',
    fontWeight: '700',
    fontFamily: 'Bell MT',
    marginBottom: '0.7em',
  },
  paintWords: {
    fontSize: '1.3em',
    textAlign: 'right',
    fontFamily: 'AvertaDemo',
  },
});

const Opensans = createTheme({
  typography: {
    fontFamily: ['Opensanslight'].join(','),
  },
});

const AvertaDemo = createTheme({
  typography: {
    fontFamily: ['AvertaDemo'].join(','),
  },
});

const MontserratBold = createTheme({
  typography: {
    fontFamily: ['MontserratBold'].join(','),
  },
});

const OpensansBold = createTheme({
  typography: {
    fontFamily: ['OpensansBold'].join(','),
  },
});

const BellMTBold = createTheme({
  typography: {
    fontFamily: ['BellMTBold'].join(','),
  },
});

const ButtonVariants = {
  animate: {
    x: [0, -10],
    opacity: 1,
    transition: { yoyo: Infinity, ease: 'easeIn' },
  },
}; /* 
const ContainerVariants = {
  initial: {},
  animate: {},
};
const H1Variants = {
  initial: { x: -3000 },
  animate: { x: 0 },
  transition: {
    type: 'tween',
    duration: 20,
    delay: 1,
  },
};
const H2Variants = {
  initial: { y: -1000 },
  animate: { y: 0 },
  transition: {
    type: 'tween',
    duration: 1,
    delay: 0.4,
  },
};
const H3Variants = {
  initial: { x: 100, opacity: 0 },
  animate: { x: 0, opacity: 1 },
}; */
const digitalTextOne = {
  visible: { scale: 0.2 },
  hidden: {
    scale: 1,
    transition: { type: 'tween', duration: 1, delay: '0' },
  },
};
const sectionThree = {
  visible: { opacity: 1, y: 0, transition: { duration: 1 }, delay: '0' },
  hidden: { opacity: 0, y: 50 },
};
const subSectionOne = {
  visible: { opacity: 1, x: 0, transition: { duration: 1 }, delay: '0' },
  hidden: { opacity: 0, x: -50 },
};
const subSectionTwo = {
  visible: { opacity: 1, x: 0, transition: { duration: 1 }, delay: '0' },
  hidden: { opacity: 0, x: 50 },
};
/* const LeftVariants = {
  visible: { opacity: 1, x: 0, transition: { duration: 2 }, delay: '0.3' },
  hidden: { opacity: 0, x: -50 },
};
const RightVariants = {
  visible: { opacity: 1, x: 0, transition: { duration: 2 }, delay: '0.3' },
  hidden: { opacity: 0, x: 50 },
}; */

const DigitalCommerce = () => {
  const classes = useStyles();
  const [ref, inView] = useInView({
    threshold: 0,
    root: null,
    rootMargin: '0px',
  });
  const controls = useAnimation();

  //const [animation, cycleAnimation] = useCycle('animationOne', 'animationTwo');

  useEffect(() => {
    if (inView) {
      controls.start('visible');
    } else {
      controls.start('hidden');
    }
  }, [controls, inView]);

  // useEffect(() => {
  //   setTimeout(() => {
  //     cycleAnimation();
  //   }, 2000);
  // }, []);

  // useEffect(() => {
  //   if (scrollYProgress) {
  //     controls.start('visible');
  //   }
  // }, [controls, scrollYProgress]);

  return (
    <Box className={classes.root}>
      <NavBar />
      <Box className={`${classes.sectionOne} ${classes.row}`}>
        <Box className={`${classes.column} ${classes.digitalTextArea}`}>
          <Typography className={`${classes.createText}`} variant="h4">
            Creating a stunning
          </Typography>
          <Box className={`${classes.digitalCenter} ${classes.row}`}>
            <Typography
              className={`${classes.digitalTextOne}`}
              component={motion.div}
              variants={digitalTextOne}
              animate={controls}
              ref={ref}
              initial="hidden"
              variant="h2"
            >
              digital
            </Typography>
            <Typography className={`${classes.digitalTextTwo}`} variant="h4">
              experience
            </Typography>
          </Box>
          <Box className={`${classes.row} ${classes.spacedDigital}`}>
            <Typography className={`${classes.forTextOne}`} variant="h3">
              for
            </Typography>
            <Typography className={`${classes.forTextTwo}`} variant="h3">
              transformation
            </Typography>
          </Box>
          <Typography className={`${classes.digitalSentence}`} variant="h6">
            We help businesses build a profitable growth experience using our
            creative space to create the future before it exists
          </Typography>
        </Box>
        <Box className={`${classes.row} ${classes.digitalImage}`}>
          <Box className={`${classes.digitalImageItemOne}`}>
            <img className={`${classes.virtualR}`} src={virt} alt="virtualR" />
          </Box>
          <img className={`${classes.queryImage}`} src={query} alt="query" />
        </Box>
      </Box>
      <Box className={classes.sectionTwo}></Box>
      <Box
        className={`${classes.column} ${classes.sectionThree}`}
        component={motion.div}
        ref={ref}
        animate={controls}
        initial="hidden"
        variants={sectionThree}
      >
        <Typography className={classes.miningHeader}>
          Mining Intelligence Using Insight
        </Typography>
        <Typography className={classes.miningTextOne} variant="h6">
          Digital innovation is transforming businesses and creating
          opportunities to exceed customer's expectations.
        </Typography>
        <Typography className={classes.miningTextTwo} variant="h6">
          Digital technologies can help transform your business, find out how
          you can access the real benefits and what digital solutions we can
          offer your business.
        </Typography>
      </Box>
      <Box className={`${classes.sectionFour} ${classes.row}`}>
        <Box
          className={`${classes.column} ${classes.subSectionOne}`}
          component={motion.div}
          ref={ref}
          animate={controls}
          initial="hidden"
          variants={subSectionOne}
        >
          <Box className={`${classes.row}`}>
            <Box>
              <img
                className={`${classes.imageIcons}`}
                src={index_f}
                alt="index_finger"
              />
            </Box>
            <Box className={`${classes.subSectionText}`}>
              <Typography
                className={`${classes.subSectionHeader}`}
                variant="h4"
              >
                Digital Engagement
              </Typography>
              <Typography
                className={`${classes.subSectionSentence}`}
                variant="h6"
              >
                Bringing real customer experience using the digital technology
                framework
              </Typography>
            </Box>
          </Box>
          <Box className={`${classes.row}`}>
            <Box>
              <img
                className={`${classes.imageIcons}`}
                src={landscape}
                alt="landscape"
              />
            </Box>
            <Box className={`${classes.subSectionText}`}>
              <Typography
                className={`${classes.subSectionHeader}`}
                variant="h4"
              >
                UI/UX Design
              </Typography>
              <Typography
                className={`${classes.subSectionSentence}`}
                variant="h6"
              >
                User experience design, bringing design centric approach to user
                interface
              </Typography>
            </Box>
          </Box>
        </Box>
        <Box
          className={`${classes.column} ${classes.subSectionTwo}`}
          component={motion.div}
          ref={ref}
          animate={controls}
          initial="hidden"
          variants={subSectionTwo}
        >
          <Box className={`${classes.row}`}>
            <Box>
              <img
                className={`${classes.imageIcons}`}
                src={video_rec}
                alt="video_recorder"
              />
            </Box>
            <Box className={`${classes.subSectionText}`}>
              <Typography
                className={`${classes.subSectionHeader}`}
                variant="h4"
              >
                Videography
              </Typography>
              <Typography
                className={`${classes.subSectionSentence}`}
                variant="h6"
              >
                Creating your story using motion graphics to bring to life
              </Typography>
            </Box>
          </Box>
          <Box className={`${classes.row}`}>
            <Box>
              <img
                className={`${classes.imageIcons}`}
                src={speaker}
                alt="speaker"
              />
            </Box>
            <Box className={`${classes.subSectionText}`}>
              <Typography
                className={`${classes.subSectionHeader}`}
                variant="h4"
              >
                Branding
              </Typography>
              <Typography
                className={`${classes.subSectionSentence}`}
                variant="h6"
              >
                Creating a strong positive perception of your company. Build the
                root to sky.
              </Typography>
            </Box>
          </Box>
        </Box>
      </Box>
      <Box className={`${classes.row} ${classes.sectionFive}`}>
        <Box className={`${classes.column} ${classes.shapedArea}`}>
          <Box className={`${classes.shaped} ${classes.areaOne}`}></Box>
          <Box className={`${classes.shaped} ${classes.areaTwo}`}></Box>
        </Box>
        <Box className={`${classes.column} ${classes.centralContentArea}`}>
          <Box className={`${classes.column} ${classes.centralContent}`}>
            <Typography className={`${classes.contentHeader}`} variant="h4">
              Automating the digital experience
            </Typography>
            <Typography className={`${classes.contentText}`} variant="h6">
              We have a team of Digital Experts with great insight and technical
              knowledge on how to design a digital vision for your business, we
              place your business where the most valuable opportunities are and
              help you realize your vision quickly and confidently with
              exceptional results.
            </Typography>
          </Box>
          <Box className={`${classes.centralImage}`}>
            <img style={{ width: '100%' }} src={television} alt="television" />
          </Box>
        </Box>
        <Box className={`${classes.column} ${classes.shapedArea}`}>
          <Box className={`${classes.shaped} ${classes.areaThree}`}></Box>
          <Box className={`${classes.shaped} ${classes.areaFour}`}></Box>
        </Box>
      </Box>
      <Box className={`${classes.column} ${classes.sectionSix}`}>
        <Typography className={`${classes.meetTitle}`} variant="h2">
          Digital Intelligence
        </Typography>
        <Box className={`${classes.row} ${classes.meetTexts}`}>
          <Typography className={`${classes.meetTextOne}`} variant="h6">
            Find out how you can access the real benefits and what digital
            solutions we can offer your business digital technologies can help
            transform your business.
          </Typography>
          <Typography className={`${classes.meetTextTwo}`} variant="h3">
            meet
          </Typography>
          <Typography className={`${classes.meetTextThree}`} variant="h6">
            Digital Innovation is creating digital experience and business
            opportunities that exceeds customer's expectations.
          </Typography>
        </Box>
        <Typography className={`${classes.meetTitle}`} variant="h2">
          Collaboration
        </Typography>
      </Box>
      <Box className={`${classes.column} ${classes.sectionSeven}`}>
        <Typography className={`${classes.blankHeader}`} variant="h4">
          Automating the digital experience
        </Typography>
        <Typography className={`${classes.blankText}`} variant="h6">
          We have a team of Digital Experts with great insight and technical
          knowledge on how to design a digital vision for your business, we
          place your business where the most valuable opportunities are and help
          you realize your vision quickly and confidently with exceptional
          results.
        </Typography>
      </Box>
      <Box className={classes.helmetpart}>
        <ThemeProvider theme={Opensans}>
          <div className={classes.helmetleft}>
            <ThemeProvider theme={BellMTBold}>
              <Typography className={classes.helmetbold}>
                Creating the adept hub for Business Sportlight
              </Typography>
            </ThemeProvider>
            <ThemeProvider theme={Opensans}>
              <Typography className={classes.helmetnormal}>
                Using the best practices methodology to improve process, we can
                help you cut wastage and stay ahead of competition, The focus is
                to help you deliver significant and measurable change
              </Typography>
            </ThemeProvider>
          </div>

          <div className={classes.helmetright}>
            <ThemeProvider theme={OpensansBold}>
              <Typography className={classes.paragraph}>VS</Typography>
            </ThemeProvider>
            <div className={classes.market}>
              <Typography className={classes.paratext}>
                Market Forces
              </Typography>
              <Typography className={classes.paratext1}>
                Market Insight
              </Typography>
            </div>
          </div>
        </ThemeProvider>
      </Box>
      <Box className={classes.touchpart}>
        <Box className={classes.touchmainOne}>
          <Typography className={classes.touchboldOne}>
            You like to improve your performance?
          </Typography>
        </Box>
        <Box className={classes.touchmainTwo}>
          <Typography className={classes.touchboldTwo}>Get in Touch</Typography>
          <Typography className={classes.touchnormal}>
            and find out how your business can
          </Typography>
          <Typography className={classes.touchnormal2}>
            benefit from our creative space
          </Typography>
          <Link
            component={motion.a}
            animate="animate"
            initial="initial"
            variants={ButtonVariants}
            className={`${classes.linkButton}`}
            to="/contactus"
          >
            <Button
              className={classes.buttonLink}
              endIcon={<ArrowForwardIcon className={classes.fowardIcon} />}
            >
              Lets Talk
            </Button>
          </Link>
        </Box>
      </Box>
      <Box className={`${classes.row} ${classes.sectionNine}`}>
        <Box className={`${classes.column} ${classes.paintText}`}>
          <Typography className={`${classes.paintHeader}`} variant="h4">
            Purpose driven digital experience
          </Typography>
          <Typography className={`${classes.paintWords}`} variant="h6">
            We place your business where the most valuable opportunities are and
            help you realize your vision quickly and confidently with
            exceptional results we have a team of Digital Experts with great
            insight and technical knowledge on how to design a digital vision
            for your business
          </Typography>
        </Box>
        <Box className={`${classes.paintImage}`}>
          <img className={`${classes.imagePaint}`} src={paint} alt="paint" />
        </Box>
      </Box>
      <Footer />
    </Box>
  );
};

export default DigitalCommerce;
