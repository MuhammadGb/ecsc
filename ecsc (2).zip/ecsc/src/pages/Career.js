import React from "react";
import NavBar from "../globals/NavBar";
import Footer from "../globals/Footer";
// import '../styles/Logopart.css'
import Box from "@material-ui/core/Box";
import { makeStyles } from "@material-ui/core/styles";
import { ThemeProvider, createTheme } from "@material-ui/core/styles";
import {
  Paper,
  Typography,
} from "@material-ui/core";
import "../styles/fonts.css";

import query from "../asset/images/query.png";
import staircase from "../asset/images/staircase.png";
import careerimage from "../asset/images/careerimage.png";
import cultureimage from "../asset/images/cultureimage.png";
import companyimage from "../asset/images/companyimage.png";
import iceimage from "../asset/images/iceimage.png";
import businessimage from "../asset/images/businessimage.png";
import vacationimage from "../asset/images/vacationimage.png";
import stockimage from "../asset/images/stockimage.png";
import lunchimage from "../asset/images/lunchimage.png";
import umbrella from "../asset/images/umbrella.png";

import { Link } from "react-router-dom";
import {
  motion,
} from "framer-motion";

const useStyles = makeStyles((theme) => ({
  root: {
    margin: "0",
    padding: "0",
  },
  queryBox: {
    width: "7.5%",
    height: "15%",
    padding: "0.4em 0.4em 0em 0em",
    position: "relative",
    left: "0.5%",
    top: "24%",
    border: "2px solid white",
    borderRight: "0px",
    cursor: "pointer",
    "@media only screen and (max-device-width: 1300px)": {
      left: "34.5%",
    },
  },
  queryImage: {
    top: "15%",
    left: "15%",
    position: "relative",
  },
  bluepart: {
    background: "#2E324B",
    height: "75vh",
    backgroundRepeat: "no-repeat",
    backgroundSize: "cover",
    width: "100%",
  },
  firstmain: {
    paddingTop: "9em",
    color: "#fff",
    display: "flex",
    flexDirection: "row",
    justifyContent: "end",
    marginRight: "0.5em",
  },
  firstmainleft: {
    marginRight: "5em",
    marginTop: "3em",
  },
  firstmainbold: {
    fontSize: "3em",
    fontWeight: "bold",
    lineHeight: "1.1",
  },
  firstmainnormal: {
    fontSize: "1.3em",
    marginTop: "1em",
  },

  secondmain: {
    width: "90%",
    alignContent: "center",
    marginLeft: "6em",
    justifyContent: "space-between",
    paddingTop: "8em",
    display: "flex",
    flexDirection: "row",
  },
  secondmainbold: {
    fontSize: "2.7em",
    marginTop: "1em",
  },
  secondmainleft: {
    marginTop: "-27em",
  },
  secondmainright: {
    marginLeft: "5em",
    width: "100%",
    marginTop: "0em",
  },
  secondrighttext: {
    fontSize: "1.4em",
  },
  thirdmain: {
    width: "100%",
    margin: "6em auto 0 auto",
    alignContent: "center",
    textAlign: "center",
    justifyContent: "center",
    backgroundColor: "#2E324B",
    height: "50vh",
    padding: "0",
    color: "#fff",
    paddingTop: "5em",
  },
  thirdmainbold: {
    fontSize: "3.5em",
    fontWeight: "700",
  },
  thirdmaintext: {
    fontSize: "1.3em",
  },
  fourthmain: {
    display: "flex",
    flexDirection: "row",
    padding: "0 0em",
    margin: "-5em auto 0em auto",
    width: "90%",
    justifyContent: "center",
    alignContent: "center",
    background: "none",
  },
  imageSection: {
    display: "flex",
    flexDirection: "column",
    margin: "0 0.5em",
    width: "40%",
    height: "66vh",
    color: "#354054 !important",
    backgroundColor: "#F1F1F2",
    padding: "2em 1em 2em 1em",
  },
  cardText: {
    marginTop: "1em",
    fontWeight: "600",
  },
  cardtitle: {
    marginTop: "1em",
    fontSize: "1.5em",
    fontWeight: "700",
  },
  fifthpart: {
    justifyContent: "center",
    alignContent: "center",
    width: "100%",
    margin: "0 auto",
    textAlign: "center",
  },
  fifthmain: {
    background: "#FAFAFA",
    height: "100vh",
    marginTop: "8em",
    display: "flex",
    flexDirection: "row",
    width: "100%",
    paddingTop: "3em",
    justifyContent: "center",
  },
  fifthleft: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    textAlign: "center",
    marginLeft: "5em",
    width: "40%",
  },
  icontext: {
    marginTop: "-6em",
    fontSize: "1.35em",
  },
  fifthicon: {
    marginLeft: "1em",
    marginTop: "3em",
  },
  fifthicon2: {
    marginTop: "4em",
    marginLeft: "1em",
  },
  fifthright: {
    backgroundImage: `url(${umbrella})`,
    height: "90vh",
    backgroundRepeat: "no-repeat",
    backgroundSize: "contain",
    width: "90%",
    marginLeft: "7em",
    marginTop: "3em",
  },
  underline: {
    height: "0.35rem",
    width: "19rem",
    background: "#fff",
    marginLeft: "7em",
    marginTop: "10em",
  },
  textdiv: {
    color: "#fff",
    marginLeft: "7em",
    marginTop: "1em",
    textAlign: "left",
  },
  textnormal: {
    fontSize: "5em",
    lineHeight: "1",
  },
  inTouchButton: {
    textDecoration: "none",
    justifyContent: "right",
    alignItems: "center",
    color: "#fff",
    backgroundColor: "#000",
    width: "35em",
    height: "3vh",
    borderRadius: "40px",
    paddingTop: "1em",
    paddingBottom: "3em",
    marginTop: "4em",
    textAlign: "center",
  },
  touchlink: {
    textDecoration: "none",
  },
  touchlinktext: {
    fontSize: "1.3em",
    fontWeight: "light",
    color: "#fff",
  },
  footer: {
    marginTop: "4em",
  },
}));
const geometric = createTheme({
  typography: {
    fontFamily: ["geometric"].join(","),
  },
});
const Bebas = createTheme({
  typography: {
    fontFamily: ["Bebas"].join(","),
  },
});
const Opensans = createTheme({
  typography: {
    fontFamily: ["Opensanslight"].join(","),
  },
});

const AvertaDemo = createTheme({
  typography: {
    fontFamily: ["AvertaDemo"].join(","),
  },
});
/* 
const MontserratBold = createTheme({
  typography: {
    fontFamily: ["MontserratBold"].join(","),
  },
});
const Montserrat = createTheme({
  typography: {
    fontFamily: ["Montserrat"].join(","),
  },
});

const OpensansBold = createTheme({
  typography: {
    fontFamily: ["OpensansBold"].join(","),
  },
});

const BellMT = createTheme({
  typography: {
    fontFamily: ["BellMT"].join(","),
  },
});

const BellMTBold = createTheme({
  typography: {
    fontFamily: ["BellMTBold"].join(","),
  },
});
 */
const ButtonVariants = {
  animate: {
    x: [0, -10],
    opacity: 1,
    transition: { yoyo: Infinity, ease: "easeIn" },
  },
};
const Career = () => {
  const classes = useStyles();
  return (
    <div className={classes.root}>
      <Paper elevation={0} className={classes.bluepart}>
        <NavBar />

        <Box className={classes.firstmain}>
          <ThemeProvider theme={AvertaDemo}>
            <div className={classes.firstmainleft}>
              <ThemeProvider theme={geometric}>
                <Typography className={classes.firstmainbold}>
                  Your Will Power Drives
                </Typography>
                <Typography className={classes.firstmainbold}>
                  your Career Growth
                </Typography>
              </ThemeProvider>
              <ThemeProvider theme={AvertaDemo}>
                <Typography className={classes.firstmainnormal}>
                  We invest in you while you accelerate your Career
                </Typography>
              </ThemeProvider>
            </div>
            <Box className={classes.queryBox}>
              <img className={classes.queryImage} src={query} alt="query" />
            </Box>
          </ThemeProvider>
        </Box>
      </Paper>

      <Box className={classes.secondpart}>
        <div className={classes.secondmain}>
          <div className={classes.secondmainleft}>
            <img src={staircase} alt={"staircase"} />
          </div>
          <div className={classes.secondmainright}>
            <ThemeProvider theme={AvertaDemo}>
              <div>
                <ThemeProvider theme={AvertaDemo}>
                  <Typography className={classes.secondrighttext}>
                    Our staff make us standout, which is why we are constantly{" "}
                  </Typography>
                  <Typography className={classes.secondrighttext}>
                    looking for more commited and passionate individuals with
                  </Typography>
                  <Typography className={classes.secondrighttext}>
                    exceptional skills to come join our team
                  </Typography>
                </ThemeProvider>
              </div>
              <div>
                <ThemeProvider theme={AvertaDemo}>
                  <Typography className={classes.secondrighttext}>
                    We have built an incubator to mentor, nurture and build our
                  </Typography>
                  <Typography className={classes.secondrighttext}>
                    staffs to be the best.
                  </Typography>
                </ThemeProvider>
              </div>
              <div>
                <ThemeProvider theme={AvertaDemo}>
                  <Typography className={classes.secondrighttext}>
                    We have provided an enabling environment to maximize our
                  </Typography>
                  <Typography className={classes.secondrighttext}>
                    staff potential, that is why we regard our company as an
                  </Typography>
                  <Typography className={classes.secondrighttext}>
                    entrepreneurial business school.
                  </Typography>
                </ThemeProvider>
              </div>
              <ThemeProvider theme={Bebas}>
                <Typography className={classes.secondmainbold}>
                  JOIN OUR TEAM TODAY AND MAKE A DIFFERENCE
                </Typography>
              </ThemeProvider>
            </ThemeProvider>
          </div>
        </div>
      </Box>

      <Box className={classes.thirdpart}>
        <ThemeProvider theme={Opensans}>
          <div className={classes.thirdmain}>
            <ThemeProvider theme={geometric}>
              <Typography className={classes.thirdmainbold}>
                Taking That Bold Step
              </Typography>
            </ThemeProvider>
            <div>
              <ThemeProvider theme={Opensans}>
                <Typography className={classes.thirdmaintext}>
                  Own that path, unlock those doors and seek opportunities to{" "}
                </Typography>
                <Typography className={classes.thirdmaintext}>
                  {" "}
                  shape a better world. We can create that platform for you
                </Typography>
              </ThemeProvider>
            </div>
          </div>
        </ThemeProvider>
      </Box>

      <Box>
        <ThemeProvider theme={Opensans}>
          <Paper elevation={0} className={classes.fourthmain}>
            <Paper elevation={0} className={classes.imageSection}>
              <img src={careerimage} alt={"careerimage-cr"} />
              <Typography className={classes.cardtitle}>
                Career in Perspective
              </Typography>
              <Typography className={classes.cardText}>
                The best part of joining a global organization? The global
                opportunities on offer
              </Typography>
            </Paper>

            <Paper elevation={0} className={classes.imageSection}>
              <img src={cultureimage} alt={"section-cultureimage"}/>
              <Typography className={classes.cardtitle}>Our Culture</Typography>
              <Typography className={classes.cardText}>
                Our people recognize the responsibilities they have to uphold
                our values.
              </Typography>
            </Paper>

            <Paper elevation={0} className={classes.imageSection}>
              <img src={companyimage} alt={"sct-companyimage"} />
              <Typography className={classes.cardtitle}>Our Company</Typography>
              <Typography className={classes.cardText}>
                Friendliness to support and reach a high performing team.
              </Typography>
            </Paper>

            <Paper elevation={0} className={classes.imageSection}>
              <img src={iceimage} alt={"sct-iceimage"}  />
              <Typography className={classes.cardtitle}>
                Ice Breaker Team
              </Typography>
              <Typography className={classes.cardText}>
                We will give you the support you need to reach your goals and
                fulfil your potentials.
              </Typography>
            </Paper>
          </Paper>
        </ThemeProvider>
      </Box>

      <Box className={classes.fifthpart}>
        <ThemeProvider theme={Opensans}>
          <div className={classes.fifthmain}>
            <div className={classes.fifthleft}>
              <div className={classes.fifthicon}>
                <img src={businessimage} alt={"sct-businessimage"}/>
                <Typography className={classes.icontext}>
                  Business School
                </Typography>
              </div>
              <div className={classes.fifthicon}>
                <img src={stockimage} alt={"sct-stockimage"} />
                <Typography className={classes.icontext}>
                  Stock Options
                </Typography>
              </div>
              <div className={classes.fifthicon2}>
                <img src={lunchimage} alt={"lunchimage"} />
                <Typography className={classes.icontext}>Free Lunch</Typography>
              </div>
              <div className={classes.fifthicon2}>
                <img src={vacationimage} alt={"sct-vacationimage"} />
                <Typography className={classes.icontext}>Vacation</Typography>
              </div>
            </div>
            <div className={classes.fifthright}>
              <div className={classes.underline}></div>
              <div className={classes.textdiv}>
                <ThemeProvider theme={Bebas}>
                  <Typography className={classes.textnormal}>
                    COME ADD COLOR
                  </Typography>
                  <Typography className={classes.textnormal}>
                    {" "}
                    TO OUR TEAM
                  </Typography>
                </ThemeProvider>
              </div>
            </div>
          </div>
        </ThemeProvider>
        <Link
          to="/"
          className={`${classes.inTouchButton}`}
          component={motion.button}
          animate="animate"
          initial="initial"
          variants={ButtonVariants}
        >
          <ThemeProvider theme={AvertaDemo}>
            <Link to="/jobsearch" className={classes.touchlink}>
              <Typography>
                <a href="/" className={classes.touchlinktext}>SEARCH FOR JOB OPENINGS</a>
              </Typography>
            </Link>
          </ThemeProvider>
        </Link>
      </Box>
      <div className={classes.footer}>
        <Footer />
      </div>
    </div>
  );
};

export default Career;
