import React from 'react';

const FunctionPage = () => {
  return <div></div>;
};

export default FunctionPage;
