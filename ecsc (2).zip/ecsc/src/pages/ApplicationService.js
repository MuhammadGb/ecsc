import React from 'react';
import Box from '@material-ui/core/Box';
import { makeStyles } from '@material-ui/styles';
import NavBar from '../globals/NavBar';
import horizon from '../asset/images/horizon.png';
import plane_turbine from '../asset/images/plane_turbine.png';
import globe_tech from '../asset/images/globe_tech.png';
import butterfly from '../asset/images/butterfly.png';
import query from '../asset/images/query.png';
import { ThemeProvider, createTheme } from '@material-ui/core/styles';
import { Button, Divider, Icon, Typography } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import Footer from '../globals/Footer';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const useStyles = makeStyles((theme) => ({
  column: {
    display: 'flex',
    flexDirection: 'column',
  },
  row: {
    display: 'flex',
    flexDirection: 'row',
  },
  sectionOne: {
    backgroundImage: `url(${horizon})`,
    backgroundSize: 'cover',
    backgroundRepeat: 'no-repeat',
    color: 'white',
    height: '42em',
  },
  sectionOneText: {
    width: '45%',
    marginTop: '20%',
    marginLeft: '10%',
    '@media only screen and (max-device-width: 1300px)': {
      width: '46%',
    },
  },
  sectionOneHeader: {
    fontSize: '5em',
    width: '65%',
    fontFamily: 'geometric',
    marginBottom: '0.3em',
    lineHeight: '1em',
  },
  sectionOneSentence: {
    fontSize: '1.2em',
    fontFamily: 'AvertaDemo',
    fontWeight: '500',
  },
  dividerOne: {
    height: '0.2em',
    width: '30%',
    marginTop: '3.5em',
    marginBottom: '3em',
    backgroundColor: 'white',
  },
  queryImage: {
    position: 'fixed',
    right: '0%',
    top: '26%',
    width: '4.5%',
    height: '8%',
    padding: '0.4em',
    cursor: 'pointer',
    background: 'rgba(0, 0, 0, 0.3)',
    zIndex: '1',
    border: '2px solid whitesmoke',
    borderRight: '0px',
  },
  sectionTwo: {
    backgroundImage: `url(${globe_tech})`,
    backgroundSize: 'cover',
    backgroundRepeat: 'no-repeat',
    color: '#020820',
    height: '38em',
    alignItems: 'center',
    justifyContent: 'flex-end',
    paddingRight: '5em',
  },
  innerTwo: {
    position: 'relative',
    width: '45%',
    top: '-2em',
    right: '2.2em',
    '@media only screen and (max-device-width: 1300px)': {
      width: '46%',
    },
  },
  dividerTwo: {
    height: '0.3em',
    width: '35%',
    marginTop: '3.5em',
    marginBottom: '2em',
    position: 'relative',
    left: '50%',
    backgroundColor: '#020820',
  },
  headerTwo: {
    fontSize: '3.9em',
    fontWeight: '700',
    lineHeight: '1em',
    textAlign: 'right',
    fontFamily: 'Bell MT',
  },
  sentenceTwo: {
    fontSize: '1.2em',
    textAlign: 'right',
    marginTop: '1.5em',
    fontFamily: 'Opensanslight',
    fontWeight: '700',
  },
  sectionThree: {
    backgroundImage: `url(${butterfly})`,
    backgroundSize: 'cover',
    backgroundRepeat: 'no-repeat',
    color: '#020820',
    height: '45em',
    alignItems: 'center',
    justifyContent: 'flex-start',
    paddingRight: '5em',
  },
  innerThree: {
    position: 'relative',
    width: '55%',
    top: '-2em',
    marginLeft: '7em',
    '@media only screen and (max-device-width: 1300px)': {
      width: '46%',
    },
  },
  headerThree: {
    fontSize: '3.9em',
    fontWeight: '700',
    lineHeight: '1.1em',
    fontFamily: 'geometric',
  },
  sentenceThree: {
    fontSize: '1.2em',
    marginTop: '1.5em',
    fontFamily: 'AvertaDemo',
    fontWeight: '700',
  },
  sectionFour: {
    height: '40em',
    backgroundColor: '#020820',
    color: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },
  fourthLineOne: {
    height: '0.3em',
    width: '60%',
    marginTop: '3.5em',
    marginBottom: '2em',
    backgroundColor: 'white',
    position: 'relative',
    left: '-75%',
  },
  fourthLineTwo: {
    height: '0.3em',
    width: '60%',
    marginTop: '1.5em',
    marginBottom: '2.5em',
    backgroundColor: 'white',
    position: 'relative',
    left: '106%',
  },
  wordOne: {
    fontSize: '4em',
    lineHeight: '1.1em',
    position: 'relative',
    left: '-25%',
    fontFamily: 'geometric',
  },
  wordTwo: {
    fontSize: '4em',
    lineHeight: '1.1em',
    fontFamily: 'geometric',
  },
  wordThree: {
    fontSize: '4em',
    lineHeight: '1.1em',
    position: 'relative',
    left: '50%',
    fontFamily: 'geometric',
  },
  textFour: {
    width: '45%',
    '@media only screen and (max-device-width: 1300px)': {
      width: '46%',
    },
  },
  sentenceFour: {
    fontSize: '1.1em',
    fontFamily: 'Opensanslight',
    fontWeight: '500',
    textAlign: 'right',
  },
  sectionFive: {
    backgroundImage: `url(${plane_turbine})`,
    backgroundSize: 'cover',
    backgroundRepeat: 'no-repeat',
    color: '#020820',
    height: '40em',
    alignItems: 'center',
    justifyContent: 'flex-start',
    paddingLeft: '7em',
  },
  textFive: {
    width: '50%',
    position: 'relative',
    top: '4em',
    '@media only screen and (max-device-width: 1300px)': {
      width: '52%',
    },
  },
  textFiveHeader: {
    fontSize: '3.7em',
    lineHeight: '1.1em',
    fontFamily: 'Bell MT',
    fontWeight: '700',
    marginBottom: '0.5em',
  },
  textFiveSentence: {
    fontSize: '1.4em',
    fontFamily: 'Opensanslight',
    fontWeight: '700',
    width: '95%',
    marginBottom: '0.5em',
  },
  linkButton: {
    marginTop: '1.25em',
    padding: '0.3em',
    width: '29%',
    height: '12%',
    textDecoration: 'none',
    borderRadius: '2.5em',
    background: '#020820',
    cursor: 'pointer',
  },
  buttonLink: {
    fontFamily: 'Opensanslight',
    textTransform: 'none',
    textAlign: 'center',
    fontWeight: '700',
    fontSize: '1.3em',
    borderRadius: '1.5em',
    color: 'white',
    width: '100%',
    height: '100%',
  },
  fowardIcon: {
    border: '3px solid white',
    color: 'white',
    borderRadius: '1em',
    marginLeft: '0em',
    position: 'relative',
    left: '0.6em',
    fontSize: '1.5em !important',
    '@media only screen and (max-device-width: 1300px)': {
      left: '0.4em',
    },
  },
}));

const ButtonVariants = {
  animate: {
    x: [0, -10],
    opacity: 1,
    transition: { yoyo: Infinity, ease: 'easeIn' },
  },
};

const Technology = () => {
  const classes = useStyles();
  return (
    <Box className={classes.root}>
      <NavBar />
      <Box className={`${classes.sectionOne} ${classes.row}`}>
        <Box className={`${classes.sectionOneText} ${classes.column}`}>
          <Typography className={`${classes.sectionOneHeader}`}>
            Defining the Future
          </Typography>
          <Typography className={`${classes.sectionOneSentence}`}>
            we provide a world class solutions that deliver results, setting the
            standards for tomorrow’s technologies with daring ideas. We find no
            challenge impossible.
          </Typography>
          <Divider
            className={`${classes.dividerOne}`}
            orientation="horizontal"
          />
        </Box>
        <img className={classes.queryImage} src={query} alt="query" />
      </Box>
      <Box className={`${classes.sectionTwo} ${classes.row}`}>
        <Box className={classes.innerTwo}>
          <Divider
            className={`${classes.dividerTwo}`}
            orientation="horizontal"
          />
          <Typography className={`${classes.headerTwo}`}>
            Delivering service through Innovation
          </Typography>
          <Typography className={`${classes.sentenceTwo}`}>
            Discovering fresh methods to deliver service whilst enhancing
            organisational flexibility. We use technology to solve most critical
            business issues . We woo our customers with specific custom software
            with robust performance.
          </Typography>
        </Box>
      </Box>
      <Box className={`${classes.sectionThree} ${classes.row}`}>
        <Box className={classes.innerThree}>
          <Typography className={`${classes.headerThree}`}>
            Innovation insight for technology solution
          </Typography>
          <Typography className={`${classes.sentenceThree}`}>
            We unitize our creative space to design a tailored technology
            solution to better align our client business strategy and ensure the
            right resources are available right on time, we are the best at new
            application development, modernization, maintenance and all through
            development life cycle.
          </Typography>
          <Typography className={`${classes.sentenceThree}`}>
            We operate at the intersection of innovation and transformation,
            using agile approach to deal with all application complexity.
          </Typography>
        </Box>
      </Box>
      <Box className={`${classes.sectionFour} ${classes.column}`}>
        <Box>
          <Divider
            className={`${classes.fourthLineOne}`}
            orientation="horizontal"
          />
          <Typography className={`${classes.wordOne}`}>Innovate</Typography>
          <Typography className={`${classes.wordTwo}`}>Transform</Typography>
          <Typography className={`${classes.wordThree}`}>Perform</Typography>
          <Divider
            className={`${classes.fourthLineTwo}`}
            orientation="horizontal"
          />
        </Box>
        <Box className={`${classes.textFour}`}>
          <Typography className={`${classes.sentenceFour}`}>
            We take our customers through this process to create better value
            for their software need. We deliver world class solution that
            delivers result, our process and methodology is straight to the
            point and cost friendly.
          </Typography>
        </Box>
      </Box>
      <Box className={`${classes.sectionFive} ${classes.row}`}>
        <Box className={`${classes.textFive} ${classes.column}`}>
          <Typography className={`${classes.textFiveHeader}`}>
            Improved Productivity Anytime-Anywhere
          </Typography>
          <Typography className={`${classes.textFiveSentence}`}>
            We build our software in modules so that the solutions can be
            scalable over time and also build a business case after the
            architecture to show reliability and immediate cost savings.
          </Typography>
          <Link
            component={motion.a}
            animate="animate"
            initial="initial"
            variants={ButtonVariants}
            className={`${classes.linkButton}`}
            to="/contactus"
          >
            <Button
              className={classes.buttonLink}
              endIcon={<ArrowForwardIcon className={classes.fowardIcon} />}
            >
              Lets Talk
            </Button>
          </Link>
        </Box>
      </Box>
      <Footer />
    </Box>
  );
};

export default Technology;
