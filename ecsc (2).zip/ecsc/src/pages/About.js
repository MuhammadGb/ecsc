import React from 'react';
import Footer from '../globals/Footer';
import Header from '../globals/Header';
import Box from '@material-ui/core/Box';
import { makeStyles } from '@material-ui/styles';
import { ThemeProvider, createTheme } from '@material-ui/core/styles';
import {
  Paper,
  Typography,
} from '@material-ui/core';
import {
  motion,
} from 'framer-motion';

import { Link } from 'react-router-dom';
import '../styles/fonts.css';

import cube from '../asset/images/cube.png';
import mouse from '../asset/images/mouse.png';
import hands from '../asset/images/hands.png';
import operations from '../asset/images/operations.png';
import technology from '../asset/images/technology.png';
import vertical from '../asset/images/vertical.png';
import horizontal from '../asset/images/horizontal.png';
import threedots from '../asset/images/threedots.png';
import nature from '../asset/images/nature.png';
import yellowback from '../asset/images/yellowback.png';
import whitearrow from '../asset/images/whitearrow.png';
import signature from '../asset/images/signature.png';

const useStyles = makeStyles((theme) => ({
  root: {
    margin: '0',
    padding: '0',
  },
  firstpart: {
    height: '100vh',
    width: '100%',
    background: '#fafafa',
  },
  firstmain: {
    width: '70%',
    alignContent: 'center',
    margin: '0em auto 0 auto',
    justifyContent: 'space-between',
    paddingTop: '8em',
    display: 'flex',
    flexDirection: 'row',
  },
  firstbold: {
    fontSize: '3em',
  },
  firsttext: {
    fontSize: '1.5em',
  },
  firstleft: {
    marginTop: '6em',
  },
  firstright: {
    marginTop: '5em',
  },
  secondmain: {
    height: '90vh',
    display: 'flex',
    flexDirection: 'row',

    margin: '10em auto 0em auto',
    justifyContent: 'space-evenly',
    width: '100%',
  },
  secondtextdiv: {
    marginTop: '4em',
  },
  secondright: {
    marginTop: '2em',
  },
  thirdmain: {
    width: '100%',
    margin: '0 auto',
    alignContent: 'center',
    textAlign: 'center',
    justifyContent: 'center',
    marginTop: '0em',
  },
  fourthmain: {
    display: 'flex',
    flexDirection: 'row',
    padding: '0 3em',
    margin: '0 auto',
    width: '50%',
    justifyContent: 'center',
    alignContent: 'center',
  },
  middlesection: {
    display: 'flex',
    flexDirection: 'row',
    margin: '0 auto',
    width: '49%',
    paddingTop: '3em',
    paddingBottom: '1em',
    textAlign: 'center',
    justifyContent: 'space-between',
  },
  middletext: {
    fontSize: '1.7em',
    fontWeight: '900',
  },
  imageSection: {
    display: 'flex',
    flexDirection: 'column',
    margin: '0 0.5em',
    width: '40%',
    height: '61vh',
    color: '#354054 !important',
    backgroundColor: '#F1F1F2',
    padding: '2em 1em 2em 1em',
  },
  cardText: {
    marginTop: '2em',
    fontWeight: '600',
  },

  fifthmain: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    padding: '0 6em',
    marginTop: '8em',
    height: '87vh',
    background: '#fafafa',
  },
  fifthleft: {
    paddingTop: '4em',
  },
  textdiv: {
    marginLeft: '7em',
    marginTop: '1em',
  },
  textbold: {
    fontSize: '5em',
    lineHeight: '0.9',
  },
  textflex: {
    display: 'flex',
    flexDirection: 'row',
  },
  boxbold: {
    fontSize: '9.5em',
    marginTop: '-0.3em',
    marginLeft: '0.2em',
  },
  fifthright: {
    backgroundImage: `url(${nature})`,
    height: '80vh',
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'contain',
    width: '100%',
    marginLeft: '13em',
    marginTop: '3em',
  },
  fifthmiddle: {
    textAlign: 'center',
    marginTop: '13.5em',
    marginRight: '2em',
  },
  fifthsemibold: {
    fontSize: '2em',
  },
  fifthbold: {
    fontSize: '4.5em',
    lineHeight: '1',
  },
  fifthimage: {
    marginLeft: '-28em',
    paddingTop: '0.5em',
  },
  verticalimage: {
    marginLeft: '24em',
    marginTop: '-2em',
  },
  sixthmain: {
    backgroundImage: `url(${yellowback})`,
    height: '100vh',
    backgroundRepeat: 'no-repeat',
    backgroundSize: '100% 100%',
    backgroundPosition: 'center',
    width: '100%',
    textAlign: 'right',
    alignContent: 'right',
  },
  sixthpart: {
    paddingRight: '8em',
    paddingTop: '3em',
  },
  sixthbold: {
    fontSize: '5em',
    lineHeight: '1',
  },
  sixthnormal: {
    marginTop: '2em',
  },
  sixthtext: {
    fontSize: '1.5em',
  },
  inTouchButton: {
    display: 'flex',
    textDecoration: 'none',
    justifyContent: 'right',
    alignItems: 'center',
    color: '#fff',
    backgroundColor: '#000',
    width: '15em',
    height: '6vh',
    border: 'none',
    borderRadius: '40px',
    paddingTop: '2em',
    paddingBottom: '2em',
    marginTop: '2em',
    marginLeft: '90em',
  },
  touchlinktext: {
    fontSize: '1.5em',
  },
  toucharrow: {
    paddingLeft: '0em',
    paddingRight: '0.5em',
    marginLeft: '1em',
  },
  seventhpart: {
    backgroundImage: `url(${signature})`,
    // backgroundColor:'grey',
    height: '100vh',
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'cover',
    width: '100%',
    margin: '0 auto',
    textAlign: 'center',
    justifyContent: 'center',
    paddingTop: '2em',
    paddingBottom: '7em',
  },
  seventhmain: {
    margin: '0 auto',
    width: '50%',
    textAlign: 'left',
    marginTop: '1em',
    paddingTop: '2em',
    paddingBottom: '2em',
  },
  moreunderline: {
    height: '0.35rem',
    width: '10rem',
    justifySelf: 'center',
    background: 'black',
    textAlign: 'center',
  },
  sourcepart: {
    backgroundColor: 'black',
    color: '#fff',
    textAlign: 'center',
  },
  sourceparttext: {
    padding: '0.8em 0',
    fontSize: '2em',
  },
  seventhbold: {
    padding: '0.5em 0em 0em 0em',
    fontSize: '2em',
  },
  seventhtextdiv: {
    marginTop: '1.5em',
  },
  seventhtext: {
    fontSize: '1.2em',
    lineHeight: '1.2',
  },
  seventhlasttext: {
    fontSize: '2em',
    padding: '0.8em 0em',
  },
  thirdbold: {
    fontSize: '3em',
  },
  thirdtext: {
    fontSize: '1.5em',
  },
}));
const segoesc = createTheme({
  typography: {
    fontFamily: ['segoesc'].join(','),
  },
});
const Opensans = createTheme({
  typography: {
    fontFamily: ['Opensanslight'].join(','),
  },
});

const AvertaDemo = createTheme({
  typography: {
    fontFamily: ['AvertaDemo'].join(','),
  },
});



const OpensansBold = createTheme({
  typography: {
    fontFamily: ['OpensansBold'].join(','),
  },
});


const BellMTBold = createTheme({
  typography: {
    fontFamily: ['BellMTBold'].join(','),
  },
});

const geometric = createTheme({
  typography: {
    fontFamily: ['geometric'].join(','),
  },
});

const righteous = createTheme({
  typography: {
    fontFamily: ['righteous'].join(','),
  },
});
const ButtonVariants = {
  animate: {
    x: [0, -10],
    opacity: 1,
    transition: { yoyo: Infinity, ease: 'easeIn' },
  },
};

const About = () => {
  const classes = useStyles();
  return (
    <div className={classes.root}>
      <Box className={classes.firstpart}>
        <Header />
        <ThemeProvider theme={AvertaDemo}>
          <div className={classes.firstmain}>
            <div className={classes.firstleft}>
              <ThemeProvider theme={segoesc}>
                <Typography className={classes.firstbold}>
                  Solution Engineering
                </Typography>
                <Typography className={classes.firstbold}>
                  For Business Agility
                </Typography>
              </ThemeProvider>
              <div>
                <ThemeProvider theme={AvertaDemo}>
                  <Typography className={classes.firsttext}>
                    We use the agile approach in solving most complex
                  </Typography>
                  <Typography className={classes.firsttext}>
                    business problems using creativity and innovations
                  </Typography>
                  <Typography className={classes.firsttext}>
                    where necessary to achieve best business objective.
                  </Typography>
                </ThemeProvider>
              </div>
            </div>
            <div className={classes.firstright}>
              <img src={cube} alt={"firstright-cube"} />
            </div>
          </div>
        </ThemeProvider>
      </Box>

      <Box className={classes.secondmain}>
        <ThemeProvider theme={AvertaDemo}>
          <div className={classes.secondleft}>
            <img src={mouse} alt={"sec-left-mouse"} />
          </div>
          <div className={classes.secondright}>
            <ThemeProvider theme={segoesc}>
              <Typography className={classes.firstbold}>Our Company</Typography>
            </ThemeProvider>

            <div className={classes.secondtextdiv}>
              <ThemeProvider theme={AvertaDemo}>
                <Typography className={classes.firsttext}>
                  We are a team of best thinkers with immense
                </Typography>
                <Typography className={classes.firsttext}>
                  insight and experience in management consulting
                </Typography>
                <Typography className={classes.firsttext}>
                  and technology solution.
                </Typography>
              </ThemeProvider>
            </div>
            <div className={classes.secondtextdiv}>
              <ThemeProvider theme={AvertaDemo}>
                <Typography className={classes.firsttext}>{"We use creativity, innovation & collaboration to"}
                </Typography>
                <Typography className={classes.firsttext}>
                  engineer solution to provide efficiency, growth &
                </Typography>
                <Typography className={classes.firsttext}>
                  the right return on investment for your business.
                </Typography>
              </ThemeProvider>
            </div>
          </div>
        </ThemeProvider>
      </Box>

      <Box className={classes.thirdmain}>
        <ThemeProvider theme={AvertaDemo}>
          <ThemeProvider theme={segoesc}>
            <Typography className={classes.thirdbold}>Our Focus</Typography>
          </ThemeProvider>
          <div>
            <ThemeProvider theme={AvertaDemo}>
              <Typography className={classes.thirdtext}>
                Our business has continued to grow as we think people,
              </Typography>
              <Typography className={classes.thirdtext}>
                technology & management operation.
              </Typography>
            </ThemeProvider>
          </div>
        </ThemeProvider>
      </Box>

      <Box className={classes.middlesection}>
        <ThemeProvider theme={Opensans}>
          <ThemeProvider theme={Opensans}>
            <Typography className={classes.middletext}>People</Typography>
            <Typography className={classes.middletext}>Technology</Typography>
            <Typography className={classes.middletext}>Operations</Typography>
          </ThemeProvider>
        </ThemeProvider>
      </Box>

      <Box>
        <ThemeProvider theme={Opensans}>
          <Paper elevation={0} className={classes.fourthmain}>
            <Paper elevation={0} className={classes.imageSection}>
              <img src={hands} alt={"fourth-main-hands"} />

              <Typography className={classes.cardText}>
                We review with detailed assesments, their business concern to
                forecast the characteristics of the main potential impact
              </Typography>
            </Paper>

            <Paper elevation={0} className={classes.imageSection}>
              <img src={technology} alt={"sct-tech"} />

              <Typography className={classes.cardText}>
                Every company needs support especially when it comes to
                performance improvement, we can help you deliver
              </Typography>
            </Paper>

            <Paper elevation={0} className={classes.imageSection}>
              <img src={operations} alt={"sct-ops"} />

              <Typography className={classes.cardText}>
                Every company needs support especially when it comes to
                performance improvement, we can help you deliver
              </Typography>
            </Paper>
          </Paper>
        </ThemeProvider>
      </Box>

      <Box className={classes.fifthmain}>
        <ThemeProvider theme={geometric}>
          <div className={classes.fifthleft}>
            <img src={threedots} alt={"fifth-left3dot"}/>

            <div className={classes.textdiv}>
              <ThemeProvider theme={geometric}>
                <Typography className={classes.textbold}>
                  We think as
                </Typography>
                <Typography className={classes.textbold}>
                  if there is
                </Typography>
              </ThemeProvider>
              <div className={classes.textflex}>
                <ThemeProvider theme={geometric}>
                  <Typography className={classes.textbold}>no</Typography>
                  <ThemeProvider theme={OpensansBold}>
                    <Typography className={classes.boxbold}>BOX</Typography>
                  </ThemeProvider>
                </ThemeProvider>
              </div>
            </div>
            <img src={vertical} alt={"vert-geo"} className={classes.verticalimage} />
          </div>

          <div className={classes.fifthright}>
            <ThemeProvider theme={Opensans}>
              <div className={classes.fifthmiddle}>
                <div className={classes.fifthtop}>
                  <ThemeProvider theme={OpensansBold}>
                    <Typography className={classes.fifthsemibold}>
                      EXACTLY
                    </Typography>
                    <Typography className={classes.fifthbold}>
                      OUTSIDE
                    </Typography>
                  </ThemeProvider>
                </div>
                <img src={horizontal} alt={"horizontal-fifth"} className={classes.fifthimage} />
                <div className={classes.fifthdown}>
                  <ThemeProvider theme={OpensansBold}>
                    <Typography
                      className={`${classes.fifthsemibold} ${classes.fifthlast}`}
                    >
                      NO BOX
                    </Typography>
                  </ThemeProvider>
                </div>
              </div>
            </ThemeProvider>
          </div>
        </ThemeProvider>
      </Box>

      <Box className={classes.sixthmain}>
        <div className={classes.sixthpart}>
          <ThemeProvider theme={BellMTBold}>
            <div>
              <ThemeProvider theme={BellMTBold}>
                <Typography className={classes.sixthbold}>
                  We can make
                </Typography>
                <Typography className={classes.sixthbold}>
                  your goals happen
                </Typography>
              </ThemeProvider>
            </div>
            <div>
              <ThemeProvider theme={AvertaDemo}>
                <div className={classes.sixthnormal}>
                  <Typography className={classes.sixthtext}>
                    Our role as a solution engineering company is to help our
                  </Typography>
                  <Typography className={classes.sixthtext}>
                    client deliver the best value for their business through
                  </Typography>
                  <Typography className={classes.sixthtext}>
                    insights, planning and partnership for incessant growth.
                  </Typography>
                </div>

                <div className={classes.sixthnormal}>
                  <Typography className={classes.sixthtext}>
                    We believe strongly that brands and consumers are
                  </Typography>
                  <Typography className={classes.sixthtext}>
                    constantly knitting together, either you are producing
                  </Typography>
                  <Typography className={classes.sixthtext}>
                    or selling something, successful businesses are those
                  </Typography>
                  <Typography className={classes.sixthtext}>
                    that are learning to do more. If you want to achieve
                  </Typography>
                  <Typography className={classes.sixthtext}>
                    more, we’re your best partner.
                  </Typography>
                </div>
              </ThemeProvider>
            </div>
            <Link
              to="/"
              className={`${classes.inTouchButton}`}
              component={motion.button}
              animate="animate"
              initial="initial"
              variants={ButtonVariants}
            >
              <ThemeProvider theme={AvertaDemo}>
                <Typography>
                  <a href={"/"} className={classes.touchlinktext}>Lets Talk</a>
                </Typography>
              </ThemeProvider>
              <img src={whitearrow} alt={"wht-whitearrow"} className={classes.toucharrow} />
            </Link>
          </ThemeProvider>
        </div>
      </Box>

      <Box className={classes.seventhpart}>
        <div className={classes.seventhmain}>
          <ThemeProvider theme={Opensans}>
            <div className={classes.sourcepart}>
              <ThemeProvider theme={AvertaDemo}>
                <Typography className={classes.sourceparttext}>
                  The Source of Our Pride
                </Typography>
              </ThemeProvider>
            </div>
            <ThemeProvider theme={righteous}>
              <Typography className={classes.seventhbold}>
                The ecs-ellent team
              </Typography>
            </ThemeProvider>
            <div className={classes.seventhtextdiv}>
              <ThemeProvider theme={AvertaDemo}>
                <Typography className={classes.seventhtext}>
                  We believe our employee plays a key role in our success that
                  is why we have created an internal
                </Typography>
                <Typography className={classes.seventhtext}>
                  University for learning and mentorship cultureto develop more
                  skills while empowering and
                </Typography>
                <Typography className={classes.seventhtext}>
                  motivating them to be the right thinker.
                </Typography>
              </ThemeProvider>
            </div>

            <div className={classes.seventhtextdiv}>
              <ThemeProvider theme={AvertaDemo}>
                <Typography className={classes.seventhtext}>
                  Our goal is to build a platform for sustainable growth for our
                  organisation and stakeholders, for
                </Typography>
                <Typography className={classes.seventhtext}>
                  employee we have created an atmosphere that will encourage a
                  secured and enabling environment
                </Typography>
                <Typography className={classes.seventhtext}>
                  to work, while committed to add visible value to our client's
                  business.
                </Typography>
              </ThemeProvider>
            </div>

            <div className={classes.seventhtextdiv}>
              <ThemeProvider theme={AvertaDemo}>
                <Typography className={classes.seventhtext}>
                  We know that partnership and alliances are the secrets of
                  incessant growth and organisation success.
                </Typography>
                <Typography className={classes.seventhtext}>
                  We have formed partnership and alliances with outstanding
                  companies and organizations whose
                </Typography>
                <Typography className={classes.seventhtext}>
                  capabilities would complement ours, either by a way of
                  extending our service offering or helping with
                </Typography>
                <Typography className={classes.seventhtext}>
                  the delivery of new technology or business process.
                </Typography>
              </ThemeProvider>
            </div>
            <ThemeProvider theme={BellMTBold}>
              <Typography className={classes.seventhlasttext}>
                We are a team of the best thinkers
              </Typography>
            </ThemeProvider>
            <div className={classes.moreunderline}></div>
          </ThemeProvider>
        </div>
      </Box>
      <Footer />
    </div>
  );
};

export default About;
