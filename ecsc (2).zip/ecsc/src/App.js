import React from 'react';
// import '/App.css'
import ScrollToTop from './component/ScrollToTop';
import HomePage from './pages/HomePage';
import About from './pages/About';
import Career from './pages/Career';
import DigitalCommerce from './pages/DigitalCommerce';
import BusinessAgility from './pages/BusinessAgility';
import ContactUs from './pages/ContactUs';
import Learning from './pages/Learning';
import ApplicationService from './pages/ApplicationService';
import FeaturedInsight from './pages/FeaturedInsight';
import CustomerSatisfaction from './pages/customerStrategy';
import Jobs from './pages/Jobs';
import OtherServices from './pages/OtherServices';
import { BrowserRouter, Switch, Route } from 'react-router-dom';

const App = () => {
  return (
    <>
      <BrowserRouter>
        <ScrollToTop />
        {/* <NavBar/> */}
        {/* <div className='pages'> */}
        <Switch>
          <Route path="/" exact component={HomePage}></Route>
          <Route path="/learning" exact component={Learning}></Route>
          <Route
            path="/digitalcommerce"
            exact
            component={DigitalCommerce}
          ></Route>
          <Route path="/customerstrategy" component={CustomerSatisfaction}></Route>
          <Route path="/businessagility" component={BusinessAgility}></Route>
          <Route path="/career" component={Career}></Route>
          <Route path="/contactus" component={ContactUs}></Route>
          <Route path="/about" component={About}></Route>
          <Route
            path="/application_service"
            component={ApplicationService}
          ></Route>
          <Route path="/jobsearch" component={Jobs}></Route>
          <Route path="/featuredinsight" component={FeaturedInsight}></Route>
          <Route path="/otherservices" component={OtherServices}></Route>
        </Switch>
        {/* </div> */}
      </BrowserRouter>
    </>
  );
};

export default App;
