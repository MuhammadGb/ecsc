import React, { useEffect, useState} from 'react';
import {  NavLink } from 'react-router-dom';
import { FaBars } from 'react-icons/fa';
import { FaTimes } from 'react-icons/fa';

import '../styles/NavBar.css';
import Dropdown from '../component/Dropdown';
import navlogo from '../asset/images/navlogo.png';
import blacklogo from '../asset/images/blacklogo.png';

const NavBar = (props) => {
  const {page} = props
  const [appearance, setAppearance] = useState(false);
  const [dropdown, setDropdown] = useState(false);
  const [mobile, setMobile] = useState(false);
  let klass = ''
  let navlogoImg = ''
  if(page==='customerStrategy'){
    if(appearance ){
      klass = 'navbar dark'
      navlogoImg = navlogo
    }
    else{
      klass = 'navbar light'
      navlogoImg = blacklogo
    }
  }else{
    klass=appearance ? 'navbar addition' : 'navbar'
    navlogoImg = navlogo
  }
const handleClick = () => setMobile(!mobile);
useEffect(() => {
  
  const changeBackground = () => {
    if (window.scrollY >= 80) {
      setAppearance(true);
    } else {
      setAppearance(false);
    }
  };

  window.addEventListener('scroll', changeBackground);

  return () => {
    
  window.removeEventListener('scroll', changeBackground);
  }
}, [])

const onMouseEnter = () => {
  if (window.innerWidth < 960) {
    setDropdown(false);
  } else {
    setDropdown(true);
  }
};

const onMouseLeave = () => {
  if (window.innerWidth < 960) {
    setDropdown(false);
  } else {
    setDropdown(false);
  }
};
  return (
    <nav className={klass}>
      <div className="nav-container">
        <NavLink exact to="/" className="nav-logo">
          <img src={navlogoImg} alt={"navLogo"} className="navlogoImg" />
        </NavLink>
        <div className="mobile-menu-icon" onClick={handleClick}>
          {mobile ? <FaTimes color="#fff" /> : <FaBars color="#fff" />}
        </div>
        <ul
          className={mobile ? 'nav-menu active' : 'nav-menu'}
          onClick={() => setMobile(false)}
        >
          <li className="nav-item">
            <NavLink exact to="/featuredinsight" className="nav-links">
              Featured Insight
            </NavLink>
          </li>
          <li
            className="nav-item"
            onMouseEnter={onMouseEnter}
            onMouseLeave={onMouseLeave}
          >
            <NavLink exact to="/" className="nav-links">
            Functions
            </NavLink>
            {dropdown && <Dropdown />}
          </li>
          <li className="nav-item">
            <NavLink exact to="/career" className="nav-links">
              Careers
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink exact to="/About" className="nav-links">
              About Us
            </NavLink>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default NavBar;
