import React, { useState } from 'react';
import Box from '@material-ui/core/Box';
import { makeStyles } from '@material-ui/styles';
import query from '../asset/images/query.png';
import typewriter from '../asset/images/typewriter.png';
import Footer from '../globals/Footer';
import Header from '../globals/Header';
import { Typography } from '@material-ui/core';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';

const useStyles = makeStyles({
  column: {
    display: 'flex',
    flexDirection: 'column',
  },
  row: {
    display: 'flex',
    flexDirection: 'row',
  },
  firstSection: {
    backgroundImage: `url(${typewriter})`,
    height: '34em',
    color: '#020820',
    justifyContent: 'center',
  },
  textBoxFirst: {
    alignItems: 'center',
    position: 'relative',
    top: '15%',
  },
  sectionOneText: {
    fontSize: '3.2em',
    fontWeight: '700',
    width: '45%',
    lineHeight: '1em',
    position: 'relative',
    left: '5%',
  },
  queryBox: {
    width: '100%',
    cursor: 'pointer',
    background: 'rgba(0, 0, 0, 0.3)',
    position: 'relative',
    top: '-25%',
    alignItems: 'flex-end',
  },
  queryPic: {
    border: '2.5px solid white',
    padding: '1.1em',
    borderRight: '0px',
  },
  secondSection: {
    padding: '2em 4em',
    backgroundColor: '#FAFAFA',
  },
  rowBoxes: {
    flexFlow: 'wrap',
    justifyContent: 'center',
  },
  innerBoxOne: {
    margin: '1em 2em',
    width: '40%',
    height: '9em',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: '1em',
    // "&:hover": {
    //   border: "2px solid midnightblue"
    // },
  },
  boxTextOne: {
    fontSize: '1.8em',
    fontWeight: '700',
  },
  boxTextTwo: {
    fontSize: '1em',
    marginRight: '0.8em',
    fontWeight: '700',
  },
  fowardIcon: {
    border: '3px solid #2E324B',
    color: '#2E324B',
    borderRadius: '1em',
    fontSize: '1.5em !important',
  },
  filter: {
    display: 'none',
  },
  general: {
    position: 'relative',
    top: '7em',
    left: '10em',
    width: '20em',
    height: '10em',
    background: 'green',
  },
  
});

const JobSearch = (props) => {
  const classes = useStyles();
  const {  jobDetails, jobRoles } = props;
  const [number, setNumber] = useState(0);

  const filteredJobs = jobDetails.filter((jbD) => jbD.index === number);

const handleClick = (e,number)=>{
  console.log(number)
  setNumber(number)
}
  return (
    <Box>
      <Header />
      <Box className={`${classes.firstSection} ${classes.column}`}>
        <Box className={`${classes.textBoxFirst} ${classes.column}`}>
          <Typography className={`${classes.sectionOneText} ${classes.row}`}>
            Join our Journey
          </Typography>
          <Typography className={`${classes.sectionOneText} ${classes.row}`}>
            and grab opportunities
          </Typography>
        </Box>
        <Box className={`${classes.queryBox} ${classes.column}`}>
          <img className={`${classes.queryPic}`} src={query} alt="query" />
        </Box>
      </Box>
      <Box className={`${classes.secondSection} ${classes.column}`}>
        <Box className={`${classes.row} ${classes.rowBoxes}`}>
          {jobRoles.map((jR) => (
            <Box
              variant="outlined"
              className={`${classes.innerBoxOne} ${classes.column}`}
              
              onClick={(e)=>handleClick(e,jR.index)}
            >
              <Typography className={`${classes.boxTextOne}`}>
                {jR.role}
              </Typography>
              <Box className={`${classes.row} ${classes.active}`} alignItems="center">
                <Typography className={`${classes.boxTextTwo}`}>
                  {jR.view}
                </Typography>
                <ArrowForwardIcon className={classes.fowardIcon} />
              </Box>
              {number === jR.index
                ? filteredJobs.map((fjb) => (
                    <Box className={`${classes.general}`}>
                      <Typography variant="h4" gutterBottom>
                        {fjb.role}
                      </Typography>
                      <Typography variant="h4" gutterBottom>
                        {fjb.ID}
                      </Typography>
                      <Typography variant="h6" gutterBottom>
                        {fjb.description}
                      </Typography>
                      <Typography variant="h6" gutterBottom>
                        {fjb.qualifications}
                      </Typography>
                    </Box>
                  ))
                : ''}
            </Box>
          ))}
        </Box>
      </Box>
      <Footer />
    </Box>
  );
};

export default JobSearch;
