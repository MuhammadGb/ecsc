import React from 'react';
import Box from '@material-ui/core/Box';
import { makeStyles } from '@material-ui/styles';

const useStyles = makeStyles({
  column: {
    display: 'flex',
    flexDirection: 'column',
  },
  row: {
    display: 'flex',
    flexDirection: 'row',
  },
  none: {
    display: 'none',
  },
});

const JobInfo = (props) => {
  const classes = useStyles();
  const {  openJob} = props;

  return (
    <Box className={openJob? classes.column: classes.none}>
      <Box>
        <Box>THE JOB DETAILS</Box>
      </Box>
      <Box>
        <Box>DETAILS OF THE JOB</Box>
      </Box>
    </Box>
    );
};

export default JobInfo;
