export const MenuItems = [
  {
    title: 'Application Service',
    path: '/application_service',
    cName: 'dropdown-first',
  },
  {
    title: 'Business Agility',
    path: '/businessagility',
    cName: 'dropdown-link',
  },
  {
    title: 'Customer Strategy',
    path: 'customerstrategy',
    cName: 'dropdown-link',
  },
  {
    title: 'Digital Commerce',
    path: '/digitalcommerce',
    cName: 'dropdown-link',
  },
  {
    title: 'Learning & Engagement',
    path: '/learning',
    cName: 'dropdown-last',
  },
];
